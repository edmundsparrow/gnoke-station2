/**
 * db.js — Gnoke Contacts
 * Storage via GnokeSysDB (AppDB) — Gnoke Station 2 native.
 * Replaces the old localStorage('webos-contacts') approach.
 *
 * Storage layout (namespaced to 'contact' by AppDB):
 *   AppDB.sessions → contact records { id, title, name, phone, email, created_at }
 *
 * Public API (async):
 *   await DB.init()
 *   await DB.getContacts()        → Contact[]  (sorted by name)
 *   await DB.saveContact(contact) → id
 *   await DB.deleteContact(id)    → void
 *   DB.newId()                    → string
 */

const DB = (() => {
  'use strict';

  function _db() {
    if (!window.AppDB) throw new Error('[DB] AppDB not ready — gnoke-presence.js must run first');
    return window.AppDB;
  }

  function newId() {
    return Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
  }

  async function init() {
    await new Promise((resolve) => {
      if (window.AppDB) { resolve(); return; }
      const t = setInterval(() => {
        if (window.AppDB) { clearInterval(t); resolve(); }
      }, 40);
      setTimeout(() => { clearInterval(t); resolve(); }, 4000);
    });
  }

  async function getContacts() {
    const rows = await _db().sessions.getAll();
    return rows
      .map(r => ({
        id: r.id, name: r.name || r.title || '', phone: r.phone || '', email: r.email || '',
        created_at: r.created_at || '',
      }))
      .sort((a, b) => a.name.localeCompare(b.name));
  }

  async function saveContact(contact) {
    const id = contact.id || newId();
    await _db().sessions.put({
      id,
      title:      contact.name,
      name:       contact.name,
      phone:      contact.phone || '',
      email:      contact.email || '',
      created_at: contact.created_at || new Date().toISOString(),
      ts:         Date.now(),
    });
    return id;
  }

  async function deleteContact(id) {
    await _db().sessions.delete(id);
  }

  return { init, newId, getContacts, saveContact, deleteContact };
})();
