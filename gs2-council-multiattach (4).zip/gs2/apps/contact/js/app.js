/**
 * app.js — Gnoke Contacts
 * Inline-page UI logic. No WindowManager — this is a full GS2 app page.
 */

const App = (() => {
  'use strict';

  let _contacts = [];
  let _editingId = null;

  function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text || '';
    return div.innerHTML;
  }

  function toast(message, type = 'info') {
    const el = document.getElementById('toast');
    if (!el) return;
    el.textContent = message;
    el.className = 'toast show ' + type;
    clearTimeout(el._t);
    el._t = setTimeout(() => el.classList.remove('show'), 2400);
  }

  function render(list = _contacts) {
    const wrap  = document.getElementById('contacts-list');
    const empty = document.getElementById('contacts-empty');

    if (!list.length) {
      wrap.innerHTML = '';
      empty.style.display = 'block';
      return;
    }
    empty.style.display = 'none';

    wrap.innerHTML = list.map(c => `
      <div class="contact-card" data-id="${c.id}">
        <div class="contact-info">
          <div class="contact-name">${escapeHtml(c.name)}</div>
          ${c.phone ? `<div class="contact-detail">${escapeHtml(c.phone)}</div>` : ''}
          ${c.email ? `<div class="contact-detail">${escapeHtml(c.email)}</div>` : ''}
        </div>
        <div class="contact-actions">
          ${c.phone ? `<button class="icon-btn icon-btn-call" data-action="call" data-phone="${escapeHtml(c.phone)}" title="Call">📞</button>` : ''}
          <button class="icon-btn" data-action="edit" data-id="${c.id}" title="Edit">✏️</button>
          <button class="icon-btn icon-btn-danger" data-action="delete" data-id="${c.id}" title="Delete">🗑️</button>
        </div>
      </div>
    `).join('');
  }

  function showForm(contact = null) {
    _editingId = contact?.id || null;
    document.getElementById('form-title').textContent = contact ? 'Edit Contact' : 'New Contact';
    document.getElementById('contact-name').value  = contact?.name  || '';
    document.getElementById('contact-phone').value = contact?.phone || '';
    document.getElementById('contact-email').value = contact?.email || '';
    document.getElementById('contact-form-overlay').classList.add('open');
    document.getElementById('contact-name').focus();
  }

  function hideForm() {
    document.getElementById('contact-form-overlay').classList.remove('open');
    _editingId = null;
  }

  async function saveContact() {
    const name = document.getElementById('contact-name').value.trim();
    if (!name) { toast('Name is required', 'warning'); return; }

    const contact = {
      id:    _editingId,
      name,
      phone: document.getElementById('contact-phone').value.trim(),
      email: document.getElementById('contact-email').value.trim(),
    };

    await DB.saveContact(contact);
    toast(_editingId ? 'Contact updated' : 'Contact added', 'success');
    await refresh();
    hideForm();
  }

  async function deleteContact(id) {
    const c = _contacts.find(x => x.id === id);
    if (!c) return;
    if (!confirm(`Delete ${c.name}?`)) return;
    await DB.deleteContact(id);
    toast('Contact deleted', 'info');
    await refresh();
  }

  function callContact(phone) {
    if (!phone) return;
    window.location.href = `tel:${encodeURIComponent(phone)}`;
    toast(`Calling ${phone}…`, 'info');
  }

  async function refresh() {
    _contacts = await DB.getContacts();
    render();
  }

  function search(query) {
    const q = query.toLowerCase().trim();
    if (!q) { render(); return; }
    render(_contacts.filter(c =>
      c.name.toLowerCase().includes(q) ||
      (c.phone && c.phone.toLowerCase().includes(q)) ||
      (c.email && c.email.toLowerCase().includes(q))
    ));
  }

  function bindEvents() {
    document.getElementById('btn-add-contact').addEventListener('click', () => showForm());
    document.getElementById('btn-cancel-contact').addEventListener('click', hideForm);
    document.getElementById('btn-save-contact').addEventListener('click', saveContact);
    document.getElementById('contact-form-overlay').addEventListener('click', e => {
      if (e.target.id === 'contact-form-overlay') hideForm();
    });
    document.getElementById('search-contacts').addEventListener('input', e => search(e.target.value));

    document.getElementById('contacts-list').addEventListener('click', e => {
      const btn = e.target.closest('[data-action]');
      if (!btn) return;
      const action = btn.dataset.action;
      if (action === 'call')   callContact(btn.dataset.phone);
      if (action === 'delete') deleteContact(btn.dataset.id);
      if (action === 'edit') {
        const c = _contacts.find(x => x.id === btn.dataset.id);
        if (c) showForm(c);
      }
    });

    document.getElementById('contact-form-overlay').addEventListener('keydown', e => {
      if (e.key === 'Enter' && e.target.tagName === 'INPUT') {
        e.preventDefault();
        saveContact();
      }
    });
  }

  async function init() {
    await DB.init();
    bindEvents();
    await refresh();
  }

  return { init };
})();

document.addEventListener('DOMContentLoaded', () => App.init());
