
const AIS      = ["You","Claude","Gemini","GPT-4o","Grok"];
const INITIALS = { You:"You", Claude:"Cl", Gemini:"Ge", "GPT-4o":"GP", Grok:"Gr" };
let activeAI    = "Claude";
let msgCount    = 0;
let pendingFiles = [];
const thread    = [];

function getTime() {
  const d = new Date();
  return `${d.getHours()}:${String(d.getMinutes()).padStart(2,'0')}`;
}
function escHtml(s) {
  return s.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;");
}
function fmtBytes(b) {
  if (b < 1024) return b + ' B';
  if (b < 1024 * 1024) return (b / 1024).toFixed(1) + ' KB';
  return (b / (1024 * 1024)).toFixed(1) + ' MB';
}
function fileExt(name) {
  return name.includes('.') ? name.split('.').pop().toLowerCase() : '';
}
function contextFor(ai) {
  if (ai === "You") return thread;
  const lastIdx = [...thread].map(m => m.ai).lastIndexOf(ai);
  if (lastIdx === -1) return thread;
  return thread.slice(lastIdx + 1);
}
function updateCopyBar() {
  const label = document.getElementById("copyLabel");
  const btn   = document.getElementById("copyBtn");
  const msgs  = contextFor(activeAI);
  if (!msgs.length) {
    label.textContent = thread.length
      ? `${activeAI} has nothing new to read`
      : "No messages yet";
    btn.disabled = true;
  } else {
    const senders = [...new Set(msgs.map(m => m.ai))].join(" + ");
    label.textContent = activeAI === "You"
      ? `Full thread — ${msgs.length} message${msgs.length > 1 ? "s" : ""}`
      : `For ${activeAI}: ${msgs.length} new msg${msgs.length > 1 ? "s" : ""} from ${senders}`;
    btn.disabled = false;
  }
}
function switchIdentity(ai) {
  activeAI = ai;
  document.querySelectorAll(".id-btn").forEach(b =>
    b.classList.toggle("active", b.dataset.ai === ai)
  );
  document.getElementById("youChip").textContent =
    ai === "You" ? "Posting as yourself" : `You are ${ai}`;
  document.getElementById("chatInput").placeholder =
    ai === "You" ? "Say something…" : `Post as ${ai}…`;
  document.getElementById("inputWrap").dataset.ai = ai;
  document.getElementById("sendBtn").dataset.ai   = ai;
  updateCopyBar();
}
function postMessage(ai, text, files) {
  const filesArr = Array.isArray(files) && files.length ? files : [];
  document.getElementById("emptyState")?.remove();
  msgCount++;
  if (msgCount === 1) {
    const div = document.createElement("div");
    div.className = "day-divider";
    div.innerHTML = `<span>Today</span>`;
    document.getElementById("messages").appendChild(div);
  }
  thread.push({ ai, text, files: filesArr });
  const isMe  = ai === "You";
  const msgs  = document.getElementById("messages");
  const group = document.createElement("div");
  group.className = `msg-group ${isMe ? "from-me" : ""}`;
  const time  = getTime();
  let content = text ? escHtml(text) : '';
  filesArr.forEach(f => { content += renderAttachCard(f); });
  group.innerHTML = isMe
    ? `<div class="msg-col">
         <div class="bubble from-me" data-ai="${ai}">${content}</div>
         <div class="bubble-time">${time}</div>
       </div>
       <div class="msg-avatar" data-ai="${ai}">You</div>`
    : `<div class="msg-avatar" data-ai="${ai}">${INITIALS[ai]}</div>
       <div class="msg-col">
         <div class="msg-sender" data-ai="${ai}">${ai}</div>
         <div class="bubble from-other">${content}</div>
         <div class="bubble-time">${time}</div>
       </div>`;
  msgs.appendChild(group);
  msgs.scrollTop = msgs.scrollHeight;
  updateCopyBar();
}
function send() {
  const input = document.getElementById("chatInput");
  const text  = input.value.trim();
  if (!text && !pendingFiles.length) return;
  postMessage(activeAI, text, pendingFiles.slice());
  if (typeof GnokeHistory !== 'undefined') GnokeHistory.saveCurrentSession();
  input.value = "";
  input.style.height = "auto";
  clearAttachment();
}
document.getElementById("copyBtn").addEventListener("click", () => {
  const msgs = contextFor(activeAI);
  if (!msgs.length) return;
  const compiled = msgs.map(m => {
    let block = `[${m.ai}]`;
    if (m.text) block += `\n${m.text}`;
    if (m.files && m.files.length) block += '\n\n' + m.files.map(serializeFileForCopy).join('\n\n');
    return block;
  }).join('\n\n---\n\n');
  navigator.clipboard.writeText(compiled).then(() => {
    const btn = document.getElementById('copyBtn');
    btn.classList.add('done');
    btn.innerHTML = `<svg width="13" height="13" viewBox="0 0 24 24" fill="none"
      stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
      <polyline points="20 6 9 17 4 12"/></svg> Copied`;
    setTimeout(() => {
      btn.classList.remove('done');
      btn.innerHTML = `<svg width="13" height="13" viewBox="0 0 24 24" fill="none"
        stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <rect x="9" y="9" width="13" height="13" rx="2"/>
        <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/>
      </svg> Copy context`;
      updateCopyBar();
    }, 2000);
  });
});
document.querySelector(".identity-bar").addEventListener("click", e => {
  const btn = e.target.closest(".id-btn");
  if (btn) switchIdentity(btn.dataset.ai);
});
document.getElementById("sendBtn").addEventListener("click", send);
document.getElementById("chatInput").addEventListener("keydown", e => {
  if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); send(); }
});
document.getElementById("chatInput").addEventListener("input", function () {
  this.style.height = "auto";
  this.style.height = Math.min(this.scrollHeight, 120) + "px";
});

document.addEventListener('gnoke:boot', () => {
  if (window.gnokeSpirit) gnokeSpirit.wake('council');
});

switchIdentity("Claude");
