
const GnokeHistory = (() => {

  let _current = null;

  const makeId    = () => `s_${Date.now()}_${Math.random().toString(36).slice(2,6)}`;
  const titleFrom = (t) => {
    const src = t.find(m => m.ai === 'You' && m.text) || t.find(m => m.text);
    if (!src) return 'Untitled council';
    const words = src.text.trim().split(/\s+/);
    return words.slice(0, 6).join(' ') + (words.length > 6 ? '…' : '');
  };

  const saveCurrentSession = async () => {
    if (!thread.length) return;
    if (!_db()) return;   /* bus unavailable — skip silently */
    if (!_current) _current = makeId();
    window._gnoke_current_session = _current;
    await _db().sessions.put({
      id:      _current,
      title:   titleFrom(thread),
      ts:      Date.now(),
      thread:  JSON.parse(JSON.stringify(thread)),
      activeAI
    });
    document.dispatchEvent(new Event('gnoke:session-saved'));
  };

  const loadSession = (s) => {
    thread.length = 0;
    msgCount      = 0;
    _current      = s.id;
    window._gnoke_current_session = _current;
    const msgs = document.getElementById('messages');
    msgs.innerHTML = '';
    s.thread.forEach(m => postMessage(m.ai, m.text, m.files || (m.file ? [m.file] : [])));
    switchIdentity(s.activeAI || 'Claude');
    document.dispatchEvent(new Event('gnoke:session-saved'));
  };

  const newSession = () => {
    thread.length = 0;
    msgCount      = 0;
    _current      = null;
    window._gnoke_current_session = null;
    document.getElementById('messages').innerHTML = `
      <div class="empty-state" id="emptyState">
        <div class="empty-state-icon">⚡</div>
        <div class="empty-state-title">Council is ready</div>
        <div class="empty-state-sub">Tap <b>You</b> to speak as yourself, or tap an AI to relay their response</div>
      </div>`;
    document.getElementById('chatInput').value = '';
    switchIdentity('Claude');
    document.dispatchEvent(new Event('gnoke:session-saved'));
  };

  const autosave = () => { if (thread.length) saveCurrentSession(); };

  /* ── AppDB guard — safe even if bus unavailable ── */
  const _db = () => window.AppDB || null;

  const init = () => {
    newSession();
    window.addEventListener('visibilitychange', () => {
      if (document.visibilityState === 'hidden') autosave();
    });
    document.addEventListener('gnoke:new-session',   () => { autosave(); setTimeout(newSession, 60); });
    document.addEventListener('gnoke:load-session',   e  => loadSession(e.detail));
    document.addEventListener('gnoke:delete-session', async e => {
      if (!_db()) return;
      await _db().sessions.delete(e.detail);
      if (e.detail === _current) newSession();
      else document.dispatchEvent(new Event('gnoke:session-saved'));
    });
  };

  return {
    init,
    saveCurrentSession,
    newSession,
    dbGetAll: () => _db() ? _db().sessions.getAll() : Promise.resolve([]),
  };

})();

window.GnokeHistory = GnokeHistory;
/* init() is called by gnoke-presence.js after AppDB is ready */


