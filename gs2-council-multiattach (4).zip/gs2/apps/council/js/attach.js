
const ACCEPT_TYPES = [
  '.txt','.md','.html','.htm',
  '.css','.js','.jsx','.ts','.tsx',
  '.json','.php','.py','.java',
  '.c','.cpp','.cs','.xml',
  '.yaml','.yml','.sql','.sh',
  '.rb','.go','.rs','.swift',
  '.vue','.svelte','.toml',
  '.env','.gitignore','.csv'
].join(',');

function renderStrip() {
  const strip = document.getElementById('attachStrip');
  strip.innerHTML = '';
  if (!pendingFiles.length) { strip.classList.remove('visible'); return; }
  strip.classList.add('visible');
  pendingFiles.forEach((f, i) => {
    const chip = document.createElement('div');
    chip.className = 'attach-chip';
    chip.innerHTML = `
      <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>
      <span class="attach-chip-name">${escHtml(f.name)}</span>
      <span class="attach-chip-size">${fmtBytes(f.size)}</span>
      <button class="attach-chip-x" title="Remove">×</button>`;
    chip.querySelector('.attach-chip-x').addEventListener('click', () => {
      pendingFiles.splice(i, 1);
      renderStrip();
    });
    strip.appendChild(chip);
  });
}

function stageFiles(files) {
  let pending = files.length;
  Array.from(files).forEach(file => {
    if (!validateFile(file)) { pending--; return; }
    const reader = new FileReader();
    reader.onload = e => {
      pendingFiles.push({ name: file.name, size: file.size, content: e.target.result });
      pending--;
      if (pending === 0) renderStrip();
    };
    reader.onerror = () => { showAttachError('Could not read: ' + file.name); pending--; };
    reader.readAsText(file);
  });
}

function clearAttachment() {
  pendingFiles = [];
  document.getElementById('fileInput').value = '';
  renderStrip();
}

function showAttachError(msg) {
  const strip = document.getElementById('attachStrip');
  strip.classList.add('visible');
  const chip = document.createElement('div');
  chip.className = 'attach-chip';
  chip.innerHTML = `<span class="attach-chip-name">⚠ ${escHtml(msg)}</span>`;
  strip.appendChild(chip);
}

function renderAttachCard(file) {
  const lines   = file.content.split('\n').length;
  const preview = file.content.slice(0, 120).replace(/</g, '&lt;');
  const ext     = fileExt(file.name);
  return `<div class="attach-card">
    <div class="attach-card-head">
      <span class="attach-card-icon">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"
          stroke-linecap="round" stroke-linejoin="round" width="13" height="13">
          <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/>
          <polyline points="14 2 14 8 20 8"/>
        </svg>
      </span>
      <span class="attach-card-name">${escHtml(file.name)}</span>
      <span class="attach-card-meta">${ext ? '.' + ext + ' · ' : ''}${lines} lines · ${fmtBytes(file.size)}</span>
    </div>
    <div class="attach-card-preview">${preview}${file.content.length > 120 ? '…' : ''}</div>
  </div>`;
}

function serializeFileForCopy(file) {
  const ext = fileExt(file.name);
  return `[attachment: ${file.name}]\n\`\`\`${ext}\n${file.content}\n\`\`\``;
}

const MAX_SIZE = 500 * 1024;
function validateFile(file) {
  if (file.size > MAX_SIZE) { showAttachError(`Too large (max 500 KB): ${file.name}`); return false; }
  const ext = '.' + fileExt(file.name);
  if (!ACCEPT_TYPES.includes(ext)) { showAttachError(`Unsupported type: ${ext || 'unknown'}`); return false; }
  return true;
}

document.getElementById('attachBtn').addEventListener('click', () => {
  document.getElementById('fileInput').click();
});
document.getElementById('fileInput').addEventListener('change', e => {
  if (e.target.files.length) stageFiles(e.target.files);
});
document.getElementById('inputWrap').addEventListener('dragover', e => {
  e.preventDefault();
  e.currentTarget.classList.add('drag-over');
});
document.getElementById('inputWrap').addEventListener('dragleave', e => {
  e.currentTarget.classList.remove('drag-over');
});
document.getElementById('inputWrap').addEventListener('drop', e => {
  e.preventDefault();
  e.currentTarget.classList.remove('drag-over');
  if (e.dataTransfer.files.length) stageFiles(e.dataTransfer.files);
});
