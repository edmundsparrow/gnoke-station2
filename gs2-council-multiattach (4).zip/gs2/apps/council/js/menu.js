
(function () {
  document.body.insertAdjacentHTML('afterbegin', `
    <div class="sidebar-overlay" id="sidebarOverlay"></div>
    <aside class="sidebar" id="sidebar">
      <div class="sb-top">
        <button class="sb-icon-btn" id="sidebarToggle" title="Close menu">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <line x1="3" y1="6" x2="21" y2="6"/><line x1="3" y1="12" x2="21" y2="12"/><line x1="3" y1="18" x2="21" y2="18"/>
          </svg>
        </button>
        <span class="sb-brand">Council</span>
        <button class="sb-icon-btn sb-new-icon" id="newCouncilBtn" title="New council">
          <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
            <line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/>
          </svg>
        </button>
      </div>
      <div class="sb-search-wrap">
        <svg class="sb-search-icon" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
          <circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/>
        </svg>
        <input class="sb-search" id="sbSearch" placeholder="Search councils…" autocomplete="off"/>
        <button class="sb-search-clear" id="sbSearchClear" style="display:none">
          <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
            <line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>
          </svg>
        </button>
      </div>
      <div class="sb-list" id="chatList"></div>
    </aside>
  `);
  const topbar = document.querySelector('.topbar');
  if (topbar) {
    topbar.insertAdjacentHTML('afterbegin', `
      <button class="sb-icon-btn topbar-ham" id="topbarToggle" title="Menu">
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
          <line x1="3" y1="6" x2="21" y2="6"/><line x1="3" y1="12" x2="21" y2="12"/><line x1="3" y1="18" x2="21" y2="18"/>
        </svg>
      </button>
    `);
    const chip = topbar.querySelector('#youChip');
    if (chip) {
      chip.insertAdjacentHTML('beforebegin', `
        <button class="sb-icon-btn topbar-new" id="topbarNew" title="New council">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
            <line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/>
          </svg>
        </button>
      `);
    }
  }
  const css = document.createElement('style');
  css.textContent = `
    body { padding-left: 272px; transition: padding 0.22s cubic-bezier(.4,0,.2,1); }
    body.sb-off { padding-left: 0; }
    .sidebar {
      position: fixed; top: 0; left: 0; bottom: 0; width: 272px;
      background: var(--panel, #F7F7F9);
      border-right: 1px solid var(--border, #E0E0E8);
      display: flex; flex-direction: column;
      z-index: 300; overflow: hidden;
      transition: transform 0.22s cubic-bezier(.4,0,.2,1);
    }
    body.sb-off .sidebar { transform: translateX(-272px); }
    .sidebar-overlay {
      display: none; position: fixed; inset: 0;
      background: rgba(0,0,0,0.15); z-index: 290;
    }
    .sb-top {
      display: flex; align-items: center; gap: 4px;
      padding: 12px 10px 10px; flex-shrink: 0;
    }
    .sb-brand {
      flex: 1; font-size: 14px; font-weight: 600;
      color: var(--text); padding-left: 4px;
    }
    .sb-icon-btn {
      background: none; border: none; cursor: pointer;
      color: var(--muted); padding: 7px; border-radius: 8px;
      display: flex; align-items: center; justify-content: center;
      transition: background 0.13s, color 0.13s; flex-shrink: 0;
    }
    .sb-icon-btn:hover { background: var(--panel2, #EDEDF2); color: var(--text); }
    .sb-new-icon:hover svg { stroke: var(--accent); }
    .topbar-ham { margin-right: 4px; }
    .topbar-new { margin-right: 2px; }
    .topbar-new:hover svg { stroke: var(--accent); }
    .sb-search-wrap {
      position: relative; margin: 2px 10px 8px; flex-shrink: 0;
    }
    .sb-search-icon {
      position: absolute; left: 11px; top: 50%;
      transform: translateY(-50%); color: var(--muted2); pointer-events: none;
    }
    .sb-search {
      width: 100%; padding: 8px 30px 8px 32px;
      background: var(--bg, #fff);
      border: 1px solid var(--border, #E0E0E8);
      border-radius: 10px; font-family: var(--font);
      font-size: 13px; color: var(--text); outline: none;
      transition: border-color 0.15s; box-sizing: border-box;
    }
    .sb-search:focus { border-color: var(--accent, #3E51E6); }
    .sb-search::placeholder { color: var(--muted2); }
    .sb-search-clear {
      position: absolute; right: 9px; top: 50%;
      transform: translateY(-50%);
      background: none; border: none; cursor: pointer;
      color: var(--muted2); padding: 3px; border-radius: 4px;
      display: flex; align-items: center;
    }
    .sb-search-clear:hover { color: var(--text); }
    .sb-list {
      flex: 1; overflow-y: auto; padding: 0 6px 16px;
      scrollbar-width: thin; scrollbar-color: var(--border) transparent;
    }
    .sb-group {
      font-size: 10.5px; font-weight: 600; text-transform: uppercase;
      letter-spacing: 0.07em; color: var(--muted2);
      padding: 14px 8px 4px;
    }
    .sb-item {
      display: flex; align-items: center;
      border-radius: 10px; cursor: pointer; padding: 0 4px;
      margin-bottom: 1px; transition: background 0.12s; position: relative;
    }
    .sb-item:hover  { background: var(--panel2, #EDEDF2); }
    .sb-item.active { background: var(--panel2, #EDEDF2); }
    .sb-item.active::before {
      content: ''; position: absolute; left: 0; top: 6px; bottom: 6px;
      width: 2.5px; border-radius: 2px; background: var(--accent);
    }
    .sb-item-title {
      flex: 1; font-size: 13px; color: var(--text);
      white-space: nowrap; overflow: hidden; text-overflow: ellipsis;
      padding: 9px 6px 9px 10px; line-height: 1.3; user-select: none;
    }
    .sb-item-actions {
      display: flex; align-items: center; gap: 1px;
      opacity: 0; transition: opacity 0.14s; padding-right: 2px; flex-shrink: 0;
    }
    .sb-item:hover  .sb-item-actions { opacity: 1; }
    .sb-item.active .sb-item-actions { opacity: 1; }
    .sb-act-btn {
      background: none; border: none; cursor: pointer;
      color: var(--muted2); padding: 5px; border-radius: 6px;
      display: flex; align-items: center;
      transition: background 0.12s, color 0.12s;
    }
    .sb-act-btn:hover { background: var(--border, #E0E0E8); color: var(--text); }
    .sb-act-btn.pinned svg { fill: var(--accent); stroke: var(--accent); }
    .sb-act-btn.del:hover  { color: #D93025; }
    .sb-pin-badge {
      display: inline-flex; align-items: center;
      margin-right: 5px; color: var(--accent); flex-shrink: 0;
    }
    .sb-empty {
      font-size: 12.5px; color: var(--muted2);
      padding: 32px 16px; text-align: center; line-height: 1.7;
    }
    .sb-new-hint {
      display: flex; align-items: center; gap: 8px;
      margin: 6px 6px 2px; padding: 9px 12px;
      border-radius: 10px; border: 1.5px dashed var(--border2);
      cursor: pointer; transition: border-color 0.15s, background 0.15s;
    }
    .sb-new-hint:hover {
      border-color: var(--accent); background: rgba(62,81,230,.04);
    }
    .sb-new-hint-icon {
      width: 22px; height: 22px; border-radius: 6px;
      background: var(--accent); display: flex; align-items: center;
      justify-content: center; flex-shrink: 0;
    }
    .sb-new-hint-icon svg { stroke: #fff; }
    .sb-new-hint-label {
      font-size: 12.5px; font-weight: 500; color: var(--muted);
    }
    .sb-toast {
      position: fixed; bottom: 76px; left: 50%;
      transform: translateX(-50%);
      background: var(--text); color: var(--bg);
      font-family: var(--font); font-size: 12px;
      padding: 7px 16px; border-radius: 8px;
      opacity: 0; pointer-events: none;
      transition: opacity 0.18s; z-index: 9999; white-space: nowrap;
    }
    .sb-toast.show { opacity: 1; }
    @media (max-width: 768px) {
      body { padding-left: 0 !important; }
      .sidebar { transform: translateX(-272px); }
      body.sb-open .sidebar  { transform: translateX(0); }
      body.sb-open .sidebar-overlay { display: block; }
    }
  `;
  document.head.appendChild(css);
  const MAX_PINS = 7;
  /* Pins persisted in AppDB (IDB) — replaces localStorage */
  const getPins  = async () => {
    try { return (await AppDB.get('pins')) || []; } catch { return []; }
  };
  const savePins = async (ids) => {
    try { await AppDB.put('pins', ids); } catch {}
  };
  const togglePin = async (id) => {
    const pins = await getPins();
    const idx  = pins.indexOf(id);
    if (idx > -1) { pins.splice(idx, 1); await savePins(pins); return true; }
    if (pins.length >= MAX_PINS) { showToast(`Max ${MAX_PINS} pinned`); return false; }
    pins.unshift(id); await savePins(pins); return true;
  };
  const toast = Object.assign(document.createElement('div'), { className: 'sb-toast' });
  document.body.appendChild(toast);
  let _tt;
  const showToast = (msg) => {
    clearTimeout(_tt); toast.textContent = msg;
    toast.classList.add('show');
    _tt = setTimeout(() => toast.classList.remove('show'), 2200);
  };
  const groupOf = (ts) => {
    const d = (Date.now() - ts) / 864e5;
    if (d < 1)  return 'Today';
    if (d < 2)  return 'Yesterday';
    if (d < 7)  return 'Previous 7 days';
    if (d < 30) return 'Previous 30 days';
    return new Date(ts).toLocaleString('default', { month: 'long', year: 'numeric' });
  };
  const PIN_SVG = `<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
    <line x1="12" y1="17" x2="12" y2="22"/><path d="M5 17h14v-1.76a2 2 0 0 0-1.11-1.79l-1.78-.9A2 2 0 0 1 15 10.76V6h1a2 2 0 0 0 0-4H8a2 2 0 0 0 0 4h1v4.76a2 2 0 0 1-1.11 1.79l-1.78.9A2 2 0 0 0 5 15.24Z"/>
  </svg>`;
  const DEL_SVG = `<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
    <polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14H6L5 6"/><path d="M10 11v6"/><path d="M14 11v6"/><path d="M9 6V4h6v2"/>
  </svg>`;
  let _query = '';
  const render = async () => {
    const list = document.getElementById('chatList');
    if (!list) return;
    const sessions  = await GnokeHistory.dbGetAll();
    const pins      = await getPins();
    const currentId = window._gnoke_current_session || null;
    const q         = _query.trim().toLowerCase();
    const filtered = q
      ? sessions.filter(s => s.title.toLowerCase().includes(q))
      : sessions;
    filtered.sort((a, b) => b.ts - a.ts);
    list.innerHTML = '';
    if (!q) {
      const hint = document.createElement('div');
      hint.className = 'sb-new-hint';
      hint.innerHTML = `
        <div class="sb-new-hint-icon">
          <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round">
            <line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/>
          </svg>
        </div>
        <span class="sb-new-hint-label">New council</span>`;
      hint.addEventListener('click', () => {
        document.dispatchEvent(new Event('gnoke:new-session'));
        if (window.innerWidth <= 768) closeSidebar();
      });
      list.appendChild(hint);
    }
    if (!filtered.length) {
      list.innerHTML += `<div class="sb-empty">${q ? `Nothing matching "<b>${q}</b>"` : 'No previous councils yet.'}</div>`;
      return;
    }
    const pinned  = filtered.filter(s =>  pins.includes(s.id));
    const recents = filtered.filter(s => !pins.includes(s.id));
    const makeItem = (s) => {
      const isPinned = pins.includes(s.id);
      const isActive = s.id === currentId;
      const el       = document.createElement('div');
      el.className   = `sb-item${isActive ? ' active' : ''}`;
      el.dataset.id  = s.id;
      el.innerHTML = `
        <span class="sb-item-title">
          ${isPinned ? `<span class="sb-pin-badge">${PIN_SVG}</span>` : ''}
          ${escHtml(s.title)}
        </span>
        <div class="sb-item-actions">
          <button class="sb-act-btn pin-btn${isPinned ? ' pinned' : ''}" title="${isPinned ? 'Unpin' : 'Pin to top'}">${PIN_SVG}</button>
          <button class="sb-act-btn del del-btn" title="Delete">${DEL_SVG}</button>
        </div>`;
      el.addEventListener('click', e => {
        if (e.target.closest('.sb-act-btn')) return;
        document.dispatchEvent(new CustomEvent('gnoke:load-session', { detail: s }));
        if (window.innerWidth <= 768) closeSidebar();
      });
      el.querySelector('.pin-btn').addEventListener('click', async e => {
        e.stopPropagation();
        const changed = await togglePin(s.id);
        if (changed) {
          const isPinnedNow = (await getPins()).includes(s.id);
          showToast(isPinnedNow ? 'Pinned to top' : 'Unpinned');
        }
        render();
      });
      el.querySelector('.del-btn').addEventListener('click', async e => {
        e.stopPropagation();
        if (isPinned) { const p = await getPins(); await savePins(p.filter(id => id !== s.id)); }
        document.dispatchEvent(new CustomEvent('gnoke:delete-session', { detail: s.id }));
        showToast('Council deleted');
      });
      return el;
    };
    if (pinned.length && !q) {
      list.appendChild(Object.assign(document.createElement('div'), { className: 'sb-group', textContent: 'Pinned' }));
      pinned.forEach(s => list.appendChild(makeItem(s)));
    }
    if (recents.length) {
      const groups = {};
      recents.forEach(s => { const g = groupOf(s.ts); (groups[g] = groups[g] || []).push(s); });
      Object.entries(groups).forEach(([label, items]) => {
        list.appendChild(Object.assign(document.createElement('div'), { className: 'sb-group', textContent: label }));
        items.forEach(s => list.appendChild(makeItem(s)));
      });
    }
  };
  const closeSidebar = () => {
    if (window.innerWidth > 768) document.body.classList.add('sb-off');
    else document.body.classList.remove('sb-open');
  };
  const openSidebar = () => {
    if (window.innerWidth > 768) document.body.classList.remove('sb-off');
    else document.body.classList.add('sb-open');
  };
  const toggleSidebar = () => {
    if (window.innerWidth > 768) document.body.classList.toggle('sb-off');
    else document.body.classList.toggle('sb-open');
  };
  document.getElementById('sidebarToggle').addEventListener('click', toggleSidebar);
  document.getElementById('topbarToggle')?.addEventListener('click', toggleSidebar);
  document.getElementById('sidebarOverlay').addEventListener('click', closeSidebar);
  const newSession = () => {
    document.dispatchEvent(new Event('gnoke:new-session'));
    if (window.innerWidth <= 768) closeSidebar();
  };
  document.getElementById('newCouncilBtn').addEventListener('click', newSession);
  document.getElementById('topbarNew')?.addEventListener('click', newSession);
  const searchEl = document.getElementById('sbSearch');
  const clearEl  = document.getElementById('sbSearchClear');
  searchEl.addEventListener('input', () => {
    _query = searchEl.value;
    clearEl.style.display = _query ? 'flex' : 'none';
    render();
  });
  clearEl.addEventListener('click', () => {
    searchEl.value = _query = '';
    clearEl.style.display = 'none';
    render(); searchEl.focus();
  });
  document.addEventListener('gnoke:session-saved', render);
  const waitForHistory = () => {
    if (typeof GnokeHistory !== 'undefined') { render(); return; }
    setTimeout(waitForHistory, 30);
  };
  waitForHistory();
})();

