
# Gnöke Council — Source Commentary Reference

> All inline comments extracted from every Council source file.
> Collapsible per file. Companion to the clean codebase.

---

## Table of Contents

### Entry
- [index.html](#indexhtml) — App Entry Point & Layout

### Core Logic
- [core.js](#corejs) — State, UI, Identity & Send Logic
- [attach.js](#attachjs) — File Attachment & Drag-Drop
- [history.js](#historyjs) — Session Persistence via AppDB

### UI
- [menu.js](#menujs) — Sidebar, Search & Session Navigation
- [styles.css](#stylescss) — Visual Design & Layout Tokens

### Firmware
- [gnoke-presence.js](#gnoke-presencejs) — Bus Registration & AppDB Init

---

## Entry

<details><summary><strong>index.html</strong> &nbsp;·&nbsp; App Entry Point & Layout</summary>

**Note 1**
```
Single script tag — /sys2026/boot.js owns the full load order:
  gnoke-client.js → gnoke-syscall.js → gnoke-core.js →
  sysdb.js → gnoke-spirit.js → [app scripts] → gnoke-presence.js

App scripts declared via meta tag:
  <meta name="gnoke:scripts" content="js/core.js,js/attach.js,js/history.js,js/menu.js">
```

</details>

---

## Core Logic

<details><summary><strong>js/core.js</strong> &nbsp;·&nbsp; State, UI, Identity & Send Logic</summary>

**Note 1**
```
core.js — Gnoke Council
Owns all shared state, message rendering, identity switching, and send logic.
Exposes globals consumed by attach.js, history.js, and menu.js:
  thread       — live message array
  activeAI     — currently selected identity
  msgCount     — total messages in current session
  pendingFile  — staged attachment object or null
  postMessage()
  switchIdentity()
  escHtml()
  fmtBytes()
  fileExt()

Load order (via boot.js):
  gnoke-spirit.js → core.js → attach.js → history.js → menu.js
```

#### ── Constants ──────────────────────────────────────────
> _Precedes:_ `const AIS = ["You","Claude","Gemini","GPT-4o","Grok"];`

#### ── State ──────────────────────────────────────────────
> _Precedes:_ `let activeAI = "Claude";`

#### ── Time ───────────────────────────────────────────────
> _Precedes:_ `function getTime() {`

#### ── HTML escape ────────────────────────────────────────
> _Precedes:_ `function escHtml(s) {`

#### ── File utils ─────────────────────────────────────────
> _Precedes:_ `function fmtBytes(b) {`

#### ── Context logic ──────────────────────────────────────
> _Precedes:_ `function contextFor(ai) {`

#### ── Copy bar ───────────────────────────────────────────
> _Precedes:_ `function updateCopyBar() {`

#### ── Identity ───────────────────────────────────────────
> _Precedes:_ `function switchIdentity(ai) {`

#### ── Render: message bubble ─────────────────────────────
> _Precedes:_ `function postMessage(ai, text, file) {`

#### ── Send ───────────────────────────────────────────────
> _Precedes:_ `function send() {`

#### ── Copy context ───────────────────────────────────────
> _Precedes:_ `document.getElementById("copyBtn").addEventListener("click", () => {`

#### ── Identity bar ───────────────────────────────────────
> _Precedes:_ `document.querySelector(".identity-bar").addEventListener("click", e => {`

#### ── Send events ────────────────────────────────────────
> _Precedes:_ `document.getElementById("sendBtn").addEventListener("click", send);`

#### ── Spirit wake ────────────────────────────────────────
```
Fires on gnoke:boot after the full firmware sequence completes.
gnokeSpirit.wake('council') restores any draft text the user
was typing before the tab closed or the browser was killed.
Spirit captures all textarea/input values automatically —
no manual syncState calls needed.
```
> _Precedes:_ `document.addEventListener('gnoke:boot', () => {`

#### ── Init ───────────────────────────────────────────────
> _Precedes:_ `switchIdentity("Claude");`

</details>

<details><summary><strong>js/attach.js</strong> &nbsp;·&nbsp; File Attachment & Drag-Drop</summary>

**Note 1**
```
attach.js — Gnoke Council
File attachment: staging, clearing, card render,
copy serialisation, drag-drop + input events.
Depends on globals from core.js: pendingFile, escHtml, fmtBytes, fileExt
```

#### Accepted text-readable formats
> _Precedes:_ `const ACCEPT_TYPES = [`

#### ── Stage a file into pendingFile ─────────────────────
> _Precedes:_ `function stageFile(file) {`

#### ── Clear staged file ──────────────────────────────────
> _Precedes:_ `function clearAttachment() {`

#### ── Inline error inside strip ──────────────────────────
> _Precedes:_ `function showAttachError(msg) {`

#### ── Render attach card inside a bubble ─────────────────
> _Precedes:_ `function renderAttachCard(file) {`

#### ── Serialise a file for copy-context export ──────────
> _Precedes:_ `function serializeFileForCopy(file) {`

#### ── Guard: reject non-text / oversized files ──────────
```
MAX_SIZE = 500 KB. Files larger than this are rejected before
FileReader runs — avoids memory pressure on mobile.
```
> _Precedes:_ `const MAX_SIZE = 500 * 1024;`

#### ── Events ──────────────────────────────────────────────
> _Precedes:_ `document.getElementById('attachBtn').addEventListener('click', () => {`

#### Drag and drop onto input wrap
> _Precedes:_ `document.getElementById('inputWrap').addEventListener('dragover', e => {`

</details>

<details><summary><strong>js/history.js</strong> &nbsp;·&nbsp; Session Persistence via AppDB</summary>

**Note 1**
```
history.js — Gnoke Council
Owns session persistence for Council threads.
Storage: AppDB.sessions (GnokeSysDB namespaced under 'council').
AppDB is provided by gnoke-presence.js after Gnoke.ready() resolves —
no manual IDB open needed here.

Session shape:
  { id, title, ts, thread: [{ ai, text, file }], activeAI }

Title is auto-derived from the first message by 'You', falling
back to the first message of any identity (max 6 words).

Autosave fires on visibilitychange (tab hidden / browser kill).
GnokeHistory is exposed on window for menu.js to call dbGetAll().
```

#### ── ID + title helpers ──────────────────────────────────
> _Precedes:_ `const makeId = () =>`

#### ── Save ────────────────────────────────────────────────
> _Precedes:_ `const saveCurrentSession = async () => {`

#### ── Load ────────────────────────────────────────────────
> _Precedes:_ `const loadSession = (s) => {`

#### ── New ─────────────────────────────────────────────────
> _Precedes:_ `const newSession = () => {`

#### ── Autosave on visibility hidden ─────────────────────
> _Precedes:_ `const autosave = () => {`

#### ── Init ────────────────────────────────────────────────
```
init() is synchronous — no openDB() call needed since AppDB
is already open when gnoke-presence.js completes boot.
Events wired:
  gnoke:new-session    — autosave current, then clear after 60ms
  gnoke:load-session   — replay thread from saved session object
  gnoke:delete-session — remove from AppDB, clear view if active
```
> _Precedes:_ `const init = () => {`

</details>

---

## UI

<details><summary><strong>js/menu.js</strong> &nbsp;·&nbsp; Sidebar, Search & Session Navigation</summary>

#### ── Inject sidebar HTML ──────────────────────────────
> _Precedes:_ `document.body.insertAdjacentHTML('afterbegin', \``

#### ── Inject topbar hamburger + new chat button ────────
> _Precedes:_ `const topbar = document.querySelector('.topbar');`

#### + button in topbar (right side, before the youChip)
> _Precedes:_ `const chip = topbar.querySelector('#youChip');`

#### ── Styles ───────────────────────────────────────────
> _Precedes:_ `const css = document.createElement('style');`

#### ── Pins (AppDB / IDB, max 7) ────────────────────────
> _Precedes:_ `const MAX_PINS = 7;`

#### ── Toast ────────────────────────────────────────────
> _Precedes:_ `const toast = Object.assign(document.createElement('div'), { className: 'sb-toast' });`

#### ── Date group labels ────────────────────────────────
> _Precedes:_ `const groupOf = (ts) => {`

#### ── SVGs ─────────────────────────────────────────────
> _Precedes:_ `const PIN_SVG = \`<svg ...\``

#### ── Render ───────────────────────────────────────────
> _Precedes:_ `let _query = '';`

#### ── New council shortcut (only when no search) ───────
> _Precedes:_ `if (!q) {`

#### Pinned section
> _Precedes:_ `if (pinned.length && !q) {`

#### Recents grouped by date
> _Precedes:_ `if (recents.length) {`

#### ── Sidebar open/close ───────────────────────────────
> _Precedes:_ `const closeSidebar = () => {`

#### ── Events ───────────────────────────────────────────
> _Precedes:_ `document.getElementById('sidebarToggle').addEventListener('click', toggleSidebar);`

#### Both + buttons trigger new session
> _Precedes:_ `const newSession = () => {`

#### ── Boot — waits for GnokeHistory before first render ─
```
Polls every 30ms until GnokeHistory is defined on window.
GnokeHistory is set by history.js which loads before menu.js
in the boot sequence — this guard handles any async lag.
```
> _Precedes:_ `const waitForHistory = () => {`

</details>

<details><summary><strong>styles.css</strong> &nbsp;·&nbsp; Visual Design & Layout Tokens</summary>

#### AI brand colours
> _Precedes:_ `--c-claude: #D66A2C;`

#### Light palette
> _Precedes:_ `--bg: #FFFFFF;`

#### Typography
> _Precedes:_ `--font: 'Google Sans', 'Google Sans Text', system-ui, sans-serif;`

#### TOPBAR
> _Precedes:_ `.topbar {`

#### IDENTITY BAR
> _Precedes:_ `.identity-bar {`

#### Coloured dot per identity
> _Precedes:_ `.id-dot {`

#### Active border matches AI colour
> _Precedes:_ `.id-btn.active[data-ai="Claude"] { border-color: var(--c-claude); }`

#### MESSAGES
> _Precedes:_ `.messages {`

#### Empty state
> _Precedes:_ `.empty-state {`

#### Day divider
> _Precedes:_ `.day-divider {`

#### Message groups
> _Precedes:_ `.msg-group {`

#### Avatar
> _Precedes:_ `.msg-avatar {`

#### Message column
> _Precedes:_ `.msg-col {`

#### Sender label
> _Precedes:_ `.msg-sender {`

#### Bubbles
> _Precedes:_ `.bubble {`

#### INPUT AREA
> _Precedes:_ `.input-area {`

#### Copy bar
> _Precedes:_ `.copy-bar {`

#### Attachment strip — staged file preview
> _Precedes:_ `.attach-strip {`

#### Input row
> _Precedes:_ `.input-row {`

#### Attach button inside input
> _Precedes:_ `.attach-btn {`

#### Send button
> _Precedes:_ `.send-btn {`

#### ATTACHMENT CARD (in bubble)
> _Precedes:_ `.attach-card {`

#### Attach card inside from-me bubble
> _Precedes:_ `.bubble.from-me .attach-card { border-color: rgba(255,255,255,.2); }`

#### MOBILE
> _Precedes:_ `@media (max-width: 600px) {`

</details>

---

## Firmware

<details><summary><strong>gnoke-presence.js</strong> &nbsp;·&nbsp; Bus Registration & AppDB Init</summary>

**Note 1**
```
Standard Gnoke presence template — v1.1.0
Copied from help/presence.js. Only APP_ID changes per app.

Responsibilities:
  1. Call Gnoke.ready() to register council on the system bus.
  2. Open window.AppDB = GnokeSysDB('council') — namespaced storage
     used by history.js for session persistence.
  3. Drive the sys-pill indicator (live / error / connecting).
  4. Guard against double-boot if another script already called boot().

Load order (managed by /sys2026/boot.js):
  gnoke-client.js → gnoke-syscall.js → gnoke-core.js →
  sysdb.js → gnoke-spirit.js → [app scripts] → gnoke-presence.js
```

#### ── Three fields to adjust per app ─────────────────────
> _Precedes:_ `const APP_ID = 'council';`

#### ── Guard ────────────────────────────────────────────
> _Precedes:_ `if (window.GnokeClient?.ready) {`

#### ── Boot ─────────────────────────────────────────────
> _Precedes:_ `await Gnoke.ready({`

</details>

---

_Gnöke Council — Multi-AI thread relay. Comments extracted from runtime files._
