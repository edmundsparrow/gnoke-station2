'use strict';

/* ─────────────────────────────────────────────────────────────
   notes-ui.js — v2.0.0
   Gnoke Notes — UI layer: DOM, events, IDB load/save, bus
   Edmund Sparrow © 2026 — MIT

   LOAD ORDER (boot.js meta tag):
     notes-data.js → notes-ui.js
   gnoke-presence.js loads after via boot.js and fires gnoke:boot
   ───────────────────────────────────────────────────────────── */

/* ── DOM refs ───────────────────────────────────────────────── */
const editor       = document.getElementById('editor');
const gutter       = document.getElementById('gutter');
const editorWrap   = document.getElementById('editorWrap');
const paneEdit     = document.getElementById('paneEdit');
const panePreview  = document.getElementById('panePreview');
const paneHistory  = document.getElementById('paneHistory');
const mdBody       = document.getElementById('mdBody');
const tbFilename      = document.getElementById('tbFilename');
const tbFilenameInput = document.getElementById('tbFilenameInput');
const findBar      = document.getElementById('findBar');
const findInput    = document.getElementById('findInput');
const replaceInput = document.getElementById('replaceInput');
const findCount    = document.getElementById('findCount');
const toastEl      = document.getElementById('toast');

/* ── Toast ──────────────────────────────────────────────────── */
let _tTimer = null;
function toast(msg, type = '', ms = 2200) {
  toastEl.textContent = msg;
  toastEl.className = `toast show${type ? ' ' + type : ''}`;
  clearTimeout(_tTimer);
  _tTimer = setTimeout(() => toastEl.classList.remove('show'), ms);
}

/* ── Dirty flag ─────────────────────────────────────────────── */
function setDirty(v) {
  S.dirty = v;
  tbFilename.className = `tb-filename${v ? ' dirty' : ''}`;
  const sbSave = document.getElementById('sbSave');
  sbSave.textContent = v ? '● unsaved' : 'saved';
  sbSave.className   = `sb-item${v ? ' sb-warn' : ''}`;
}

/* ── Status bar ─────────────────────────────────────────────── */
function updateStatus() {
  const txt   = editor.value;
  const lines = txt.split('\n').length;
  const words = txt.trim() ? txt.trim().split(/\s+/).length : 0;
  const chars = txt.length;
  document.getElementById('sbLines').textContent = `${lines} line${lines !== 1 ? 's' : ''}`;
  document.getElementById('sbWords').textContent = `${words} word${words !== 1 ? 's' : ''}`;
  document.getElementById('sbChars').textContent = `${chars} char${chars !== 1 ? 's' : ''}`;
  const extLabels = { md:'Markdown', txt:'Plain Text', html:'HTML', css:'CSS',
                      js:'JavaScript', php:'PHP', csv:'CSV', sql:'SQL', json:'JSON' };
  document.getElementById('sbMode').textContent = extLabels[S.ext] || S.ext.toUpperCase();
}

/* ── Cursor ─────────────────────────────────────────────────── */
function updateCursor() {
  const before = editor.value.substring(0, editor.selectionStart);
  const ln  = before.split('\n').length;
  const col = before.split('\n').pop().length + 1;
  document.getElementById('sbCursor').textContent = `Ln ${ln}, Col ${col}`;
}

/* ── Gutter ─────────────────────────────────────────────────── */
function updateGutter() {
  if (!S.lineNums) { gutter.style.display = 'none'; return; }
  gutter.style.display = 'block';
  const lines = editor.value.split('\n').length;
  let html = '';
  for (let i = 1; i <= lines; i++) html += `<span class="gutter-line">${i}</span>`;
  gutter.innerHTML = html;
}

/* ── Preview ────────────────────────────────────────────────── */
function refreshPreview() {
  if (S.view === 'write') return;
  const txt = editor.value;
  if (S.ext === 'csv') {
    mdBody.innerHTML = renderCSV(txt);
  } else if (['md', 'txt'].includes(S.ext)) {
    mdBody.innerHTML = `<div>${renderMarkdown(txt)}</div>`;
  } else {
    mdBody.innerHTML = `<pre style="font-family:var(--mono);font-size:12px;line-height:1.65;
      color:var(--text);white-space:pre-wrap;word-break:break-all">${escHtml(txt)}</pre>`;
  }
}

/* ── View mode ──────────────────────────────────────────────── */
function setView(v) {
  S.view = v;
  paneEdit.style.display    = v === 'write' ? 'flex' : 'none';
  panePreview.className      = `pane-preview${v === 'preview' ? ' visible' : ''}`;
  paneHistory.className      = `pane-history${v === 'history' ? ' visible' : ''}`;
  ['viewEdit', 'viewPreview', 'viewHistory'].forEach(id => {
    const el = document.getElementById(id);
    if (el) el.classList.remove('active');
  });
  const map = { write: 'viewEdit', preview: 'viewPreview', history: 'viewHistory' };
  if (map[v]) document.getElementById(map[v]).classList.add('active');
  if (v === 'preview') refreshPreview();
  if (v === 'history') refreshHistory();
}

/* ── Load content into editor ───────────────────────────────── */
function loadContent(text, filename) {
  editor.value   = text;
  S.content      = text;
  S.filename     = filename;
  S.ext          = extFrom(filename);
  tbFilename.textContent    = filename;
  tbFilenameInput.value     = filename;
  setDirty(false);
  updateGutter();
  updateStatus();
  refreshPreview();
  toast(`Opened: ${filename}`, 'ok');
  if (S.ext === 'csv') setView('preview');
}

/* ── New ────────────────────────────────────────────────────── */
function newFile() {
  if (S.dirty && !confirm('Unsaved changes — discard and start new?')) return;
  editor.value         = '';
  S.content            = '';
  S.filename           = 'untitled.md';
  S.ext                = 'md';
  S.currentId          = null;
  tbFilename.textContent    = S.filename;
  tbFilenameInput.value     = S.filename;
  setDirty(false);
  updateGutter();
  updateStatus();
  refreshPreview();
  editor.focus();
}

/* ── IDB save ────────────────────────────────────────────────── */
async function saveToIDB() {
  try {
    const title = S.filename;
    const id = await NotesDB.saveNote(S.currentId, title, editor.value);
    if (id) {
      S.currentId = id;
      setDirty(false);
      toast('Saved to notes', 'ok');
      document.dispatchEvent(new Event('gnoke:notes-saved'));
    } else {
      toast('No DB — use Save As', 'err');
    }
  } catch (e) {
    console.warn('[notes] IDB save failed:', e.message);
    toast('Save failed', 'err');
  }
}

/* ── History (saved notes, council-style) ─────────────────── */
const histList = document.getElementById('histList');

async function refreshHistory() {
  const notes = await NotesDB.loadNotes();
  notes.sort((a, b) => b.ts - a.ts);
  histList.innerHTML = '';
  if (!notes.length) {
    histList.innerHTML = '<div class="hist-empty">No saved notes yet — Save to Notes to start your history.</div>';
    return;
  }
  notes.forEach(n => {
    const row = document.createElement('div');
    row.className = `hist-row${n.id === S.currentId ? ' current' : ''}`;
    const ext = extFrom(n.filename || 'untitled.md');
    const icon = { md:'📝', txt:'📄', html:'🌐', css:'🎨', js:'📜',
                    php:'🐘', csv:'📊', sql:'🗄', json:'🔧' }[ext] || '📄';
    row.innerHTML = `
      <span class="hr-icon">${icon}</span>
      <span class="hr-name">${escHtml(n.filename || 'untitled.md')}</span>
      <span class="hr-meta">${new Date(n.ts).toLocaleString()}</span>
      <button class="hr-del" title="Delete">🗑</button>`;
    row.addEventListener('click', e => {
      if (e.target.closest('.hr-del')) return;
      if (S.dirty && !confirm('Unsaved changes — discard and open?')) return;
      S.currentId = n.id;
      loadContent(n.content || '', n.filename || 'untitled.md');
      setView('write');
    });
    row.querySelector('.hr-del').addEventListener('click', async e => {
      e.stopPropagation();
      if (!confirm(`Delete "${n.filename}"?`)) return;
      await NotesDB.deleteNote(n.id);
      if (S.currentId === n.id) S.currentId = null;
      refreshHistory();
      toast('Deleted', 'ok');
    });
    histList.appendChild(row);
  });
}

/* ── Markdown format helpers ────────────────────────────────── */
function wrap(before, after) {
  if (!after) after = before;
  const s   = editor.selectionStart;
  const e   = editor.selectionEnd;
  const sel = editor.value.substring(s, e) || 'text';
  editor.setRangeText(before + sel + after, s, e, 'select');
  editor.focus();
  setDirty(true);
}
function insertLine(prefix) {
  const s     = editor.selectionStart;
  const lineStart = editor.value.substring(0, s).lastIndexOf('\n') + 1;
  editor.setRangeText(prefix, lineStart, lineStart, 'end');
  editor.focus();
  setDirty(true);
}
function insertSnippet(snippet) {
  const s = editor.selectionStart;
  editor.setRangeText(snippet, s, s, 'end');
  editor.focus();
  setDirty(true);
}

/* ── Find & Replace ─────────────────────────────────────────── */
let _findMatches = [], _findIdx = -1;

function openFind() {
  S.findOpen = true;
  findBar.classList.add('open');
  findInput.focus();
  findInput.select();
}
function closeFind() {
  S.findOpen = false;
  findBar.classList.remove('open');
  editor.focus();
}
function doFind(dir = 1) {
  const q = findInput.value;
  if (!q) { findCount.textContent = ''; return; }
  const re = new RegExp(q.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'gi');
  _findMatches = [...editor.value.matchAll(re)].map(m => m.index);
  findCount.textContent = _findMatches.length
    ? `${_findMatches.length} match${_findMatches.length !== 1 ? 'es' : ''}`
    : 'no match';
  if (!_findMatches.length) return;
  _findIdx = (_findIdx + dir + _findMatches.length) % _findMatches.length;
  const pos = _findMatches[_findIdx];
  editor.focus();
  editor.setSelectionRange(pos, pos + q.length);
  const lineH = parseFloat(getComputedStyle(editor).lineHeight);
  editor.scrollTop = (editor.value.substring(0, pos).split('\n').length - 3) * lineH;
}
function doReplace(all = false) {
  const q = findInput.value;
  const r = replaceInput.value;
  if (!q) return;
  if (all) {
    editor.value = editor.value.split(q).join(r);
    setDirty(true);
    updateGutter(); updateStatus(); refreshPreview();
    toast('Replaced all', 'ok');
  } else {
    const pos = _findMatches[_findIdx];
    if (pos === undefined) return;
    editor.setRangeText(r, pos, pos + q.length, 'end');
    setDirty(true);
    doFind(1);
  }
}

/* ── Wire events ────────────────────────────────────────────── */
editor.addEventListener('input', () => {
  S.content = editor.value;
  setDirty(true);
  updateGutter();
  updateStatus();
  refreshPreview();
});
editor.addEventListener('keyup',   updateCursor);
editor.addEventListener('click',   updateCursor);
editor.addEventListener('scroll',  () => { gutter.scrollTop = editor.scrollTop; });
editor.addEventListener('keydown', e => {
  if (e.key === 'Tab') {
    e.preventDefault();
    const s = editor.selectionStart, en = editor.selectionEnd;
    editor.setRangeText('  ', s, en, 'end');
    setDirty(true);
  }
});

document.getElementById('fontSize').addEventListener('change', e => {
  S.fontSize = parseInt(e.target.value);
  editor.style.fontSize = S.fontSize + 'px';
  updateGutter();
});

/* File */
document.getElementById('btnNew').addEventListener('click',  newFile);
document.getElementById('btnHistory').addEventListener('click', () => setView('history'));
document.getElementById('btnSaveIDB').addEventListener('click', saveToIDB);
document.getElementById('btnClear').addEventListener('click', () => {
  if (editor.value && !confirm('Clear all content?')) return;
  editor.value = ''; S.content = '';
  setDirty(true); updateGutter(); updateStatus(); refreshPreview();
});

/* Edit */
document.getElementById('btnCopyAll').addEventListener('click', () => {
  navigator.clipboard.writeText(editor.value).then(() => toast('Copied', 'ok'));
});
document.getElementById('btnSelectAll').addEventListener('click', () => {
  editor.focus(); editor.select();
});

/* Format */
document.getElementById('fmtBold').addEventListener('click',   () => wrap('**'));
document.getElementById('fmtItalic').addEventListener('click', () => wrap('*'));
document.getElementById('fmtStrike').addEventListener('click', () => wrap('~~'));
document.getElementById('fmtCode').addEventListener('click',   () => wrap('`'));
document.getElementById('fmtH1').addEventListener('click',     () => insertLine('# '));
document.getElementById('fmtH2').addEventListener('click',     () => insertLine('## '));
document.getElementById('fmtH3').addEventListener('click',     () => insertLine('### '));
document.getElementById('fmtQuote').addEventListener('click',  () => insertLine('> '));

/* Insert */
document.getElementById('insLink').addEventListener('click',   () => wrap('[', '](https://)'));
document.getElementById('insImg').addEventListener('click',    () => insertSnippet('![alt](image.png)\n'));
document.getElementById('insTable').addEventListener('click',  () => insertSnippet('| Col 1 | Col 2 | Col 3 |\n|---|---|---|\n| A | B | C |\n'));
document.getElementById('insUL').addEventListener('click',     () => insertLine('- '));
document.getElementById('insOL').addEventListener('click',     () => insertLine('1. '));
document.getElementById('insHR').addEventListener('click',     () => insertSnippet('\n---\n'));

/* View */
document.getElementById('viewEdit').addEventListener('click',    () => setView('write'));
document.getElementById('viewPreview').addEventListener('click', () => setView('preview'));
document.getElementById('viewHistory').addEventListener('click', () => setView('history'));

/* Find */
document.getElementById('btnFind').addEventListener('click',    openFind);
document.getElementById('findClose').addEventListener('click',  closeFind);
document.getElementById('findNext').addEventListener('click',   () => doFind(1));
document.getElementById('findPrev').addEventListener('click',   () => doFind(-1));
document.getElementById('replaceOne').addEventListener('click', () => doReplace(false));
document.getElementById('replaceAll').addEventListener('click', () => doReplace(true));
findInput.addEventListener('input',   () => { _findIdx = -1; doFind(1); });
findInput.addEventListener('keydown', e => {
  if (e.key === 'Enter')  doFind(e.shiftKey ? -1 : 1);
  if (e.key === 'Escape') closeFind();
});

/* Toggles */
document.getElementById('btnWrap').addEventListener('click', () => {
  S.wrap = !S.wrap;
  editor.style.whiteSpace = S.wrap ? 'pre-wrap' : 'pre';
  document.getElementById('btnWrap').classList.toggle('active', S.wrap);
});
document.getElementById('btnLines').addEventListener('click', () => {
  S.lineNums = !S.lineNums;
  document.getElementById('btnLines').classList.toggle('active', S.lineNums);
  updateGutter();
});

/* Menubar open/close */
(() => {
  const menubar = document.getElementById('menubar');
  menubar.querySelectorAll('.mn-label').forEach(label => {
    label.addEventListener('click', e => {
      e.stopPropagation();
      const mn     = label.closest('.mn');
      const isOpen = mn.classList.contains('open');
      menubar.querySelectorAll('.mn').forEach(m => m.classList.remove('open'));
      if (!isOpen) mn.classList.add('open');
    });
  });
  menubar.querySelectorAll('.mi').forEach(item =>
    item.addEventListener('click', () =>
      menubar.querySelectorAll('.mn').forEach(m => m.classList.remove('open'))));
  document.addEventListener('click', () =>
    menubar.querySelectorAll('.mn').forEach(m => m.classList.remove('open')));
})();

/* Keyboard shortcuts */
document.addEventListener('keydown', e => {
  const mod = e.ctrlKey || e.metaKey;
  if (!mod) return;
  if (e.key === 'n') { e.preventDefault(); newFile();  return; }
  if (e.key === 'o') { e.preventDefault(); setView('history'); return; }
  if (e.key === 's') { e.preventDefault(); saveToIDB();         return; }
  if (e.key === 'f') { e.preventDefault(); openFind(); return; }
  if (e.key === '1') { e.preventDefault(); setView('write');   return; }
  if (e.key === '2') { e.preventDefault(); setView('preview'); return; }
  if (e.key === '3') { e.preventDefault(); setView('history'); return; }
  if (e.key === 'b' && document.activeElement === editor) { e.preventDefault(); wrap('**'); return; }
  if (e.key === 'i' && document.activeElement === editor) { e.preventDefault(); wrap('*');  return; }
});

/* Drag & drop */
document.addEventListener('dragover', e => e.preventDefault());
document.addEventListener('drop', async e => {
  e.preventDefault();
  const file = e.dataTransfer.files[0];
  if (!file) return;
  loadContent(await file.text(), file.name);
});

/* Autosave on hide */
window.addEventListener('visibilitychange', () => {
  if (document.visibilityState === 'hidden' && S.dirty) saveToIDB();
});

/* ── Rename ──────────────────────────────────────────────────── */
function startRename() {
  tbFilename.style.display      = 'none';
  tbFilenameInput.style.display = 'block';
  tbFilenameInput.value         = S.filename;
  tbFilenameInput.focus();
  tbFilenameInput.select();
}
function commitRename() {
  let name = tbFilenameInput.value.trim();
  if (!name) name = S.filename; // revert if empty
  // Ensure it has an extension
  if (!name.includes('.')) name += '.' + S.ext;
  S.filename          = name;
  S.ext               = extFrom(name);
  tbFilename.textContent    = name;
  tbFilenameInput.value     = name;
  tbFilename.style.display      = '';
  tbFilenameInput.style.display = 'none';
  setDirty(true);
  updateStatus();
  toast(`Renamed to ${name}`, 'ok');
}
tbFilename.addEventListener('click', startRename);
tbFilename.addEventListener('keydown', e => { if (e.key === 'Enter' || e.key === ' ') startRename(); });
tbFilenameInput.addEventListener('blur',    commitRename);
tbFilenameInput.addEventListener('keydown', e => {
  if (e.key === 'Enter')  { e.preventDefault(); commitRename(); }
  if (e.key === 'Escape') {
    tbFilenameInput.value         = S.filename;
    tbFilename.style.display      = '';
    tbFilenameInput.style.display = 'none';
  }
});


(() => {
  updateGutter();
  updateStatus();
  setView('write');
})();

/* ── After bus boots, restore spirit ────────────────────────── */
document.addEventListener('gnoke:boot', () => {
  if (window.gnokeSpirit) gnokeSpirit.wake('notepad');
});