'use strict';

/* ─────────────────────────────────────────────────────────────
   notes-data.js — v2.0.0
   Gnoke Notes — Data layer: IDB persistence + renderers
   Edmund Sparrow © 2026 — MIT

   WHAT THIS FILE OWNS:
     - App state object S
     - IDB note persistence via AppDB (set by gnoke-presence.js)
     - Markdown + CSV renderers
     - No DOM access. No GnokeClient. No bus.
   ───────────────────────────────────────────────────────────── */

/* ── App state ─────────────────────────────────────────────── */
const S = {
  content:  '',
  filename: 'untitled.md',
  ext:      'md',
  dirty:    false,
  view:     'write',    /* 'write' | 'preview' */
  wrap:     true,
  lineNums: true,
  fontSize: 13,
  findOpen: false,
  currentId: null,      /* IDB note id — null means unsaved */
};

/* ── IDB helpers via AppDB ─────────────────────────────────── */
const NotesDB = {
  _db() { return window.AppDB || null; },

  async saveNote(id, title, content) {
    const db = this._db();
    if (!db) return null;
    const noteId = id || `note_${Date.now()}_${Math.random().toString(36).slice(2,5)}`;
    await db.sessions.put({
      id:      noteId,
      title:   title || 'Untitled',
      ts:      Date.now(),
      content,
      filename: S.filename,
    });
    return noteId;
  },

  async loadNotes() {
    const db = this._db();
    if (!db) return [];
    return (await db.sessions.getAll()) || [];
  },

  async deleteNote(id) {
    const db = this._db();
    if (!db) return;
    await db.sessions.delete(id);
  },
};

/* ── Markdown renderer (no deps) ──────────────────────────── */
function renderMarkdown(md) {
  if (!md) return '';
  let h = md
    .replace(/```([\w]*)\n?([\s\S]*?)```/g, (_, lang, c) =>
      `<pre><code class="lang-${lang}">${escHtml(c.trim())}</code></pre>`)
    .replace(/^#{6}\s(.+)$/gm, '<h6>$1</h6>')
    .replace(/^#{5}\s(.+)$/gm, '<h5>$1</h5>')
    .replace(/^#{4}\s(.+)$/gm, '<h4>$1</h4>')
    .replace(/^###\s(.+)$/gm,  '<h3>$1</h3>')
    .replace(/^##\s(.+)$/gm,   '<h2>$1</h2>')
    .replace(/^#\s(.+)$/gm,    '<h1>$1</h1>')
    .replace(/^>\s(.+)$/gm, '<blockquote>$1</blockquote>')
    .replace(/^(-{3,}|\*{3,}|_{3,})$/gm, '<hr>')
    .replace(/\*\*\*(.+?)\*\*\*/g, '<strong><em>$1</em></strong>')
    .replace(/\*\*(.+?)\*\*/g,     '<strong>$1</strong>')
    .replace(/\*(.+?)\*/g,         '<em>$1</em>')
    .replace(/__(.+?)__/g,         '<strong>$1</strong>')
    .replace(/_(.+?)_/g,           '<em>$1</em>')
    .replace(/~~(.+?)~~/g,         '<del>$1</del>')
    .replace(/`([^`]+)`/g,         '<code>$1</code>')
    .replace(/!\[([^\]]*)\]\(([^)]+)\)/g, '<img src="$2" alt="$1">')
    .replace(/\[([^\]]+)\]\(([^)]+)\)/g,
      '<a href="$2" target="_blank" rel="noopener">$1</a>')
    .replace(/^[\*\-\+]\s(.+)$/gm, '<li>$1</li>')
    .replace(/(<li>.*<\/li>(\n|$))+/g, s => `<ul>${s}</ul>`)
    .replace(/^\d+\.\s(.+)$/gm, '<li>$1</li>')
    .replace(/\|(.+)\|\n\|[-| :]+\|\n((?:\|.+\|\n?)+)/g, (_, head, body) => {
      const ths = head.split('|').filter(c => c.trim())
        .map(c => `<th>${c.trim()}</th>`).join('');
      const rows = body.trim().split('\n').map(r => {
        const tds = r.split('|').filter(c => c.trim())
          .map(c => `<td>${c.trim()}</td>`).join('');
        return `<tr>${tds}</tr>`;
      }).join('');
      return `<table><thead><tr>${ths}</tr></thead><tbody>${rows}</tbody></table>`;
    })
    .replace(/^(?!<[a-z]).+$/gm, l => `<p>${l}</p>`)
    .replace(/<p><\/p>/g, '');
  return h;
}

function escHtml(s) {
  return s
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;');
}

/* ── CSV renderer ──────────────────────────────────────────── */
function renderCSV(csv) {
  const rows = csv.trim().split('\n').map(r => {
    const cols = [];
    let cur = '', inQ = false;
    for (const ch of r) {
      if (ch === '"') { inQ = !inQ; continue; }
      if (ch === ',' && !inQ) { cols.push(cur); cur = ''; continue; }
      cur += ch;
    }
    cols.push(cur);
    return cols;
  });
  if (!rows.length) return '<p>Empty CSV</p>';
  const header = rows[0].map(c => `<th>${escHtml(c.trim())}</th>`).join('');
  const body = rows.slice(1).map(r =>
    `<tr>${r.map(c => `<td>${escHtml(c.trim())}</td>`).join('')}</tr>`
  ).join('');
  return `<div class="csv-table-wrap">
    <table class="csv-table">
      <thead><tr>${header}</tr></thead>
      <tbody>${body}</tbody>
    </table>
  </div>`;
}

/* ── Ext helper ─────────────────────────────────────────────── */
function extFrom(name) {
  return (name.split('.').pop() || 'txt').toLowerCase();
}