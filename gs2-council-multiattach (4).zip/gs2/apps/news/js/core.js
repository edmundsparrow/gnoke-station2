'use strict';

/* ══════════════════════════════════════════════════════════════════
   STATE
══════════════════════════════════════════════════════════════════ */
const State = (() => {
  const DEFAULTS = {
    activePage  : 'feed-page',
    activeTab   : 'all',
    hnStories   : [],
    devStories  : [],
    loading     : false,
    lastFetch   : null,
  };

  let _state = { ...DEFAULTS };
  const _listeners = {};

  function get(key)          { return _state[key]; }
  function set(key, value)   { _state[key] = value; (_listeners[key] || []).forEach(fn => fn(value)); }
  function on(key, callback) { if (!_listeners[key]) _listeners[key] = []; _listeners[key].push(callback); }
  function reset()           { _state = { ...DEFAULTS }; }

  return { get, set, on, reset, DEFAULTS };
})();


/* ══════════════════════════════════════════════════════════════════
   UI
══════════════════════════════════════════════════════════════════ */
const UI = (() => {
  let _toastTimer = null;

  function toast(msg, type = 'info') {
    const el = document.getElementById('toast');
    if (!el) return;
    clearTimeout(_toastTimer);
    el.textContent = msg;
    el.className   = 'show' + (type === 'err' ? ' err' : type === 'ok' ? ' ok' : '');
    _toastTimer = setTimeout(() => el.classList.remove('show'), 2600);
  }

  function init() {
    const saved = localStorage.getItem('devfeeds-theme');
    if (saved) document.documentElement.setAttribute('data-theme', saved);
  }

  function toggleTheme() {
    const cur = document.documentElement.getAttribute('data-theme');
    const next = cur === 'dark' ? 'light' : 'dark';
    document.documentElement.setAttribute('data-theme', next);
    localStorage.setItem('devfeeds-theme', next);
  }

  return { toast, init, toggleTheme };
})();
