'use strict';

/* ══════════════════════════════════════════════════════════════════
   FEEDS — data fetching for HN and dev.to
══════════════════════════════════════════════════════════════════ */
const Feeds = (() => {

  function _timeAgo(d) {
    if (!d) return '';
    const s = Math.floor((Date.now() - d) / 1000);
    if (s < 60)    return s + 's ago';
    if (s < 3600)  return Math.floor(s / 60) + 'm ago';
    if (s < 86400) return Math.floor(s / 3600) + 'h ago';
    return Math.floor(s / 86400) + 'd ago';
  }

  async function fetchHN() {
    const ids = await fetch('https://hacker-news.firebaseio.com/v0/topstories.json')
      .then(r => r.json());
    const top = ids.slice(0, 30);
    const items = await Promise.all(
      top.map(id =>
        fetch(`https://hacker-news.firebaseio.com/v0/item/${id}.json`)
          .then(r => r.json())
          .catch(() => null)
      )
    );
    return items.filter(Boolean).map(i => ({
      id       : 'hn-' + i.id,
      source   : 'hn',
      title    : i.title,
      url      : i.url || `https://news.ycombinator.com/item?id=${i.id}`,
      hnUrl    : `https://news.ycombinator.com/item?id=${i.id}`,
      score    : i.score || 0,
      comments : i.descendants || 0,
      author   : i.by || '',
      time     : i.time ? new Date(i.time * 1000) : null,
      tags     : [],
    }));
  }

  async function fetchDev() {
    const data = await fetch('https://dev.to/api/articles?per_page=30&top=1')
      .then(r => r.json());
    return data.map(a => ({
      id       : 'dev-' + a.id,
      source   : 'dev',
      title    : a.title,
      url      : a.url,
      hnUrl    : null,
      score    : a.positive_reactions_count || 0,
      comments : a.comments_count || 0,
      author   : a.user?.username || '',
      time     : a.published_at ? new Date(a.published_at) : null,
      tags     : (a.tag_list || []).slice(0, 3),
    }));
  }

  async function refresh() {
    State.set('loading', true);
    try {
      const [hn, dev] = await Promise.all([fetchHN(), fetchDev()]);
      State.set('hnStories', hn);
      State.set('devStories', dev);
      State.set('lastFetch', Date.now());
    } catch (err) {
      console.error('[DevFeeds] fetch error', err);
      throw err;
    } finally {
      State.set('loading', false);
    }
  }

  function getVisible() {
    const tab = State.get('activeTab');
    const hn  = State.get('hnStories');
    const dev = State.get('devStories');
    if (tab === 'hn')  return [...hn];
    if (tab === 'dev') return [...dev];
    return [...hn, ...dev].sort((a, b) => b.score - a.score);
  }

  function timeAgo(story) { return _timeAgo(story.time); }

  return { refresh, getVisible, timeAgo };
})();
