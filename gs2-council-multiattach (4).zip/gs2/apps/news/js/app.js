'use strict';

document.addEventListener('gnoke:boot', () => {

  UI.init();
  loadPage('feed-page');


  /* ══════════════════════════════════════════════════════════════
     PAGE ROUTING
  ══════════════════════════════════════════════════════════════ */
  function loadPage(pageId) {
    document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
    const page = document.getElementById(pageId);
    if (page) page.classList.add('active');
    State.set('activePage', pageId);
    updateDrawerActive(pageId);
  }

  window.loadPage = loadPage;


  /* ══════════════════════════════════════════════════════════════
     MOBILE DRAWER
  ══════════════════════════════════════════════════════════════ */
  const Drawer = (() => {
    const panel   = () => document.getElementById('drawer');
    const overlay = () => document.getElementById('drawer-overlay');
    function open()  { panel()?.classList.add('open'); overlay()?.classList.add('open'); }
    function close() { panel()?.classList.remove('open'); overlay()?.classList.remove('open'); }
    return { open, close };
  })();

  window.Drawer = Drawer;

  function updateDrawerActive(pageId) {
    document.querySelectorAll('.drawer-btn').forEach(b => {
      b.classList.toggle('active', b.dataset.page === pageId);
    });
  }


  /* ══════════════════════════════════════════════════════════════
     FEED RENDER
  ══════════════════════════════════════════════════════════════ */
  function renderFeed() {
    const feedEl  = document.getElementById('feed-list');
    const countEl = document.getElementById('feed-count');
    if (!feedEl) return;

    if (State.get('loading')) {
      feedEl.innerHTML = '<div class="loader"><span class="spinner"></span>Fetching stories…</div>';
      if (countEl) countEl.textContent = '';
      return;
    }

    const items = Feeds.getVisible();
    if (!items.length) {
      feedEl.innerHTML = '<div class="empty-state">No stories loaded — hit Refresh.</div>';
      if (countEl) countEl.textContent = '';
      return;
    }

    if (countEl) countEl.textContent = items.length + ' stories';

    feedEl.innerHTML = items.map(s => {
      const isHN   = s.source === 'hn';
      const hiCls  = s.score > 200 ? ' score-hi' : '';
      const tags   = s.tags.map(t => `<span class="story-tag">#${t}</span>`).join('');
      const ago    = Feeds.timeAgo(s);
      return `<a class="story-card" href="${_esc(s.url)}" target="_blank" rel="noopener">
        <div class="source-dot ${isHN ? 'dot-hn' : 'dot-dev'}"></div>
        <div class="story-body">
          <div class="story-title">${_esc(s.title)}</div>
          <div class="story-meta">
            <span class="source-badge ${isHN ? 'badge-hn' : 'badge-dev'}">${isHN ? 'HN' : 'dev.to'}</span>
            <span class="meta-sep">·</span>
            <span class="${hiCls}">▲ ${s.score}</span>
            <span class="meta-sep">·</span>
            <span>💬 ${s.comments}</span>
            ${s.author ? `<span class="meta-sep">·</span><span>${_esc(s.author)}</span>` : ''}
            ${ago      ? `<span class="meta-sep">·</span><span>${ago}</span>` : ''}
          </div>
          ${tags ? `<div class="story-tags">${tags}</div>` : ''}
        </div>
      </a>`;
    }).join('');
  }

  function _esc(str) {
    return String(str)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }

  State.on('loading',    renderFeed);
  State.on('hnStories',  renderFeed);
  State.on('devStories', renderFeed);
  State.on('activeTab',  renderFeed);


  /* ══════════════════════════════════════════════════════════════
     TAB SWITCHING
  ══════════════════════════════════════════════════════════════ */
  document.querySelectorAll('.tab').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
      btn.classList.add('active');
      State.set('activeTab', btn.dataset.tab);
    });
  });


  /* ══════════════════════════════════════════════════════════════
     REFRESH BUTTON
  ══════════════════════════════════════════════════════════════ */
  document.getElementById('btn-refresh')?.addEventListener('click', async () => {
    try {
      await Feeds.refresh();
      UI.toast('Feed updated', 'ok');
    } catch {
      UI.toast('Fetch failed — check connection', 'err');
    }
  });


  /* ══════════════════════════════════════════════════════════════
     THEME TOGGLE
  ══════════════════════════════════════════════════════════════ */
  document.getElementById('btn-theme')?.addEventListener('click', () => {
    UI.toggleTheme();
  });


  /* ══════════════════════════════════════════════════════════════
     INITIAL LOAD
  ══════════════════════════════════════════════════════════════ */
  Feeds.refresh().catch(() => {
    UI.toast('Could not load feeds', 'err');
  });

});
