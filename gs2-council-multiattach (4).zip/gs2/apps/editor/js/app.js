'use strict';

/* ─────────────────────────────────────────────────────────────
   app.js — v2.1.0
   Gnoke Editor — Core IDE logic
   Edmund Sparrow © 2026 — MIT

   Fixes vs v2.0:
     - Menu bubble bug fixed (stopPropagation on .mn-drop)
     - Mobile word-wrap via CSS (see style.css)
     - Open in Pache broadcasts PACHE_OPEN on kernel bus
     - Save As via File System Access API with download fallback
     - data.js now owns IDB; app.js owns only UI + state
   ───────────────────────────────────────────────────────────── */

const Editor = {
  documents:     {},
  currentDocId:  'welcome',
  isSidebarOpen: false,
  wrap:          false,
  lineNums:      true,
  fontSize:      13,
  findOpen:      false,

  el: {},

  /* ── Bootstrap ──────────────────────────────────────────────── */
  async init() {
    this.cacheDom();
    this.documents = await EditorData.loadAll();
    this.bindMenubar();
    this.bindEvents();
    this.loadDocument(
      this.currentDocId in this.documents
        ? this.currentDocId
        : EditorData.WELCOME_ID
    );
    this.renderTabs();
    this.updateGutter();
    this.updateStatus();
  },

  cacheDom() {
    const id = x => document.getElementById(x);
    this.el = {
      editor:      id('htmlEditor'),
      gutter:      id('gutter'),
      tbFilename:  id('tbFilename'),
      tbFilenameInput: id('tbFilenameInput'),
      docTabs:     id('docTabs'),
      docsList:    id('docsList'),
      fileSidebar: id('fileSidebar'),
      findBar:     id('findBar'),
      findInput:   id('findInput'),
      replaceInput:id('replaceInput'),
      findCount:   id('findCount'),
      toast:       id('toast'),
      sbMode:      id('sbMode'),
      sbLines:     id('sbLines'),
      sbChars:     id('sbChars'),
      sbCursor:    id('sbCursor'),
      sbSave:      id('sbSave'),
      sbBus:       id('sbBus'),
      fontSize:    id('fontSize'),
    };
  },

  /* ── Toast ──────────────────────────────────────────────────── */
  _tTimer: null,
  toast(msg, type = '', ms = 2200) {
    const t = this.el.toast;
    t.textContent = msg;
    t.className = `toast show${type ? ' ' + type : ''}`;
    clearTimeout(this._tTimer);
    this._tTimer = setTimeout(() => t.classList.remove('show'), ms);
  },

  /* ── Menubar wiring ─────────────────────────────────────────── */
  bindMenubar() {
    const menubar = document.getElementById('menubar');

    /* Open / close dropdowns */
    menubar.querySelectorAll('.mn-label').forEach(label => {
      label.addEventListener('click', e => {
        e.stopPropagation();
        const mn     = label.closest('.mn');
        const isOpen = mn.classList.contains('open');
        menubar.querySelectorAll('.mn').forEach(m => m.classList.remove('open'));
        if (!isOpen) mn.classList.add('open');
      });
    });

    /* KEY FIX: stop clicks inside a dropdown reaching the global
       document handler — otherwise the menu closes before the
       action listener fires */
    menubar.querySelectorAll('.mn-drop').forEach(drop =>
      drop.addEventListener('click', e => e.stopPropagation()));

    /* Close menu after an action fires */
    menubar.querySelectorAll('.mi').forEach(item =>
      item.addEventListener('click', () =>
        menubar.querySelectorAll('.mn').forEach(m => m.classList.remove('open'))));

    /* Close on outside click */
    document.addEventListener('click', () =>
      menubar.querySelectorAll('.mn').forEach(m => m.classList.remove('open')));

    /* ── File ── */
    document.getElementById('btnNew').addEventListener('click',     () => this.newDocument());
    document.getElementById('btnSaveIDB').addEventListener('click', () => this.save(true));
    document.getElementById('btnSaveAs').addEventListener('click',  () => this.startRename());
    document.getElementById('btnClose').addEventListener('click',   () => this.closeDocument(this.currentDocId));
    document.getElementById('btnDelete').addEventListener('click',  () => this.deleteDocument(this.currentDocId));

    /* ── Edit ── */
    document.getElementById('btnCopyAll').addEventListener('click', () => {
      navigator.clipboard.writeText(this.el.editor.value)
        .then(() => this.toast('Copied', 'ok'));
    });
    document.getElementById('btnSelectAll').addEventListener('click', () => {
      this.el.editor.focus(); this.el.editor.select();
    });
    document.getElementById('btnFind').addEventListener('click',    () => this.openFind());
    document.getElementById('btnIndent').addEventListener('click',  () => this.indentSelection());
    document.getElementById('btnOutdent').addEventListener('click', () => this.outdentSelection());

    /* ── View ── */
    document.getElementById('btnSidebarToggle').addEventListener('click', () => this.toggleSidebar());
    document.getElementById('btnWrap').addEventListener('click', () => {
      this.wrap = !this.wrap;
      this.el.editor.style.whiteSpace = this.wrap ? 'pre-wrap' : 'pre';
      document.getElementById('btnWrap').classList.toggle('active', this.wrap);
    });
    document.getElementById('btnLines').addEventListener('click', () => {
      this.lineNums = !this.lineNums;
      document.getElementById('btnLines').classList.toggle('active', this.lineNums);
      this.updateGutter();
    });
    document.getElementById('btnOpenPache').addEventListener('click', () => this.openInPache());
    this.el.fontSize.addEventListener('change', e => {
      this.fontSize = parseInt(e.target.value);
      this.el.editor.style.fontSize = this.fontSize + 'px';
      this.updateGutter();
    });
  },

  /* ── Editor events ──────────────────────────────────────────── */
  bindEvents() {
    const editor = this.el.editor;
    let saveTimer;

    editor.addEventListener('input', () => {
      this.updateGutter();
      this.updateStatus();
      this.markDirty(true);
      clearTimeout(saveTimer);
      saveTimer = setTimeout(() => this.save(), 800);
    });
    editor.addEventListener('keyup',   () => this.updateCursor());
    editor.addEventListener('click',   () => this.updateCursor());
    editor.addEventListener('scroll',  () => { this.el.gutter.scrollTop = editor.scrollTop; });
    editor.addEventListener('keydown', e => {
      if (e.key === 'Tab') {
        e.preventDefault();
        if (e.shiftKey) this.outdentSelection();
        else            this.indentSelection();
      }
    });

    document.getElementById('newBtn').addEventListener('click', () => this.newDocument());

    /* Filename rename (click-to-edit, Notes-style) */
    this.el.tbFilename.addEventListener('click', () => this.startRename());
    this.el.tbFilename.addEventListener('keydown', e => {
      if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); this.startRename(); }
    });
    this.el.tbFilenameInput.addEventListener('blur', () => this.commitRename());
    this.el.tbFilenameInput.addEventListener('keydown', e => {
      if (e.key === 'Enter')  { e.preventDefault(); this.commitRename(); }
      if (e.key === 'Escape') { e.preventDefault(); this.cancelRename(); }
    });

    /* Find bar */
    document.getElementById('findClose').addEventListener('click',  () => this.closeFind());
    document.getElementById('findNext').addEventListener('click',   () => this.doFind(1));
    document.getElementById('findPrev').addEventListener('click',   () => this.doFind(-1));
    document.getElementById('replaceOne').addEventListener('click', () => this.doReplace(false));
    document.getElementById('replaceAll').addEventListener('click', () => this.doReplace(true));
    this.el.findInput.addEventListener('input', () => { this._findIdx = -1; this.doFind(1); });
    this.el.findInput.addEventListener('keydown', e => {
      if (e.key === 'Enter')  this.doFind(e.shiftKey ? -1 : 1);
      if (e.key === 'Escape') this.closeFind();
    });

    /* Keyboard shortcuts */
    document.addEventListener('keydown', e => {
      const mod = e.ctrlKey || e.metaKey;
      if (!mod) return;
      if (e.key === 'n') { e.preventDefault(); this.newDocument(); return; }
      if (e.key === 'o') { e.preventDefault(); this.toggleSidebar(); return; }
      if (e.key === 's') { e.preventDefault(); this.save(true);    return; }
      if (e.key === 'w') { e.preventDefault(); this.closeDocument(this.currentDocId); return; }
      if (e.key === 'f') { e.preventDefault(); this.openFind();    return; }
    });

    /* Drag & drop */
    document.addEventListener('dragover', e => e.preventDefault());
    document.addEventListener('drop', async e => {
      e.preventDefault();
      const file = e.dataTransfer.files[0];
      if (!file) return;
      this.importFile(await file.text(), file.name);
    });

    /* Autosave on hide */
    window.addEventListener('visibilitychange', () => {
      if (document.visibilityState === 'hidden') this.save();
    });
  },

  /* ── Sidebar ─────────────────────────────────────────────────── */
  toggleSidebar() {
    this.isSidebarOpen = !this.isSidebarOpen;
    this.el.fileSidebar.classList.toggle('open', this.isSidebarOpen);
    document.getElementById('btnSidebarToggle').classList.toggle('active', this.isSidebarOpen);
    if (this.isSidebarOpen) this.renderDocumentList();
  },

  /* ── Tabs ────────────────────────────────────────────────────── */
  renderTabs() {
    const container = this.el.docTabs;
    container.innerHTML = '';
    Object.values(this.documents).forEach(doc => {
      const tab = document.createElement('div');
      tab.className = 'tab' + (doc.id === this.currentDocId ? ' active' : '');

      const label = document.createElement('span');
      label.textContent = doc.name;
      tab.appendChild(label);
      tab.addEventListener('click', () => this.loadDocument(doc.id));

      if (doc.id !== EditorData.WELCOME_ID) {
        const close = document.createElement('span');
        close.className = 'tab-close';
        close.innerHTML = '&times;';
        close.addEventListener('click', e => {
          e.stopPropagation();
          this.closeDocument(doc.id);
        });
        tab.appendChild(close);
      }
      container.appendChild(tab);
    });
  },

  /* ── Sidebar document list ──────────────────────────────────── */
  renderDocumentList() {
    const list = this.el.docsList;
    list.innerHTML = '';
    Object.values(this.documents)
      .sort((a, b) => b.lastModified - a.lastModified)
      .forEach(doc => {
        const item = document.createElement('div');
        item.className = 'doc-item' + (doc.id === this.currentDocId ? ' active' : '');

        const name = document.createElement('span');
        name.textContent = doc.name;
        item.appendChild(name);

        if (doc.id !== EditorData.WELCOME_ID) {
          const del = document.createElement('button');
          del.className = 'doc-delete';
          del.textContent = '✕';
          del.addEventListener('click', e => {
            e.stopPropagation();
            if (confirm(`Delete "${doc.name}"?`)) this.deleteDocument(doc.id);
          });
          item.appendChild(del);
        }
        item.addEventListener('click', () => this.loadDocument(doc.id));
        list.appendChild(item);
      });
  },

  /* ── CRUD ────────────────────────────────────────────────────── */
  loadDocument(docId) {
    const doc = this.documents[docId];
    if (!doc) return;
    this.currentDocId = docId;
    this.el.editor.value = doc.content;
    this.el.tbFilename.textContent = doc.name;
    this.el.tbFilenameInput.value  = doc.name;
    this.renderTabs();
    if (this.isSidebarOpen) this.renderDocumentList();
    this.updateGutter();
    this.updateStatus();
    this.updateCursor();
    this.markDirty(false);
  },

  newDocument() {
    const name = prompt('File name (e.g. index.html):', 'untitled.html');
    if (!name) return;
    const id = 'doc_' + Date.now();
    this.documents[id] = {
      id,
      name,
      content:      EditorData.newDocTemplate(name),
      lastModified: Date.now(),
    };
    this.loadDocument(id);
    this.renderTabs();
    if (this.isSidebarOpen) this.renderDocumentList();
    EditorData.saveAll(this.documents);
  },

  closeDocument(docId) {
    if (docId === EditorData.WELCOME_ID) return;
    const name = this.documents[docId]?.name;
    if (this.currentDocId === docId) {
      const remaining = Object.keys(this.documents).filter(id => id !== docId);
      this.loadDocument(remaining.length ? remaining[remaining.length - 1] : EditorData.WELCOME_ID);
    }
    delete this.documents[docId];
    EditorData.deleteOne(docId);
    this.renderTabs();
    if (this.isSidebarOpen) this.renderDocumentList();
    if (name) this.toast(`Closed: ${name}`);
  },

  deleteDocument(docId) {
    if (docId === EditorData.WELCOME_ID) {
      this.toast('Cannot delete Welcome file', 'err'); return;
    }
    const name = this.documents[docId]?.name;
    delete this.documents[docId];
    EditorData.deleteOne(docId);
    if (this.currentDocId === docId) this.loadDocument(EditorData.WELCOME_ID);
    this.renderTabs();
    if (this.isSidebarOpen) this.renderDocumentList();
    this.toast(`Deleted: ${name}`, 'ok');
  },

  /* ── Rename (Save As → IDB, Notes-style) ─────────────────────── */
  startRename() {
    const doc = this.documents[this.currentDocId];
    if (!doc) return;
    if (this.currentDocId === EditorData.WELCOME_ID) {
      this.toast('Cannot rename Welcome file', 'err');
      return;
    }
    this.el.tbFilename.style.display      = 'none';
    this.el.tbFilenameInput.style.display = 'block';
    this.el.tbFilenameInput.value         = doc.name;
    this.el.tbFilenameInput.focus();
    this.el.tbFilenameInput.select();
  },

  commitRename() {
    const doc = this.documents[this.currentDocId];
    if (!doc) return;
    let name = this.el.tbFilenameInput.value.trim();
    if (!name) name = doc.name; // revert if empty
    const prevExt = (doc.name.split('.').pop() || 'txt');
    if (!name.includes('.')) name += '.' + prevExt;

    doc.name         = name;
    doc.lastModified = Date.now();
    this.el.tbFilename.textContent      = name;
    this.el.tbFilenameInput.value       = name;
    this.el.tbFilename.style.display      = '';
    this.el.tbFilenameInput.style.display = 'none';
    this.renderTabs();
    if (this.isSidebarOpen) this.renderDocumentList();
    this.updateStatus();
    EditorData.saveAll(this.documents);
    this.markDirty(false);
    this.toast(`Renamed to ${name}`, 'ok');
  },

  cancelRename() {
    const doc = this.documents[this.currentDocId];
    this.el.tbFilenameInput.value         = doc?.name || '';
    this.el.tbFilename.style.display      = '';
    this.el.tbFilenameInput.style.display = 'none';
  },

  importFile(content, name) {
    const id = 'doc_' + Date.now();
    this.documents[id] = { id, name, content, lastModified: Date.now() };
    this.loadDocument(id);
    this.renderTabs();
    if (this.isSidebarOpen) this.renderDocumentList();
    EditorData.saveAll(this.documents);
    this.toast(`Opened: ${name}`, 'ok');
  },

  /* ── Save to IDB (autosave + Ctrl+S) ───────────────────────── */
  save(showToast = false) {
    if (!this.currentDocId) return;
    this.documents[this.currentDocId].content      = this.el.editor.value;
    this.documents[this.currentDocId].lastModified = Date.now();
    EditorData.saveAll(this.documents).then
      ? EditorData.saveAll(this.documents).then(() => {
          this.markDirty(false);
          if (showToast) this.toast('Saved', 'ok');
        })
      : (() => { this.markDirty(false); if (showToast) this.toast('Saved', 'ok'); })();
  },

  /* ── Open in Pache ──────────────────────────────────────────── */
  openInPache() {
    const doc = this.documents[this.currentDocId];
    if (!doc) return;
    this.save();
    if (window.GnokeClient && GnokeClient.ready) {
      GnokeClient.broadcast('PACHE_OPEN', {
        filename: doc.name,
        editorId: this.currentDocId,
      }).then(() => {
        this.toast(`Sent to Pache: ${doc.name}`, 'ok');
      }).catch(() => {
        this.toast('Pache not running', 'err');
      });
    } else {
      this.toast('Bus offline — Pache unavailable', 'err');
    }
  },

  /* ── Dirty flag ─────────────────────────────────────────────── */
  markDirty(dirty) {
    this.el.tbFilename.classList.toggle('dirty', dirty);
    this.el.sbSave.textContent = dirty ? '● unsaved' : 'saved';
    this.el.sbSave.className   = `sb-item${dirty ? ' sb-warn' : ''}`;
  },

  /* ── Gutter / status / cursor ───────────────────────────────── */
  updateGutter() {
    if (!this.lineNums) { this.el.gutter.style.display = 'none'; return; }
    this.el.gutter.style.display = 'block';
    const lines = this.el.editor.value.split('\n').length;
    let html = '';
    for (let i = 1; i <= lines; i++) html += `<span class="gutter-line">${i}</span>`;
    this.el.gutter.innerHTML = html;
  },

  updateStatus() {
    const txt   = this.el.editor.value;
    const lines = txt.split('\n').length;
    this.el.sbLines.textContent = `${lines} line${lines !== 1 ? 's' : ''}`;
    this.el.sbChars.textContent = `${txt.length} char${txt.length !== 1 ? 's' : ''}`;
    const doc = this.documents[this.currentDocId];
    const ext = (doc?.name.split('.').pop() || 'txt').toLowerCase();
    const labels = {
      html:'HTML', htm:'HTML', css:'CSS', js:'JavaScript',
      php:'PHP', json:'JSON', xml:'XML', sql:'SQL',
      md:'Markdown', txt:'Plain Text', yml:'YAML', yaml:'YAML', csv:'CSV',
    };
    this.el.sbMode.textContent = labels[ext] || ext.toUpperCase();
  },

  updateCursor() {
    const before = this.el.editor.value.substring(0, this.el.editor.selectionStart);
    const ln  = before.split('\n').length;
    const col = before.split('\n').pop().length + 1;
    this.el.sbCursor.textContent = `Ln ${ln}, Col ${col}`;
  },

  /* ── Indent / outdent ───────────────────────────────────────── */
  indentSelection() {
    const editor = this.el.editor;
    const s = editor.selectionStart, en = editor.selectionEnd;
    if (s === en) {
      editor.setRangeText('  ', s, en, 'end');
    } else {
      const text      = editor.value;
      const lineStart = text.lastIndexOf('\n', s - 1) + 1;
      const replaced  = text.slice(lineStart, en).replace(/^/gm, '  ');
      editor.setRangeText(replaced, lineStart, en, 'end');
    }
    this.markDirty(true); this.updateGutter();
  },

  outdentSelection() {
    const editor = this.el.editor;
    const s = editor.selectionStart, en = editor.selectionEnd;
    const text      = editor.value;
    const lineStart = text.lastIndexOf('\n', s - 1) + 1;
    const replaced  = text.slice(lineStart, en).replace(/^(  |\t)/gm, '');
    editor.setRangeText(replaced, lineStart, en, 'end');
    this.markDirty(true); this.updateGutter();
  },

  /* ── Find & Replace ─────────────────────────────────────────── */
  _findMatches: [],
  _findIdx: -1,

  openFind() {
    this.findOpen = true;
    this.el.findBar.classList.add('open');
    this.el.findInput.focus();
    this.el.findInput.select();
  },
  closeFind() {
    this.findOpen = false;
    this.el.findBar.classList.remove('open');
    this.el.editor.focus();
  },
  doFind(dir = 1) {
    const editor = this.el.editor;
    const q = this.el.findInput.value;
    if (!q) { this.el.findCount.textContent = ''; return; }
    const re = new RegExp(q.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'gi');
    this._findMatches = [...editor.value.matchAll(re)].map(m => m.index);
    this.el.findCount.textContent = this._findMatches.length
      ? `${this._findMatches.length} match${this._findMatches.length !== 1 ? 'es' : ''}`
      : 'no match';
    if (!this._findMatches.length) return;
    this._findIdx = (this._findIdx + dir + this._findMatches.length) % this._findMatches.length;
    const pos = this._findMatches[this._findIdx];
    editor.focus();
    editor.setSelectionRange(pos, pos + q.length);
    const lineH = parseFloat(getComputedStyle(editor).lineHeight);
    editor.scrollTop = (editor.value.substring(0, pos).split('\n').length - 3) * lineH;
  },
  doReplace(all = false) {
    const editor = this.el.editor;
    const q = this.el.findInput.value;
    const r = this.el.replaceInput.value;
    if (!q) return;
    if (all) {
      editor.value = editor.value.split(q).join(r);
      this.markDirty(true);
      this.updateGutter(); this.updateStatus();
      this.toast('Replaced all', 'ok');
    } else {
      const pos = this._findMatches[this._findIdx];
      if (pos === undefined) return;
      editor.setRangeText(r, pos, pos + q.length, 'end');
      this.markDirty(true);
      this.doFind(1);
    }
  },
};

/* ── Boot ────────────────────────────────────────────────────── */
document.addEventListener('gnoke:boot', () => {
  window._gnokeBoot = true;
  Editor.init();
  if (window.gnokeSpirit) gnokeSpirit.wake('editor');
});

/* Fallback: if boot.js not present (standalone / Netlify test),
   boot directly. Small delay lets gnoke:boot fire first if it will. */
setTimeout(() => {
  if (!window._gnokeBoot) Editor.init();
}, 200);
