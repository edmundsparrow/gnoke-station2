'use strict';

/* ─────────────────────────────────────────────────────────────
   data.js — v2.1.0
   Gnoke Editor — Data layer: IDB persistence + welcome doc
   Edmund Sparrow © 2026 — MIT

   WHAT THIS FILE OWNS:
     - EditorData: IDB load/save, welcome document
     - No DOM access. No GnokeClient. No bus.
   ───────────────────────────────────────────────────────────── */

const EditorData = {

  WELCOME_ID: 'welcome',

  /* ── IDB via AppDB ─────────────────────────────────────────── */
  _db() { return window.AppDB || null; },

  async loadAll() {
    const db = this._db();
    const docs = {};

    // Always include welcome doc
    docs[this.WELCOME_ID] = this._welcomeDoc();

    if (!db) return docs;
    try {
      const saved = await db.sessions.getAll();
      (saved || []).forEach(d => {
        if (d.id && d.id !== this.WELCOME_ID) {
          docs[d.id] = {
            id:           d.id,
            name:         d.name || d.title || 'untitled',
            content:      d.content || '',
            lastModified: d.ts || Date.now(),
          };
        }
      });
    } catch (e) {
      console.warn('[editor] IDB loadAll failed:', e.message);
    }
    return docs;
  },

  async saveAll(docs) {
    const db = this._db();
    if (!db) return;
    try {
      for (const doc of Object.values(docs)) {
        if (doc.id === this.WELCOME_ID) continue;
        await db.sessions.put({
          id:      doc.id,
          name:    doc.name,
          title:   doc.name,
          content: doc.content,
          ts:      doc.lastModified || Date.now(),
        });
      }
    } catch (e) {
      console.warn('[editor] IDB saveAll failed:', e.message);
    }
  },

  async deleteOne(id) {
    const db = this._db();
    if (!db) return;
    try { await db.sessions.delete(id); } catch (e) {}
  },

  /* ── Welcome document ──────────────────────────────────────── */
  _welcomeDoc() {
    return {
      id:           this.WELCOME_ID,
      name:         'welcome.html',
      lastModified: Date.now(),
      content: `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Welcome</title>
</head>
<body>
  <h1>Gnoke Editor</h1>
  <p>Lightweight IDE for HTML, CSS, JS, PHP and more.</p>
  <p>File → New to start a new document.</p>
</body>
</html>`,
    };
  },

  /* ── New doc template ──────────────────────────────────────── */
  newDocTemplate(name) {
    const ext = (name.split('.').pop() || 'txt').toLowerCase();
    const templates = {
      html: `<!DOCTYPE html>\n<html lang="en">\n<head>\n  <meta charset="UTF-8">\n  <title>Document</title>\n</head>\n<body>\n  \n</body>\n</html>`,
      css:  `/* ${name} */\n\n`,
      js:   `'use strict';\n\n`,
      php:  `<?php\n\n`,
    };
    return templates[ext] || '';
  },
};
