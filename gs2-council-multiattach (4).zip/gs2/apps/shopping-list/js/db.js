/**
 * db.js — Gnoke Shopping List
 * Storage via GnokeSysDB (AppDB) — Gnoke Station 2 native.
 *
 * Replaces the old sql.js / localStorage binary approach.
 * AppDB is a namespaced GnokeSysDB instance opened by gnoke-presence.js.
 *
 * Storage layout (all keys namespaced to 'shopping-list' by AppDB):
 *   AppDB.sessions   → trip records  { id, name, budget, note, created_at, status }
 *   AppDB.put('items:'+tripId, Item[])  → line items array per trip
 *   AppDB.put('settings', { key: val }) → flat settings object
 *
 * Public API (async — same surface as the old DB):
 *   await DB.init()
 *   await DB.getTrips()                → Trip[]
 *   await DB.getTrip(id)               → Trip | null
 *   await DB.saveTrip(trip)            → id
 *   await DB.deleteTrip(id)            → void
 *   await DB.getItems(tripId)          → Item[]
 *   await DB.saveItem(item)            → id
 *   await DB.deleteItem(id)            → void
 *   await DB.toggleItem(id, checked)   → void
 *   await DB.getSetting(key, def)      → string
 *   await DB.setSetting(key, val)      → void
 *   DB.exportJSON()                    → string  (sync — reads cached state)
 *   await DB.importJSON(json)          → void
 *   DB.newId()                         → string
 */

const DB = (() => {
  'use strict';

  /* ── Wait for AppDB to be ready (set by gnoke-presence.js) ── */
  function _db() {
    if (!window.AppDB) throw new Error('[DB] AppDB not ready — gnoke-presence.js must run first');
    return window.AppDB;
  }

  function newId() {
    return Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
  }

  /* ── Init ── No-op: AppDB is opened by gnoke-presence.js ── */
  async function init() {
    // Poll until AppDB is available (presence may still be booting)
    await new Promise((resolve) => {
      if (window.AppDB) { resolve(); return; }
      const t = setInterval(() => {
        if (window.AppDB) { clearInterval(t); resolve(); }
      }, 40);
      setTimeout(() => { clearInterval(t); resolve(); }, 4000);
    });
  }

  /* ══ TRIPS — stored in AppDB.sessions ══ */

  async function getTrips() {
    const rows = await _db().sessions.getAll();
    return rows.sort((a, b) => (b.created_at || '').localeCompare(a.created_at || ''));
  }

  async function getTrip(id) {
    const trips = await getTrips();
    return trips.find(t => t.id === id) || null;
  }

  async function saveTrip(trip) {
    const id = trip.id || newId();
    await _db().sessions.put({
      id,
      title:      trip.name,      // sessions API uses 'title' as display field
      name:       trip.name,
      budget:     trip.budget     || 0,
      note:       trip.note       || '',
      created_at: trip.created_at || new Date().toISOString(),
      status:     trip.status     || 'open',
      ts:         Date.now(),
    });
    return id;
  }

  async function deleteTrip(id) {
    // Remove items first
    await _db().delete('items:' + id);
    await _db().sessions.delete(id);
  }

  /* ══ ITEMS — stored as JSON array keyed 'items:<tripId>' ══ */

  async function getItems(tripId) {
    const raw = await _db().get('items:' + tripId);
    return Array.isArray(raw) ? raw.sort((a, b) => (a.sort_order || 0) - (b.sort_order || 0)) : [];
  }

  async function saveItem(item) {
    const items = await getItems(item.trip_id);
    const id    = item.id || newId();
    const idx   = items.findIndex(i => i.id === id);
    const record = {
      id,
      trip_id:    item.trip_id,
      label:      item.label,
      price:      item.price      || 0,
      qty:        item.qty        || 1,
      unit:       item.unit       || '',
      checked:    item.checked    ? 1 : 0,
      sort_order: item.sort_order || Date.now(),
    };
    if (idx >= 0) {
      items[idx] = { ...items[idx], ...record };
    } else {
      items.push(record);
    }
    await _db().put('items:' + item.trip_id, items);
    return id;
  }

  async function deleteItem(id) {
    // We need to find which trip owns this item — scan all trips
    const trips = await getTrips();
    for (const trip of trips) {
      const items = await getItems(trip.id);
      const filtered = items.filter(i => i.id !== id);
      if (filtered.length !== items.length) {
        await _db().put('items:' + trip.id, filtered);
        return;
      }
    }
  }

  async function toggleItem(id, checked) {
    const trips = await getTrips();
    for (const trip of trips) {
      const items = await getItems(trip.id);
      const idx   = items.findIndex(i => i.id === id);
      if (idx >= 0) {
        items[idx].checked = checked ? 1 : 0;
        await _db().put('items:' + trip.id, items);
        return;
      }
    }
  }

  /* ══ SETTINGS — stored as a flat object under key 'settings' ══ */

  async function _getSettings() {
    const s = await _db().get('settings');
    return (s && typeof s === 'object') ? s : {};
  }

  async function getSetting(key, def = '') {
    const settings = await _getSettings();
    return key in settings ? settings[key] : def;
  }

  async function setSetting(key, val) {
    const settings = await _getSettings();
    settings[key] = String(val);
    await _db().put('settings', settings);
  }

  /* ══ EXPORT / IMPORT ══ */

  async function exportJSONAsync() {
    const trips = await getTrips();
    const full  = await Promise.all(trips.map(async t => ({ ...t, items: await getItems(t.id) })));
    return JSON.stringify({ version: 2, exported_at: new Date().toISOString(), trips: full }, null, 2);
  }

  // Keep sync signature for menu.js callers; returns the JSON string via promise
  function exportJSON() {
    return exportJSONAsync();
  }

  async function importJSON(json) {
    const data = JSON.parse(json);
    for (const t of (data.trips || [])) {
      const items = t.items || [];
      const tripCopy = { ...t };
      delete tripCopy.items;
      // v1 compat: id may be missing
      if (!tripCopy.id) tripCopy.id = newId();
      await saveTrip(tripCopy);
      for (const i of items) {
        await saveItem({ ...i, trip_id: tripCopy.id });
      }
    }
  }

  return {
    init, newId,
    getTrips, getTrip, saveTrip, deleteTrip,
    getItems, saveItem, deleteItem, toggleItem,
    getSetting, setSetting,
    exportJSON, importJSON,
  };
})();
