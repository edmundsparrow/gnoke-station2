# Gnoke GeoCompass

Real-time GPS bearing, heading, and destination navigation. A GnokeStation native app.

---

<details>
<summary>Architecture</summary>

**Type:** Tool / TYPE C — no database, state lives in runtime memory and AppDB (IDB) for persistence.

**Script load order** (boot.js reads `gnoke:scripts` meta and loads in this sequence):

1. `js/core.js` — State, UI, Geo math, `_esc()`
2. `js/geo-compass.js` — Compass engine, GPS, DeviceOrientation, SVG rose
3. `js/speed.js` — Speedometer engine, GPS watcher, rAF dial
4. `js/app.js` — DOMContentLoaded bootstrap, page routing, all event wiring
5. `gnoke-presence.js` — Bus registration, sysPill driver (loaded last by boot.js)

</details>

---

<details>
<summary>GnokeStation integration</summary>

- **gnoke.json** — `role: "guest_app"`, `capabilities: ["geolocation"]`
- **gnoke-presence.js** — `APP_ID: "geocompass"`, `APP_CAPS: ["geolocation"]`
- **boot.js** — single entry point at bottom of body
- **sysPill** — `id="sysPill"` in topbar, driven automatically by presence.js
- **Home link** — brand wraps `<a href="/index.html">` back to GnokeStation launcher
- **gnoke:boot event** — fired by presence.js after bus registration; app can listen for this to defer GPS-dependent init if needed

</details>

---

<details>
<summary>core.js — modules</summary>

### State
Single source of truth for all runtime state. Pub/sub via `State.on(key, fn)`.

Key state fields:
- `activePage` — current visible page id
- `compassEnabled` — whether DeviceOrientation is active
- `heading` — smoothed compass heading in degrees
- `gpsLat`, `gpsLon`, `gpsAccuracy`, `gpsActive` — GPS fix data
- `destLat`, `destLon`, `destName` — active destination

API: `State.get(key)`, `State.set(key, value)`, `State.on(key, callback)`, `State.reset()`

### UI
Pure DOM utilities. No business logic.

- `UI.toast(msg, type)` — type: `'ok'` | `'err'` | `'info'`
- `UI.status(msg, type)` — brief status chip
- `UI.loading(show)` — loading overlay
- `UI.openModal(id)` / `UI.closeModal(id)`
- `UI.empty(tbody, cols, msg)` — empty state row
- `UI.init()` — wires modal overlay-click-to-close

### Geo
Pure math. No DOM, no state.

- `Geo.haversine(lat1, lon1, lat2, lon2)` → distance in metres
- `Geo.bearing(lat1, lon1, lat2, lon2)` → bearing in degrees (0–360)
- `Geo.cardinalDir(deg)` → 16-point cardinal string e.g. `'NNE'`
- `Geo.formatDist(metres)` → human string e.g. `'1.23 km'` or `'456 m'`

### _esc(str)
HTML escape utility. Used when rendering user/API content into innerHTML.

</details>

---

<details>
<summary>geo-compass.js — Compass module</summary>

Public API exposed on `window.Compass`:

| Method | Description |
|---|---|
| `Compass.init()` | Mount SVG compass rose, start GPS watcher, start rAF animation loop |
| `Compass.enableOrientation()` | Request DeviceOrientation permission (iOS 13+ prompt), start heading tracking |
| `Compass.setDest(lat, lon, name)` | Set active destination, updates bearing arrow and dest card |
| `Compass.clearDest()` | Clear destination, resets arrow and dest card |
| `Compass.searchLocation(query)` | Nominatim geocode search → populates search results page |
| `Compass.selectResult(lat, lon, name)` | Pick a search result as destination, switches to compass page |
| `Compass.destroy()` | Cancel rAF, clear GPS watcher, remove orientation listeners |

**SVG compass rose** — built programmatically at init. Tick marks every 5° (major at 10°), degree labels at 30° intervals, cardinal/intercardinal labels, red N needle, gold S needle, destination bearing arrow overlay.

**Heading smoothing** — `_smoothHeading` interpolates toward `_targetHeading` at 10% per frame. Prevents jitter from sensor noise.

**Destination bearing arrow** — non-rotating `<g>` element rotated via JS to relative bearing (bearing minus current heading). Shows dashed ring + arrow at compass edge.

**iOS orientation permission** — checks for `DeviceOrientationEvent.requestPermission` and calls it before activating. Required on iOS 13+.

**GPS error codes:** 1 = permission denied, 2 = unavailable, 3 = timeout.

</details>

---

<details>
<summary>speed.js — Speedometer module</summary>

Public API on `window.Speedometer`:

| Method | Description |
|---|---|
| `Speedometer.init()` | Mount SVG dial, load odometer, start GPS watcher, start rAF loop |
| `Speedometer.destroy()` | Cancel rAF, clear GPS watcher |
| `Speedometer.reset()` | Reset trip stats (max, avg, trip km). Does not reset odometer. |
| `Speedometer.toggleUnit()` | Toggle km/h ↔ mph. Persisted in AppDB (IDB). |

**Config:** Max dial 240 km/h. Sweep 270°. Arc colours: green 0–80, amber 80–160, red 160–240.

**GPS speed** — `coords.speed` from Geolocation API (m/s), converted to km/h. Samples below 0.5 km/h ignored to filter noise.

**Odometer** — persisted in AppDB under key `odometer`. Never resets. Trip meter resets on `Speedometer.reset()`.

**Distance calc** — haversine between consecutive GPS fixes. Fixes > 500m apart are discarded as GPS jumps.

**Unit persistence** — AppDB key `speed-unit` (`'kmh'` | `'mph'`).

</details>

---

<details>
<summary>app.js — Bootstrap</summary>

Runs on `DOMContentLoaded`. Owns all event wiring and page routing.

Init sequence:
1. `UI.init()` — modal overlay close wiring
2. `Compass.init()` — mount SVG, start GPS + rAF
3. `Speedometer.init()` — mount dial, start GPS + rAF
4. Populate About tech table
5. `loadPage('compass-page')` — show default page

**Page routing** — `loadPage(pageId)` removes `.active` from all `.page` elements, adds to target. Saves to `State.set('activePage', pageId)`. Clears `context-info` topbar text for non-compass pages.

**Drawer** — hamburger opens, close button and overlay click close. Escape key closes. `window.Drawer` and `window.loadPage` exposed for inline HTML handlers.

</details>

---

<details>
<summary>Nominatim usage</summary>

Search endpoint: `https://nominatim.openstreetmap.org/search`

Parameters: `q`, `format=json`, `limit=8`, `addressdetails=1`

User-Agent header required: `GnokegeoCompass/1.0`

Map preview iframes use OpenStreetMap embed with bbox ±0.05° around result coordinates.

Rate limit: Nominatim public instance — do not hammer. One request per search action.

</details>

---

<details>
<summary>AppDB keys (IDB)</summary>

| Key | Type | Description |
|---|---|---|
| `odometer` | string | Cumulative km, 3 decimal places. Never resets. |
| `speed-unit` | string | `'kmh'` or `'mph'`. |

</details>
