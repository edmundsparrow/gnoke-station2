{
  "gnoke": "1.0",
  "appId": "geocompass",
  "name": "GeoCompass",
  "version": "1.0.0",
  "role": "guest_app",
  "native": true,
  "capabilities": ["geolocation"],
  "description": "Real-time GPS bearing, heading and destination navigation",
  "icon": "🧭",
  "author": "Ekong Ikpe",
  "license": "MIT"
}
