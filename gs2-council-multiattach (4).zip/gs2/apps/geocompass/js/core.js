/**
 * core.js — Gnoke GeoCompass
 * Foundation layer. Must load before all other scripts.
 *
 * Contains:
 *   State  — runtime state store with pub/sub
 *   UI     — DOM utilities (toast, status chip, modals)
 *   Geo    — pure math helpers (haversine, bearing, cardinalDir, formatDist)
 *   _esc() — HTML escape utility
 */


/* ══════════════════════════════════════════════════════════════════
   STATE — single source of truth for all runtime state
══════════════════════════════════════════════════════════════════ */

const State = (() => {

  const today = new Date().toISOString().split('T')[0];

  const DEFAULTS = {
    /* Navigation */
    activePage        : 'compass-page',

    /* Date */
    today             : today,

    /* Compass */
    compassEnabled    : false,
    heading           : 0,         // current smoothed heading (degrees)

    /* GPS */
    gpsLat            : null,
    gpsLon            : null,
    gpsAccuracy       : null,
    gpsActive         : false,

    /* Destination */
    destLat           : null,
    destLon           : null,
    destName          : null,

    /* Search */
    searchResults     : [],
    searchStatus      : '',
  };

  let _state    = { ...DEFAULTS };
  const _listeners = {};

  function get(key)          { return _state[key]; }
  function set(key, value)   { _state[key] = value; (_listeners[key] || []).forEach(fn => fn(value)); }
  function on(key, callback) { if (!_listeners[key]) _listeners[key] = []; _listeners[key].push(callback); }
  function reset()           { _state = { ...DEFAULTS }; }

  return { get, set, on, reset, DEFAULTS };

})();


/* ══════════════════════════════════════════════════════════════════
   UI — pure DOM utilities, no business logic
══════════════════════════════════════════════════════════════════ */

const UI = (() => {

  /* ── Toast ── */
  let _toastTimer = null;

  function toast(msg, type = 'info') {
    const el = document.getElementById('toast');
    if (!el) return;
    clearTimeout(_toastTimer);
    el.textContent = msg;
    el.className   = `show${type === 'err' ? ' err' : type === 'ok' ? ' ok' : ''}`;
    _toastTimer = setTimeout(() => el.classList.remove('show'), 2800);
  }

  /* ── Status chip ── */
  let _statusTimer = null;

  function status(msg, type = 'ok') {
    const el = document.getElementById('status-chip');
    if (!el) return;
    clearTimeout(_statusTimer);
    el.textContent = msg;
    el.className   = `show${type === 'err' ? ' err' : ''}`;
    _statusTimer = setTimeout(() => el.classList.remove('show'), 2200);
  }

  /* ── Loading overlay ── */
  function loading(show) {
    const el = document.getElementById('loading-overlay');
    if (el) el.style.display = show ? 'flex' : 'none';
  }

  /* ── Modals ── */
  function openModal(id)  { document.getElementById(id)?.classList.add('show'); }
  function closeModal(id) { document.getElementById(id)?.classList.remove('show'); }

  function initModalOverlayClose() {
    document.querySelectorAll('.modal-overlay').forEach(overlay => {
      overlay.addEventListener('click', e => {
        if (e.target === overlay) overlay.classList.remove('show');
      });
    });
  }

  /* ── Table empty state ── */
  function empty(tbody, cols, msg = 'No records yet.') {
    tbody.innerHTML = `<tr><td colspan="${cols}" class="empty-cell">${msg}</td></tr>`;
  }

  /* ── Init ── */
  function init() { initModalOverlayClose(); }

  return { toast, status, loading, openModal, closeModal, empty, init };

})();


/* ══════════════════════════════════════════════════════════════════
   GEO — pure math helpers (no DOM, no state)
══════════════════════════════════════════════════════════════════ */

const Geo = (() => {

  function _toRad(d) { return d * Math.PI / 180; }
  function _toDeg(r) { return r * 180 / Math.PI; }

  function haversine(lat1, lon1, lat2, lon2) {
    const R    = 6371e3;
    const dLat = _toRad(lat2 - lat1);
    const dLon = _toRad(lon2 - lon1);
    const a    = Math.sin(dLat / 2) ** 2 +
                 Math.cos(_toRad(lat1)) * Math.cos(_toRad(lat2)) *
                 Math.sin(dLon / 2) ** 2;
    return 2 * R * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  }

  function bearing(lat1, lon1, lat2, lon2) {
    const y = Math.sin(_toRad(lon2 - lon1)) * Math.cos(_toRad(lat2));
    const x = Math.cos(_toRad(lat1)) * Math.sin(_toRad(lat2)) -
              Math.sin(_toRad(lat1)) * Math.cos(_toRad(lat2)) * Math.cos(_toRad(lon2 - lon1));
    return (_toDeg(Math.atan2(y, x)) + 360) % 360;
  }

  function cardinalDir(deg) {
    const dirs = ['N','NNE','NE','ENE','E','ESE','SE','SSE',
                  'S','SSW','SW','WSW','W','WNW','NW','NNW'];
    return dirs[Math.round((deg % 360) / 22.5) % 16];
  }

  function formatDist(m) {
    return m >= 1000 ? `${(m / 1000).toFixed(2)} km` : `${Math.round(m)} m`;
  }

  return { haversine, bearing, cardinalDir, formatDist };

})();


/* ══════════════════════════════════════════════════════════════════
   _esc — HTML escape utility
══════════════════════════════════════════════════════════════════ */

function _esc(str) {
  const d = document.createElement('div');
  d.textContent = str;
  return d.innerHTML;
}
