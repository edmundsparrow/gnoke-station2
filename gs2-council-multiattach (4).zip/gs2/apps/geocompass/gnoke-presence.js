'use strict';

(async () => {

  /* ── Pill state ─────────────────────────────────────────────── */
  function _setSysPill(s) {
    const pill  = document.getElementById('sysPill');
    const label = document.getElementById('sysPillLabel');
    if (!pill) return;
    pill.className    = 'sys-pill' + (s === 'live' ? ' live' : s === 'error' ? ' error' : '');
    label.textContent = s === 'live' ? 'Bus Live' : s === 'error' ? 'Bus Error' : 'Connecting';
  }

  /* ══════════════════════════════════════════════════════════════
     ↓ CHANGE THESE 4 FIELDS — nothing else in this file changes
  ══════════════════════════════════════════════════════════════ */
  const APP_ID            = 'geocompass';
  const APP_VERSION       = '1.0.0';
  const APP_CAPS          = ['geolocation'];
  const APP_MAX_INSTANCES = 1;   /* 1 = singleton, -1 = unlimited */
  /* ══════════════════════════════════════════════════════════════ */

  /* ── App Switcher ───────────────────────────────────────────────
     Injected into every app via presence.js — no per-app changes.
     Anchors to the sys-pill. Shows running apps from the bus
     registry. Click any entry to focus that window directly.
  ──────────────────────────────────────────────────────────────── */
  function _buildSwitcher() {
    /* Inject CSS once */
    if (!document.getElementById('_gsw_style')) {
      const st = document.createElement('style');
      st.id = '_gsw_style';
      st.textContent = `
        #_gswTray {
          position: fixed;
          top: calc(var(--topbar-h, 44px) + 6px);
          right: 10px;
          z-index: 9999;
          background: var(--surface, #fff);
          border: 1px solid var(--border, #d8e6f2);
          border-radius: 12px;
          box-shadow: 0 8px 24px rgba(31,71,101,0.14);
          min-width: 200px;
          max-width: 260px;
          overflow: hidden;
          opacity: 0;
          pointer-events: none;
          transform: translateY(-6px) scale(0.97);
          transform-origin: top right;
          transition: opacity 0.15s ease, transform 0.15s ease;
          font-family: var(--font-sans, 'Outfit', sans-serif);
        }
        #_gswTray.open {
          opacity: 1;
          pointer-events: all;
          transform: translateY(0) scale(1);
        }
        ._gsw-header {
          padding: 9px 12px 7px;
          font-size: 9px;
          font-weight: 600;
          letter-spacing: 0.1em;
          text-transform: uppercase;
          color: var(--muted, #8aa3bc);
          border-bottom: 1px solid var(--border, #d8e6f2);
          display: flex;
          align-items: center;
          justify-content: space-between;
        }
        ._gsw-home {
          font-size: 9px;
          font-weight: 600;
          letter-spacing: 0.06em;
          text-transform: uppercase;
          color: var(--blue-2, #3f6e9b);
          text-decoration: none;
          padding: 2px 6px;
          border-radius: 4px;
          background: var(--accent-dim, rgba(134,180,228,0.14));
          transition: background 0.15s;
        }
        ._gsw-home:hover { background: var(--border, #d8e6f2); }
        ._gsw-list {
          padding: 5px 0;
          max-height: 320px;
          overflow-y: auto;
        }
        ._gsw-item {
          display: flex;
          align-items: center;
          gap: 9px;
          padding: 7px 12px;
          cursor: pointer;
          transition: background 0.1s;
          user-select: none;
          border: none;
          background: transparent;
          width: 100%;
          text-align: left;
        }
        ._gsw-item:hover { background: var(--surface-2, #f7fafd); }
        ._gsw-item.current { background: var(--accent-dim, rgba(134,180,228,0.14)); }
        ._gsw-dot {
          width: 7px; height: 7px; border-radius: 50%;
          background: var(--live, #0e9f6e);
          flex-shrink: 0;
          box-shadow: 0 0 0 2px rgba(14,159,110,0.15);
        }
        ._gsw-name {
          font-size: 12px;
          font-weight: 500;
          color: var(--text, #1a2e44);
          white-space: nowrap;
          overflow: hidden;
          text-overflow: ellipsis;
          flex: 1;
        }
        ._gsw-item.current ._gsw-name {
          color: var(--blue-2, #3f6e9b);
          font-weight: 600;
        }
        ._gsw-empty {
          padding: 12px;
          font-size: 11px;
          color: var(--muted, #8aa3bc);
          text-align: center;
        }
        ._gsw-pill-wrap {
          position: relative;
          cursor: pointer;
        }
        ._gsw-pill-wrap .sys-pill {
          cursor: pointer;
          user-select: none;
        }
      `;
      document.head.appendChild(st);
    }

    /* Build tray */
    const tray = document.createElement('div');
    tray.id = '_gswTray';
    tray.innerHTML = `
      <div class="_gsw-header">
        <span>Running Apps</span>
        <a class="_gsw-home" href="/index.html"
           onclick="if(window.open('/index.html','gnoke-launch')){this.blur();return false;}">
          ⌂ Home
        </a>
      </div>
      <div class="_gsw-list" id="_gswList">
        <div class="_gsw-empty">No other apps running</div>
      </div>
    `;
    document.body.appendChild(tray);

    /* Wrap the sys-pill so clicks open the tray */
    const pill = document.getElementById('sysPill');
    if (pill && pill.parentNode) {
      const wrap = document.createElement('div');
      wrap.className = '_gsw-pill-wrap';
      pill.parentNode.insertBefore(wrap, pill);
      wrap.appendChild(pill);
      wrap.addEventListener('click', (e) => {
        e.stopPropagation();
        tray.classList.toggle('open');
      });
    }

    /* Close on outside click */
    document.addEventListener('click', () => tray.classList.remove('open'));
    tray.addEventListener('click', e => e.stopPropagation());

    return tray;
  }

  function _renderSwitcher(processes) {
    const list = document.getElementById('_gswList');
    if (!list) return;

    /* Filter out self, launcher, and system-only processes with no URL */
    const others = Object.values(processes).filter(p => {
      const id = p.meta?.appId || p.meta?.name || '';
      return id !== APP_ID && id !== 'gnoke-launch' && p.meta?.url;
    });

    if (!others.length) {
      list.innerHTML = '<div class="_gsw-empty">No other apps running</div>';
      return;
    }

    list.innerHTML = others.map(p => {
      const name = p.meta?.name || p.meta?.appId || 'App';
      const url  = p.meta?.url  || '#';
      const appId = p.meta?.appId || name.toLowerCase().replace(/\s+/g,'-');
      return `
        <button class="_gsw-item" data-url="${url}" data-id="${appId}" title="Switch to ${name}">
          <span class="_gsw-dot"></span>
          <span class="_gsw-name">${name}</span>
        </button>
      `;
    }).join('');

    list.querySelectorAll('._gsw-item').forEach(btn => {
      btn.addEventListener('click', () => {
        const url = btn.dataset.url;
        const id  = btn.dataset.id;
        if (url && url !== '#') {
          window.open(url, `gnoke-${id}`);
        }
        document.getElementById('_gswTray')?.classList.remove('open');
      });
    });
  }

  /* ── Boot ────────────────────────────────────────────────────── */
  if (window.GnokeClient?.ready) {
    _setSysPill('live');
    if (window.GnokeSysDB) window.AppDB = GnokeSysDB(APP_ID);
    return;
  }

  /* Build the switcher tray immediately so it's ready before boot */
  _buildSwitcher();

  try {
    await Gnoke.ready({
      name:         APP_ID,
      version:      APP_VERSION,
      capabilities: APP_CAPS,
      maxInstances: APP_MAX_INSTANCES,
    });
    if (window.GnokeSysDB) window.AppDB = GnokeSysDB(APP_ID);
    _setSysPill('live');

    /* Initial population */
    const { processes } = await GnokeClient.listAll();
    _renderSwitcher(processes);

    /* Live updates as apps open/close */
    GnokeClient.onRegistry(procs => _renderSwitcher(procs));

    GnokeClient.onProcessDied(() => {});
  } catch (_) {
    _setSysPill('error');
  }

})();
