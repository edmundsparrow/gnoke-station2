/* resolver.js — v1.0.0
   Gnoke-Zero / Pache — Single source of truth for path resolution.
   Edmund Sparrow © 2026 — MIT

   MANDATE (from zero.md):
   All path normalisation lives here.
   No path logic leaks into: UI, Service Worker, settings panel.

   ROOT AWARENESS MODEL:
   The mounted folder is the authoritative document root.
   The root is not merely storage — it is the anchor for all
   path calculations. Every resolution is relative to that root.

   This module is shared by:
   - pache-client.js  (builds URLs before opening tabs)
   - gnoke-zero-sw.js (walks handles on fetch)
   - index.html       (resolves display paths for the tree)

   It is loaded in both main-thread and SW context, so:
   - No DOM access
   - No window / document references
   - No IndexedDB (that belongs to spirit/storage)
   - Pure functions only
*/

'use strict';

const GnokeResolver = (() => {

  const SERVE_PREFIX = '/serve';

  /* ── normalise ───────────────────────────────────────────────
     Takes any raw path and returns a clean, root-relative path.

     Rules (in order):
     1. Always starts with /
     2. No double slashes
     3. No trailing slash (except bare root "/")
     4. Resolves ../ and ./ segments
     5. Stays inside root — cannot escape above /

     Examples:
       normalise('/src/../app.html') → '/app.html'
       normalise('src/app.html')     → '/src/app.html'
       normalise('/src//app.html')   → '/src/app.html'
       normalise('/')                → '/'
  */
  function normalise(raw) {
    if (!raw || raw === '') return '/';

    // Ensure leading slash
    let p = raw.startsWith('/') ? raw : '/' + raw;

    // Collapse double slashes
    p = p.replace(/\/\/+/g, '/');

    // Resolve . and .. segments
    const parts = p.split('/');
    const resolved = [];
    for (const part of parts) {
      if (part === '' || part === '.') continue;
      if (part === '..') {
        resolved.pop(); // can't go above root — if empty, stays empty
      } else {
        resolved.push(part);
      }
    }

    const result = '/' + resolved.join('/');
    return result === '/' ? '/' : result;
  }

  /* ── resolveRequest ──────────────────────────────────────────
     The core resolution function. Takes a pathname from a fetch
     event or a user click and returns what the SW should serve.

     Input:  pathname  — e.g. '/serve/src/app.html'
     Output: { segments: string[], fileName: string }
             segments = folder path to walk (may be empty for root)
             fileName = the file to getFileHandle()

     The SERVE_PREFIX ('/serve') is stripped first.
     Root-relative path is the remainder.

     Clean-URL rules applied:
     - Empty or '/' → index.html at root
     - Trailing slash → directory index.html
     - No extension → try appending .html

     These rules live HERE. Not in the SW. Not in the UI.
  */
  function resolveRequest(pathname) {
    let rel = pathname.startsWith(SERVE_PREFIX)
      ? pathname.slice(SERVE_PREFIX.length)
      : pathname;

    rel = normalise(rel);

    // Bare root
    if (rel === '/') rel = '/index.html';

    // Trailing slash = directory index
    if (rel.endsWith('/')) rel += 'index.html';

    // Clean URL: no extension → try .html
    const lastSeg = rel.split('/').pop();
    if (lastSeg && !lastSeg.includes('.')) rel += '.html';

    // Split into walk segments + file name
    const parts = rel.split('/').filter(Boolean);
    const fileName = parts.pop();
    const segments = parts; // folders to walk via getDirectoryHandle

    return { segments, fileName, resolvedPath: rel };
  }

  /* ── toServeURL ──────────────────────────────────────────────
     Converts a root-relative file path to the URL the browser
     should open. This is the only place SERVE_PREFIX is applied
     for outbound navigation.

     Input:  '/src/app.html'
     Output: '/serve/src/app.html'
  */
  function toServeURL(rootRelativePath) {
    const clean = normalise(rootRelativePath);
    return SERVE_PREFIX + clean;
  }

  /* ── isServeable ─────────────────────────────────────────────
     Returns true if this pathname falls under SERVE_PREFIX and
     should be handled by the SW resolver. Used by the SW fetch
     interceptor to decide whether to intercept.
  */
  function isServeable(pathname) {
    return pathname.startsWith(SERVE_PREFIX);
  }

  /* ── displayPath ─────────────────────────────────────────────
     Returns a human-readable root-relative path for UI display.
     Strips SERVE_PREFIX if present.
  */
  function displayPath(pathname) {
    const p = pathname.startsWith(SERVE_PREFIX)
      ? pathname.slice(SERVE_PREFIX.length)
      : pathname;
    return normalise(p);
  }

  /* ── extension ───────────────────────────────────────────────
     Returns the lowercase extension of a filename, or ''.
  */
  function extension(name) {
    const dot = name.lastIndexOf('.');
    return dot > 0 ? name.slice(dot + 1).toLowerCase() : '';
  }

  /* ── isNavigable ─────────────────────────────────────────────
     Returns true if this file should be opened as a real tab
     (served by SW) rather than previewed inline.
  */
  function isNavigable(name) {
    const ext = extension(name);
    return ext === 'html' || ext === 'htm';
  }

  return {
    SERVE_PREFIX,
    normalise,
    resolveRequest,
    toServeURL,
    isServeable,
    displayPath,
    extension,
    isNavigable,
  };

})();

/* Export for SW context (importScripts) and main-thread context (script tag) */
if (typeof module !== 'undefined') module.exports = GnokeResolver;
