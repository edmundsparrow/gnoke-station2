/* gnoke-zero-spirit.js — v1.0.0
   Pache's soul.
   Edmund Sparrow © 2026 — MIT

   Two species live here:

   1. 'zero-tree'     — identity: folder path (e.g. "/" or "/src")
                         essence:  [{name, kind}] — names only, no content
                         used for: instant ghost-render of tree shape
                         on revisit, before live handles are reacquired.

   2. 'zero-resolver' — identity: file path (e.g. "/src/app.js")
                         essence:  { parentPath, name } — enough for the
                         SW to know "this file lives under this folder,
                         walk from there" without re-walking from root.
                         The actual FileSystemFileHandle can't survive
                         death — but the SHAPE of where it lives can.

   Neither essence ever holds file content or live handles.
   Only shape. Shape is what survives death.
*/

'use strict';

window.GnokeZeroSpirit = (() => {

  const SPECIES_TREE     = 'zero-tree';
  const SPECIES_RESOLVER = 'zero-resolver';

  let _ready = false;

  async function init() {
    if (_ready) return;
    await GnokeHeartbeat.init([SPECIES_TREE, SPECIES_RESOLVER]);
    _ready = true;
  }

  /* ── Tree shape (per-folder) ─────────────────────────────────
     identity = folder path ("/" for root)
     essence  = [{name, kind}]  kind: 'file' | 'folder'          */

  function saveTreeShape(folderPath, entries) {
    const essence = entries.map(e => ({ name: e.name, kind: e.kind }));
    return GnokeHeartbeat.put(SPECIES_TREE, folderPath, essence);
  }

  function loadTreeShape(folderPath) {
    return GnokeHeartbeat.get(SPECIES_TREE, folderPath);
  }

  /* ── Resolver shape (per-file) ───────────────────────────────
     identity = file path ("/src/app.js")
     essence  = { parentPath, name }
     Lets the resolver skip to the nearest known parent instead
     of walking from root every time.                            */

  function saveResolverShape(filePath, parentPath) {
    const name = filePath.split('/').pop();
    return GnokeHeartbeat.put(SPECIES_RESOLVER, filePath, { parentPath, name });
  }

  function loadResolverShape(filePath) {
    return GnokeHeartbeat.get(SPECIES_RESOLVER, filePath);
  }

  /* ── Ghost render check ───────────────────────────────────────
     Returns true if this folder has ever been seen before —
     i.e. there's a ghost available to render while the live
     handle is being reacquired.                                  */
  async function hasGhost(folderPath) {
    const shape = await loadTreeShape(folderPath);
    return shape !== null;
  }

  return {
    init,
    saveTreeShape, loadTreeShape,
    saveResolverShape, loadResolverShape,
    hasGhost,
  };

})();
