/* gnoke-zero-sw.js — v2.0.0
   Gnoke-Zero — Lazy Resolver Service Worker
   Edmund Sparrow © 2026 — MIT

   THE SHIFT FROM v1:
   - No pre-loaded VFS map. No full-folder read.
   - Holds the live root FileSystemDirectoryHandle (transferred from
     main thread on mount).
   - On fetch: walks path segments lazily via getDirectoryHandle /
     getFileHandle, only touching the folders actually requested.
   - Main thread heartbeats "shape" (names only) to IDB via
     gnoke-zero-spirit.js — this SW doesn't need to read that store
     directly; it just resolves live handles. The spirit layer is
     for the UI's ghost-tree, not for this SW's correctness.

   SERVING MODEL:
   - .html files opened via window.open() land here as real
     same-origin navigations (the opened URL is under this SW's
     scope, e.g. /serve/src/app.html).
   - All sub-resource fetches from that page (css/js/img with
     relative paths) also fall under this scope and get resolved
     the same lazy way.
*/

'use strict';

const SW_VERSION = '2.0.0';
const SERVE_PREFIX = '/serve'; // URLs under this prefix are resolved against the mounted root

/* ── Root handle (transferred from main thread on mount) ──────── */
let _root = null; // FileSystemDirectoryHandle
let _rootLabel = '';

/* ── MIME map ───────────────────────────────────────────────── */
const MIME = {
  html:'text/html; charset=utf-8', htm:'text/html; charset=utf-8',
  css:'text/css; charset=utf-8', js:'application/javascript; charset=utf-8',
  mjs:'application/javascript; charset=utf-8', json:'application/json; charset=utf-8',
  svg:'image/svg+xml; charset=utf-8', txt:'text/plain; charset=utf-8',
  md:'text/plain; charset=utf-8', png:'image/png', jpg:'image/jpeg',
  jpeg:'image/jpeg', gif:'image/gif', webp:'image/webp', ico:'image/x-icon',
  woff:'font/woff', woff2:'font/woff2', ttf:'font/ttf',
};
function _mime(path) {
  const ext = (path.split('.').pop() || '').toLowerCase();
  return MIME[ext] || 'application/octet-stream';
}

/* ── Install / Activate ────────────────────────────────────── */
self.addEventListener('install', () => {
  console.info(`[gnoke-zero-sw] v${SW_VERSION} installed`);
  self.skipWaiting();
});
self.addEventListener('activate', e => {
  console.info('[gnoke-zero-sw] activated');
  e.waitUntil(self.clients.claim());
});

/* ── Message handler ──────────────────────────────────────────
   ROOT_MOUNT — main thread transfers the live directory handle
   ROOT_EJECT — clear it, back to pass-through                  */
self.addEventListener('message', evt => {
  const { cmd, handle, label } = evt.data || {};

  if (cmd === 'ROOT_MOUNT') {
    _root = handle;
    _rootLabel = label || 'project';
    console.info(`[gnoke-zero-sw] root mounted: "${_rootLabel}"`);
    evt.source?.postMessage({ event: 'ROOT_READY', label: _rootLabel });
    return;
  }

  if (cmd === 'ROOT_EJECT') {
    _root = null;
    _rootLabel = '';
    console.info('[gnoke-zero-sw] root ejected');
    evt.source?.postMessage({ event: 'ROOT_CLEARED' });
    return;
  }

  if (cmd === 'ROOT_STATUS') {
    evt.source?.postMessage({ event: 'ROOT_STATUS', mounted: _root !== null, label: _rootLabel });
    return;
  }
});

/* ── Fetch interceptor ─────────────────────────────────────── */
self.addEventListener('fetch', evt => {
  const url = new URL(evt.request.url);

  if (!_root) return; // pass-through, nothing mounted
  if (evt.request.method !== 'GET') return;
  if (url.origin !== self.location.origin) return;
  if (!url.pathname.startsWith(SERVE_PREFIX)) return;

  evt.respondWith(_resolveAndServe(url.pathname));
});

/* ── Lazy path walk ────────────────────────────────────────────
   /serve/src/app.html → ['src','app.html']
   Walks getDirectoryHandle for each segment except the last,
   then getFileHandle for the last. Only touches folders on
   the requested path — true lazy resolution.                   */
async function _resolveAndServe(pathname) {
  let relPath = pathname.slice(SERVE_PREFIX.length); // "/src/app.html"
  if (relPath === '' || relPath === '/') relPath = '/index.html';

  // Trailing slash = directory index request (e.g. /New folder/)
  if (relPath.endsWith('/')) relPath += 'index.html';

  // Clean-URL: no extension AND no trailing slash → try .html
  const lastSeg = relPath.split('/').pop();
  if (lastSeg && !lastSeg.includes('.')) relPath += '.html';

  const segments = relPath.split('/').filter(Boolean);
  const fileName = segments.pop();

  try {
    let dir = _root;
    for (const seg of segments) {
      dir = await dir.getDirectoryHandle(seg);
    }
    const fileHandle = await dir.getFileHandle(fileName);
    const file = await fileHandle.getFile();
    const buf  = await file.arrayBuffer();

    return new Response(buf, {
      status: 200,
      headers: {
        'Content-Type': _mime(fileName),
        'Cache-Control': 'no-store',
        'X-Gnoke-Zero': 'lazy-resolve',
      }
    });
  } catch (e) {
    return _404(relPath, e.message);
  }
}

/* ── 404 ───────────────────────────────────────────────────── */
function _404(path, reason) {
  const html = `<!DOCTYPE html><html><head><meta charset="utf-8">
<style>
:root{--bg:#f0f5fb;--text:#1a2e44;--text-2:#4a6480;--blue-1:#86b4e4;--blue-2:#3f6e9b;--border:#d8e6f2}
*{box-sizing:border-box;margin:0;padding:0}
body{font-family:'Outfit',system-ui,sans-serif;background:var(--bg);color:var(--text);
  min-height:100vh;display:flex;align-items:center;justify-content:center}
.card{background:#fff;border:1px solid var(--border);border-radius:16px;padding:32px;max-width:420px;width:90%;text-align:center}
.card::before{content:'⬡';display:block;width:48px;height:48px;background:linear-gradient(135deg,var(--blue-1),var(--blue-2));
  border-radius:12px;margin:0 auto 20px;font-size:22px;line-height:48px;color:#fff}
h1{font-size:18px;font-weight:700;margin-bottom:8px}
p{font-size:13px;color:var(--text-2);line-height:1.6}
code{font-family:monospace;font-size:12px;background:var(--bg);padding:2px 6px;border-radius:4px;border:1px solid var(--border)}
</style></head><body><div class="card">
<h1>404 — Not Found</h1>
<p>Gnoke-Zero couldn't resolve <code>${path}</code> in the mounted project.</p>
<p style="margin-top:10px;font-size:11px;color:var(--text-3,#8aa3bc)">${reason}</p>
</div></body></html>`;
  return new Response(html, { status: 404, headers: { 'Content-Type': 'text/html; charset=utf-8' } });
}
