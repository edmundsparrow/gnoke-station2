/* gnoke-heartbeat.js — v1.0.0
   THE SPIRIT LAW
   Edmund Sparrow © 2026 — MIT

   Nothing is lost. Every unit that can die defines:
     - identity   : string                 — the soul's key
     - essence()  : () => serialisable     — minimal state worth keeping
     - reincarnate: (essence) => void       — how to come back

   On heartbeat (debounced "about to lose state"):
     store.put(identity, essence())

   On birth:
     essence = store.get(identity)
     if essence: reincarnate(essence)

   One IDB database, many stores (one per "species" of unit).
   The store name is the species. The identity is the soul.
*/

'use strict';

window.GnokeHeartbeat = (() => {

  const DB_NAME = 'gnoke:spirit';
  const VERSION = 1;

  /* Stores are created lazily — pass the species names you'll use
     up front via init(), or rely on auto-upgrade (slower, causes
     a version bump + reload on first use of a new species). */
  let _db = null;
  let _knownStores = new Set();

  function _openDB(stores) {
    return new Promise((resolve, reject) => {
      const req = indexedDB.open(DB_NAME, VERSION + _versionBump(stores));
      req.onupgradeneeded = e => {
        const db = e.target.result;
        for (const s of stores) {
          if (!db.objectStoreNames.contains(s)) db.createObjectStore(s);
        }
      };
      req.onsuccess = e => resolve(e.target.result);
      req.onerror   = e => reject(e.target.error);
    });
  }

  /* Crude version bump: stored in localStorage-free way via IDB itself
     would be circular, so we keep it simple — species set is fixed
     per app via init(). This avoids reload-on-upgrade churn. */
  let _versionOverride = 0;
  function _versionBump() { return _versionOverride; }

  /* ── Public: init ────────────────────────────────────────────
     Call once with the list of species (store names) this app
     will ever use. Opens (or creates) the DB with all of them. */
  let _initPromise = null;

  async function init(species = []) {
    species.forEach(s => _knownStores.add(s));
    if (_db) return true; // already open — species are fixed for the session
    if (_initPromise) return _initPromise;
    _versionOverride = 1;
    _initPromise = _openDB([..._knownStores]).then(db => { _db = db; return true; });
    return _initPromise;
  }

  function _tx(store, mode) {
    if (!_db) throw new Error('[heartbeat] not initialised — call GnokeHeartbeat.init([...species]) first');
    return _db.transaction(store, mode).objectStore(store);
  }

  /* ── Core ops ────────────────────────────────────────────────
     species = store name (e.g. 'zero-tree', 'zero-resolver')
     identity = key (e.g. '/Projects/myapp')
     essence  = any structured-cloneable value                  */

  function put(species, identity, essence) {
    return new Promise((resolve, reject) => {
      try {
        const r = _tx(species, 'readwrite').put(essence, identity);
        r.onsuccess = () => resolve();
        r.onerror   = e => reject(e.target.error);
      } catch (e) { reject(e); }
    });
  }

  function get(species, identity) {
    return new Promise((resolve, reject) => {
      try {
        const r = _tx(species, 'readonly').get(identity);
        r.onsuccess = e => resolve(e.target.result ?? null);
        r.onerror   = e => reject(e.target.error);
      } catch (e) { resolve(null); } // species not ready — treat as no essence
    });
  }

  function del(species, identity) {
    return new Promise((resolve, reject) => {
      try {
        const r = _tx(species, 'readwrite').delete(identity);
        r.onsuccess = () => resolve();
        r.onerror   = e => reject(e.target.error);
      } catch (e) { resolve(); }
    });
  }

  function keys(species) {
    return new Promise((resolve, reject) => {
      try {
        const r = _tx(species, 'readonly').getAllKeys();
        r.onsuccess = e => resolve(e.target.result);
        r.onerror   = e => reject(e.target.error);
      } catch (e) { resolve([]); }
    });
  }

  /* ── Debounced heartbeat helper ─────────────────────────────
     Returns a function you call on every "something changed"
     signal. It coalesces rapid signals into one write. */
  function pulse(species, identity, essenceFn, delay = 300) {
    let t;
    return () => {
      clearTimeout(t);
      t = setTimeout(() => put(species, identity, essenceFn()), delay);
    };
  }

  /* ── Reincarnation helper ───────────────────────────────────
     Fetch essence and apply it if present. No-op if nothing
     was ever stored — birth proceeds normally. */
  async function reincarnate(species, identity, applyFn) {
    const essence = await get(species, identity);
    if (essence !== null) applyFn(essence);
    return essence;
  }

  return { init, put, get, del, keys, pulse, reincarnate };

})();
