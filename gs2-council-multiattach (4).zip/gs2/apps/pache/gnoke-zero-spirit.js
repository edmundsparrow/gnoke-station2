/* gnoke-zero-spirit.js — v2.0.0
   Gnoke-Zero / Pache — Spirit (persistence layer)
   Edmund Sparrow © 2026 — MIT

   MANDATE (from zero.md — storage.js role):
   - IndexedDB access
   - Root-specific settings
   - Cached metadata (shape only — never content, never live handles)

   Two species:

   'zero-tree'     — shape of a folder at a path
                     identity: folder path (e.g. '/' or '/src')
                     essence:  [{name, kind}]
                     purpose:  ghost-render the tree before live
                               handles are reacquired

   'zero-resolver' — parent hint per file
                     identity: file path (e.g. '/src/app.js')
                     essence:  { parentPath, name }
                     purpose:  optimisation — skip to nearest
                               known parent instead of walking
                               from root every time

   Neither species holds file content or live handles.
   Only shape. Shape is what survives death.

   pache-client.js calls this — not index.html.
   resolver.js does not call this — it is pure logic.
*/

'use strict';

window.GnokeZeroSpirit = (() => {

  const SPECIES_TREE     = 'zero-tree';
  const SPECIES_RESOLVER = 'zero-resolver';

  let _ready = false;

  async function init() {
    if (_ready) return;
    await GnokeHeartbeat.init([SPECIES_TREE, SPECIES_RESOLVER]);
    _ready = true;
  }

  /* ── Tree shape ──────────────────────────────────────────────
     Called by pache-client.readLevel() after listing a folder.
     Saves [{name, kind}] — enough to ghost-render the tree.    */
  function saveTreeShape(folderPath, entries) {
    const essence = entries.map(e => ({ name: e.name, kind: e.kind }));
    return GnokeHeartbeat.put(SPECIES_TREE, folderPath, essence);
  }

  function loadTreeShape(folderPath) {
    return GnokeHeartbeat.get(SPECIES_TREE, folderPath);
  }

  /* ── Resolver shape ──────────────────────────────────────────
     Called by pache-client.readLevel() for each file.
     Saves { parentPath, name } — a navigation hint.
     Resolver.js does NOT call this — it is pure path logic.
     The client calls this as a side-effect of directory listing.*/
  function saveResolverShape(filePath, parentPath) {
    const name = filePath.split('/').pop();
    return GnokeHeartbeat.put(SPECIES_RESOLVER, filePath, { parentPath, name });
  }

  function loadResolverShape(filePath) {
    return GnokeHeartbeat.get(SPECIES_RESOLVER, filePath);
  }

  /* ── Ghost check ─────────────────────────────────────────────
     Returns true if this folder has ever been seen — i.e. a
     ghost is available to render while handles are reacquired.  */
  async function hasGhost(folderPath) {
    const shape = await loadTreeShape(folderPath);
    return shape !== null;
  }

  return {
    init,
    saveTreeShape,
    loadTreeShape,
    saveResolverShape,
    loadResolverShape,
    hasGhost,
  };

})();
