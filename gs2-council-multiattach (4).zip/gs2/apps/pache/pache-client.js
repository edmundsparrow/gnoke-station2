/* pache-client.js — v2.0.0
   Gnoke-Zero / Pache — Controller and bridge.
   Edmund Sparrow © 2026 — MIT

   MANDATE (from zero.md):
   - Mount root (acquire handle only — read NOTHING)
   - Expand a folder on demand (click → read that level only)
   - Sync shape to spirit AFTER a level is read (not before)
   - Communicate with Service Worker

   LAZY LAW:
   Mount gives you a handle. That is all.
   The root folder appears in the tree as a surface — name only.
   No directory read happens until the user clicks a folder.
   No folder is pre-loaded, pre-cached, or pre-snapshotted.
   Shape is saved to spirit only AFTER the user opens a folder —
   not speculatively.

   The client is the authority on mounted state.
   The UI reads state from the client.
   The SW receives handles from the client.
*/

'use strict';

window.PacheClient = (() => {

  let _rootHandle = null;
  let _rootName   = '';
  let _swReady    = false;
  let _listeners  = {};

  /* ── Events ─────────────────────────────────────────────── */
  function on(event, fn) {
    (_listeners[event] = _listeners[event] || []).push(fn);
  }
  function _emit(event, data) {
    (_listeners[event] || []).forEach(fn => fn(data));
  }

  /* ── Service Worker ──────────────────────────────────────── */
  async function initSW() {
    if (!('serviceWorker' in navigator)) {
      _emit('sw:error', { reason: 'not-supported' });
      return false;
    }
    try {
      await navigator.serviceWorker.register('./gnoke-zero-sw.js', { scope: './' });
      await navigator.serviceWorker.ready;
      _swReady = true;
      _emit('sw:ready');
      return true;
    } catch (e) {
      _emit('sw:error', { reason: e.message });
      return false;
    }
  }

  function _postSW(msg) {
    if (_swReady && navigator.serviceWorker.controller) {
      navigator.serviceWorker.controller.postMessage(msg);
    }
  }

  /* ── Mount ───────────────────────────────────────────────────
     Acquires the root handle ONLY.
     Does NOT read any directory entries.
     Does NOT save any shape to spirit.
     Does NOT send anything to the SW yet — the SW gets the
     handle only after the user navigates to a file.
     The UI receives just { name, handle } — enough to draw
     the root row as a closed folder surface.                  */
  async function mount() {
    if (!('showDirectoryPicker' in window)) {
      _emit('mount:error', { reason: 'Folder picker not supported in this browser' });
      return false;
    }
    try {
      const handle = await window.showDirectoryPicker({ mode: 'read' });
      _rootHandle  = handle;
      _rootName    = handle.name;

      // SW gets the handle now so it is ready when files are opened
      _postSW({ cmd: 'ROOT_MOUNT', handle, label: _rootName });

      _emit('mount:success', { name: _rootName, handle });
      return true;
    } catch (e) {
      if (e.name !== 'AbortError') {
        _emit('mount:error', { reason: e.message });
      }
      return false;
    }
  }

  /* ── Eject ───────────────────────────────────────────────── */
  function eject() {
    _rootHandle = null;
    _rootName   = '';
    _postSW({ cmd: 'ROOT_EJECT' });
    _emit('mount:eject');
  }

  /* ── expandFolder ────────────────────────────────────────────
     Called ONLY when the user clicks a folder row.
     Reads exactly one directory level — no more.
     Saves shape to spirit AFTER reading (not before).
     Returns [{name, kind, handle}] sorted folders-first.

     This is the ONLY place directory enumeration happens.
     index.html never touches FileSystem API directly.         */
  async function expandFolder(dirHandle, folderPath) {
    const entries = [];
    for await (const [name, entry] of dirHandle.entries()) {
      entries.push({ name, kind: entry.kind, handle: entry });
    }
    entries.sort((a, b) => {
      if (a.kind !== b.kind) return a.kind === 'directory' ? -1 : 1;
      return a.name.localeCompare(b.name);
    });

    // Save shape AFTER read — not speculatively
    await GnokeZeroSpirit.saveTreeShape(
      folderPath,
      entries.map(e => ({ name: e.name, kind: e.kind }))
    );

    return entries;
  }

  /* ── openFile ────────────────────────────────────────────────
     Navigable (.html/.htm) → real tab via SW resolver.
     Everything else → read content once, return for inline preview.
     Root awareness: path always root-relative, URL via resolver. */
  async function openFile(rootRelativePath) {
    const name = rootRelativePath.split('/').pop();

    if (GnokeResolver.isNavigable(name)) {
      if (!_swReady) return { type: 'error', reason: 'Service Worker not ready' };
      const url = GnokeResolver.toServeURL(rootRelativePath);
      window.open(url, '_blank');
      return { type: 'navigated', url };
    }

    try {
      const file = await _walkToFile(rootRelativePath);
      const ext  = GnokeResolver.extension(name);
      const isImg = /^(png|jpe?g|gif|webp|svg|ico)$/.test(ext);

      if (isImg) {
        return { type: 'image', name, path: rootRelativePath,
                 objectUrl: URL.createObjectURL(file) };
      } else {
        const text = await file.text();
        return { type: 'text', name, path: rootRelativePath, text };
      }
    } catch (e) {
      return { type: 'error', reason: e.message };
    }
  }

  /* ── _walkToFile ─────────────────────────────────────────────
     Walks from _rootHandle using resolver segments.
     Only for non-HTML inline preview — never called on navigation. */
  async function _walkToFile(rootRelativePath) {
    if (!_rootHandle) throw new Error('No root mounted');
    const { segments, fileName } = GnokeResolver.resolveRequest(rootRelativePath);
    let dir = _rootHandle;
    for (const seg of segments) dir = await dir.getDirectoryHandle(seg);
    const fh = await dir.getFileHandle(fileName);
    return fh.getFile();
  }

  /* ── Accessors ───────────────────────────────────────────── */
  function isMounted()   { return _rootHandle !== null; }
  function getRootName() { return _rootName; }
  function getRootHandle(){ return _rootHandle; }
  function isSWReady()   { return _swReady; }

  /* ── init ────────────────────────────────────────────────── */
  async function init() {
    await GnokeZeroSpirit.init();
    await initSW();
  }

  return {
    init,
    mount,
    eject,
    expandFolder,
    openFile,
    isMounted,
    getRootName,
    getRootHandle,
    isSWReady,
    on,
  };

})();
