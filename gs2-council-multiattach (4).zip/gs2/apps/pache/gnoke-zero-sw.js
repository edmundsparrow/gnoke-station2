/* gnoke-zero-sw.js — v3.0.0
   Gnoke-Zero / Pache — Service Worker (Interceptor)
   Edmund Sparrow © 2026 — MIT

   MANDATE (from zero.md):
   - Intercept fetches
   - Apply resolved canonical paths  ← via resolver.js
   - Serve VFS resources

   Must not contain UI knowledge.
   Must not become configuration storage.
   Must not own root awareness logic — that is resolver.js's job.

   DEPENDENCY:
   resolver.js is importScripts'd here so that ALL path logic
   lives in one place. The SW calls GnokeResolver.resolveRequest()
   exactly the same way the client does — no duplicated logic.
*/

'use strict';

importScripts('./resolver.js');

const SW_VERSION = '3.0.0';

/* ── Root handle (transferred from pache-client on mount) ─────
   The client is the authority on mounted state.
   The SW receives it — it does not manage it.             */
let _root      = null;
let _rootLabel = '';

/* ── MIME map ─────────────────────────────────────────────── */
const MIME = {
  html:'text/html; charset=utf-8',     htm:'text/html; charset=utf-8',
  css:'text/css; charset=utf-8',       js:'application/javascript; charset=utf-8',
  mjs:'application/javascript; charset=utf-8', json:'application/json; charset=utf-8',
  svg:'image/svg+xml; charset=utf-8',  txt:'text/plain; charset=utf-8',
  md:'text/plain; charset=utf-8',      png:'image/png',
  jpg:'image/jpeg',                    jpeg:'image/jpeg',
  gif:'image/gif',                     webp:'image/webp',
  ico:'image/x-icon',                  woff:'font/woff',
  woff2:'font/woff2',                  ttf:'font/ttf',
};
function _mime(fileName) {
  const ext = GnokeResolver.extension(fileName);
  return MIME[ext] || 'application/octet-stream';
}

/* ── Install / Activate ──────────────────────────────────── */
self.addEventListener('install', () => {
  console.info(`[gnoke-zero-sw] v${SW_VERSION} installed`);
  self.skipWaiting();
});
self.addEventListener('activate', e => {
  console.info('[gnoke-zero-sw] activated');
  e.waitUntil(self.clients.claim());
});

/* ── Message handler ─────────────────────────────────────────
   ROOT_MOUNT  — client transfers live DirectoryHandle
   ROOT_EJECT  — clear, back to pass-through
   ROOT_STATUS — health check                                  */
self.addEventListener('message', evt => {
  const { cmd, handle, label } = evt.data || {};

  if (cmd === 'ROOT_MOUNT') {
    _root      = handle;
    _rootLabel = label || 'project';
    console.info(`[gnoke-zero-sw] root mounted: "${_rootLabel}"`);
    evt.source?.postMessage({ event: 'ROOT_READY', label: _rootLabel });
    return;
  }

  if (cmd === 'ROOT_EJECT') {
    _root      = null;
    _rootLabel = '';
    console.info('[gnoke-zero-sw] root ejected');
    evt.source?.postMessage({ event: 'ROOT_CLEARED' });
    return;
  }

  if (cmd === 'ROOT_STATUS') {
    evt.source?.postMessage({
      event: 'ROOT_STATUS',
      mounted: _root !== null,
      label: _rootLabel,
      version: SW_VERSION,
    });
    return;
  }
});

/* ── Fetch interceptor ───────────────────────────────────────
   Only intercepts GET requests under SERVE_PREFIX.
   Everything else passes through unchanged.
   Root awareness check: if no root, always pass through.     */
self.addEventListener('fetch', evt => {
  const url = evt.request.url;
  const parsed = new URL(url);

  if (!_root)                                          return;
  if (evt.request.method !== 'GET')                    return;
  if (parsed.origin !== self.location.origin)          return;
  if (!GnokeResolver.isServeable(parsed.pathname))     return;

  evt.respondWith(_serve(parsed.pathname));
});

/* ── _serve ──────────────────────────────────────────────────
   Delegates ALL path logic to GnokeResolver.resolveRequest().
   Walks from root lazily — only touching folders on the path.
   No path logic here. Resolver is the single source of truth. */
async function _serve(pathname) {
  const { segments, fileName, resolvedPath } =
    GnokeResolver.resolveRequest(pathname);

  try {
    let dir = _root;
    for (const seg of segments) {
      dir = await dir.getDirectoryHandle(seg);
    }
    const fileHandle = await dir.getFileHandle(fileName);
    const file       = await fileHandle.getFile();
    const buf        = await file.arrayBuffer();

    return new Response(buf, {
      status: 200,
      headers: {
        'Content-Type':  _mime(fileName),
        'Cache-Control': 'no-store',
        'X-Gnoke-Zero':  'lazy-resolve',
        'X-Resolved':    resolvedPath,
      },
    });
  } catch (e) {
    return _404(resolvedPath, e.message);
  }
}

/* ── 404 ─────────────────────────────────────────────────── */
function _404(path, reason) {
  const html = `<!DOCTYPE html><html><head><meta charset="utf-8">
<style>
:root{--bg:#f0f5fb;--text:#1a2e44;--text-2:#4a6480;--blue-1:#86b4e4;--blue-2:#3f6e9b;--border:#d8e6f2}
*{box-sizing:border-box;margin:0;padding:0}
body{font-family:'Outfit',system-ui,sans-serif;background:var(--bg);color:var(--text);
  min-height:100vh;display:flex;align-items:center;justify-content:center}
.card{background:#fff;border:1px solid var(--border);border-radius:16px;padding:32px;max-width:420px;width:90%;text-align:center}
.card::before{content:'⬡';display:block;width:48px;height:48px;background:linear-gradient(135deg,var(--blue-1),var(--blue-2));
  border-radius:12px;margin:0 auto 20px;font-size:22px;line-height:48px;color:#fff}
h1{font-size:18px;font-weight:700;margin-bottom:8px}
p{font-size:13px;color:var(--text-2);line-height:1.6}
code{font-family:monospace;font-size:12px;background:var(--bg);padding:2px 6px;border-radius:4px;border:1px solid var(--border)}
</style></head><body><div class="card">
<h1>404 — Not Found</h1>
<p>Gnoke-Zero couldn't resolve <code>${path}</code> in the mounted project.</p>
<p style="margin-top:10px;font-size:11px;color:#8aa3bc">${reason}</p>
</div></body></html>`;
  return new Response(html, {
    status: 404,
    headers: { 'Content-Type': 'text/html; charset=utf-8' },
  });
}
