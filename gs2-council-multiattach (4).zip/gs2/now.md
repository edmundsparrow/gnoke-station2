# now.md — Session Continuity Pointer
> Read this FIRST, before gnoke-doc.md, before gs2f.md. This is the only file
> that changes every session, and it should be getting SHORTER, not longer —
> it tracks distance to "station ready", not project history.

---

## What Gnoke Station 2 is

A browser-native OS shell. Tabs are processes. Apps are isolated pages that
communicate through a SharedWorker bus (`firmware/gnoke-worker.js`). The
firmware layer handles capability authority, hardware leasing, and syscall
routing. The system layer (`sys2026/`) handles boot, auth, app registry,
launcher, and per-app database access. Apps live in `apps/` and `system/`
and know nothing about the engine below them — they only call `AppDB` and
`GnokeCore`.

---

## Where we are

**Firmware — 11 scripts, stable.**
**sys2026 — 9 scripts, stable.**

**Storage — fully on IDB. No localStorage in production code.**
- `GnokeFirmware` IDB (v2): `kernel` store (worker topology) + `config`
  store (PIDs, UID). Used by firmware and auth.
- `GnokeStore` IDB (v1): `app-data` + `sessions` stores. Used by all apps
  via `AppDB = GnokeSysDB(appId)`.
- `sessionStorage`: auth session flag only (`gnoke:authed`). Intentional —
  auth state should not survive a browser restart.

**apps.js registry — 23 entries, all paths verified.**

**System apps:**
- `system/debug/` — complete and registered.
- `system/settings/` — HTML shell only, no JS yet.
- `system/terminal/` — icon only, no implementation.
- `system/dictionary/` — empty slot, no decision yet.

**Process bus — stable.** Heartbeat 20s, TTL 65s, ping-on-hide,
PID in `GnokeFirmware/config` IDB, singleton eviction on reconnect.

**`sys2026/sysdb.js` is IDB-only.** OPFS/sql.js upgrade designed in
`help/gs2f.md` but not yet wired in.

**Push Notifications not yet implemented.**

Distance to "station ready": unknown — run it, audit what breaks, then
measure the closure rate.

---

## Active blockers

- **OPFS/sql.js engine not wired into `sys2026/sysdb.js`** — factory swap
  fully designed in `help/gs2f.md`. Needs implementation + Chromium testing.

- **`system/settings/` has no JS** — HTML shell exists, no logic wired.

- **`system/terminal/` is empty** — icon only, url '#'. Build it or remove.

- **`system/dictionary/` is an empty folder** — no decision yet.

- **Push Notifications (Service Worker + Push API)** — not started.

---

## Last things fixed

**App switcher injected into all apps via gnoke-presence.js (most recent):**
- Clicking the sys-pill in any app topbar opens a live tray of running apps.
- Click any entry → `window.open(url, 'gnoke-<id>')` focuses that window directly.
  No bouncing through home/launcher to switch apps.
- `⌂ Home` link in tray header goes to launcher if needed.
- Tray driven by `GnokeClient.onRegistry()` — updates live as apps open/close.
- `gnoke-core.js` now passes `url` (pathname) in meta on REGISTER so the
  worker registry carries enough info to build switcher entries.
- All 9 app gnoke-presence.js copies regenerated from updated template.

**apps.js sorted alphabetically within each category (previous):**
- All 4 categories (Apps, Web, Games, System) now sorted A→Z by name.

**localStorage fully removed from production code (previous):**
- All PID storage moved to `GnokeFirmware/config` IDB (v2). Affects
  `gnoke-client.js`, `launcher.js` inline client, `debug/index.html`
  inline client — all now carry a `_fwDB` helper that opens the same DB.
- `GnokeFirmware` bumped to version 2: `config` store added alongside
  `kernel`. Worker, client, and auth all open at v2.
- `auth.js` UID moved from `localStorage` to `GnokeFirmware/config` IDB.
  `backup.js` reads UID from same store.
- `council/menu.js` pins → `AppDB.put/get('pins')`.
- `geocompass/js/speed.js` odometer + unit → `AppDB`.
- `system/settings/index.html` grid preference → `GnokeStore` IDB directly.
- `reset.js` updated: clears `localStorage` + `sessionStorage` on nuke
  (belt-and-suspenders alongside the IDB wipes).
- All stale `.md` docs and info panels updated to reflect IDB storage.

**Ghost tabs / stale session reconnection (previous):**
- PID in `localStorage` → now `GnokeFirmware/config` IDB (superseded above).
- Worker REGISTER does singleton eviction on `appId` match.
- `gnoke-core.js` passes `appId` + `maxInstances` to worker.
- `APP_MAX_INSTANCES` added to all `gnoke-presence.js` copies.

---

## Stable decisions (do not re-litigate)

1. Apps never know which storage engine is active — they only call `AppDB`.
2. Firmware scripts use `importScripts` — no ES module syntax in `/firmware/`.
3. App types TYPE A / B / C are fixed. See `gnoke-doc.md`.
4. Topbar standard is mandatory for all apps — no exceptions.
5. `gnoke-presence.js` — apps change exactly four fields: `APP_ID`,
   `APP_VERSION`, `APP_CAPS`, `APP_MAX_INSTANCES`. Nothing else changes.
6. App manifests are always `gnoke.json` — never `.json.js`.
7. No `localStorage` in production code. Firmware identity (PIDs, UID) →
   `GnokeFirmware/config` IDB. App data → `GnokeStore` via `AppDB`.
   `sessionStorage` for auth session flag only — intentional, short-lived.

---

## Rule for whoever edits this file next

When a blocker closes, delete it — don't add a "closed" line.
Keep only the two most recent entries in "Last things fixed", trim older ones.
When a new blocker is found, add it here, but check `gnoke-doc.md` first.
This file should trend toward empty. Empty = station ready.
