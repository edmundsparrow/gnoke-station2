# Gnoke Station 2 — Developer Reference

> Single source of truth for building apps on Gnoke Station 2.
> Firmware layer, system layer, app patterns, topbar standard, script loading rules.

---

## Table of Contents

### Firmware (`/firmware/`)
- [gnoke-worker.js](#gnoke-workerjs) — System Bus — SharedWorker entry point
- [gnoke-kernel.js](#gnoke-kerneljs) — Capability Authority Kernel
- [gnoke-hal.js](#gnoke-haljs) — Hardware Abstraction Layer
- [gnoke-shell.js](#gnoke-shelljs) — Privileged Shell Process — PID 1
- [gnoke-syscall.js](#gnoke-syscalljs) — Syscall Abstraction Layer
- [gnoke-client.js](#gnoke-clientjs) — Tab Process Stub — Bus Connection
- [gnoke-core.js](#gnoke-corejs) — Universal App Bridge — High-Level API
- [gnoke-spirit.js](#gnoke-spiritjs) — UI State Resurrection — Form Persistence
- [policy.js](#policyjs) — Governance and Access Control Layer
- [reset.js](#resetjs) — Factory Reset

### System (`/sys2026/`)
- [boot.js](#bootjs) — System Boot Coordinator — App Script Loader
- [sysdb.js](#sysdbjs) — System App Database
- [auth.js](#authjs) — Authentication & Session Management
- [config.js](#configjs) — App Config Resolver — Spawn Interceptor
- [backup.js](#backupjs) — Backup & Restore Utility
- [apps.js](#appsjs) — App Registry & Category Map
- [launcher.js](#launcherjs) — Station Launcher Logic

### App Layer
- [gnoke-presence.js](#gnoke-presencejs) — App Presence & Bus Registration
- [gnoke.json](#gnokejson) — App Manifest
- [menu.js](#menujs) — Hamburger Drawer (optional)

### App Patterns
- [Topbar Standard](#topbar-standard) — Required chrome for all apps
- [Script Loading](#script-loading) — boot.js vs TYPE C
- [App Types](#app-types) — TYPE A / B / C explained

---

## Firmware

### gnoke-worker.js
**System Bus — SharedWorker entry point — v2.0.0**

The SharedWorker entry point. Owns the process registry, heartbeat reaper, topology persistence, and message relay. Capability authority and syscall routing live in separate files imported alongside it.

```
importScripts('gnoke-kernel.js');   // ← required
importScripts('gnoke-hal.js');      // ← required for HAL
```

Separation of concerns:
- `gnoke-worker.js` — process registry, heartbeat, relay
- `gnoke-kernel.js` — capability registry, syscall routing

Philosophy: Active ports are truth. Persisted topology is advisory.

---

### gnoke-kernel.js
**Capability Authority Kernel — v2.0.0**

Lives inside the SharedWorker. Owns all capability authority so the bus file remains a pure message relay.

Commands handled:
- `CLAIM_CAPABILITY` — grants exclusive ownership to the calling port. First-port-wins.
- `RELEASE_CAPABILITY` — releases ownership.
- `SYSCALL` — kernel-routed call. The caller never learns the provider's PID.

`GnokeKernel.flush(pid)` — called by the bus when a process dies. Releases all capability leases and hardware locks.

---

### gnoke-hal.js
**Hardware Abstraction Layer — v1.0.0**

Acts as the "Registry of Occupation." Manages hardware leases (locks) to prevent multiple tabs from crashing exclusive browser ports (Serial, USB, Bluetooth).

```
GnokeHAL.acquire(pid, deviceId)   // claim a device
GnokeHAL.release(pid, deviceId)   // release a device
GnokeHAL.flush(pid)               // emergency cleanup on process death
```

---

### gnoke-shell.js
**Privileged Shell Process — PID 1 — v2.0.0**

The shell is the first tab. Only tab with elevated kernel capabilities. Owns the workspace FileSystem handle and services filesystem syscalls for all other tabs.

```js
await GnokeShell.boot();    // init on page load (before user gesture)
await GnokeShell.mount();   // open directory picker (requires user gesture)
await GnokeShell.wake();    // restore handle after reload
```

Syscall surface (handled automatically — no app code needed):
- `FS_WRITE { name, content }` — write file to workspace
- `FS_READ  { name }` — return file text content
- `FS_DELETE { name }` — delete file
- `FS_LIST  {}` — return array of filenames

---

### gnoke-syscall.js
**Syscall Abstraction Layer — v2.0.0**

Sits between app tabs and the kernel. Apps never address providers directly — they issue a named syscall which the kernel routes to whichever process has claimed the matching capability.

```js
await GnokeClient.boot({ name: 'my-app' });
GnokeSyscall.init();

// Write a file — routed to whoever owns 'filesystem'
await GnokeSyscall.call('filesystem', 'FS_WRITE', { name: 'notes.txt', content: 'Hello.' });

// Read a file
const { content } = await GnokeSyscall.call('filesystem', 'FS_READ', { name: 'notes.txt' });

// List workspace files
const { files } = await GnokeSyscall.call('filesystem', 'FS_LIST', {});

// Delete a file
await GnokeSyscall.call('filesystem', 'FS_DELETE', { name: 'notes.txt' });
```

Adding new capabilities:
```js
await GnokeClient.boot({ name: 'printer-svc' });
await GnokeClient.claimCapability('printer');
GnokeClient.on('SYSCALL', async ({ syscall, args, _callId, _replyTo }) => {
  GnokeClient.send(_replyTo, 'SYSCALL_REPLY', { _callId, result, error });
});
```

---

### gnoke-client.js
**Tab Process Stub — Bus Connection — v2.0.0**

Runs inside each tab. Connects the tab to the firmware bus, registers it as a named process with a PID, and handles resurrection on tab wake.

```js
// Boot (call once, before anything else)
await GnokeClient.boot({ name: 'my-app', meta: { role: 'guest_app' } });

// Send to a specific process
GnokeClient.send('pid-of-other-tab', 'MY_EVENT', { data });

// Broadcast to all processes
GnokeClient.broadcast('USER_SIGNED_OUT', {});

// Listen for messages
GnokeClient.on('MY_EVENT', (data, from) => { });

// Process lifecycle
GnokeClient.onProcessBorn((pid, meta) => { });
GnokeClient.onProcessDied((pid) => { });
GnokeClient.onRegistry((processes) => { });

// Get current registry snapshot
const procs = await GnokeClient.list();

// Current PID of this tab
GnokeClient.pid
```

---

### gnoke-core.js
**Universal App Bridge — High-Level API — v1.1.0**

The single call apps make to join the system. Wraps `GnokeClient.boot()` + `GnokeSyscall.init()` in one async call.

```js
await Gnoke.ready({
  name        : 'my-app',
  version     : '1.0.0',
  capabilities: [],
});
```

After `Gnoke.ready()` resolves, `GnokeClient` and `GnokeSyscall` are both live. `gnoke-presence.js` calls this for you — apps don't call it directly.

---

### gnoke-spirit.js
**UI State Resurrection — Form Persistence — v1.0.0**

Persists UI state (form values, scroll positions, open panels) to IndexedDB and restores them on next page load. Apps use it via `Gnoke.syncState()`.

---

### policy.js
**Governance and Access Control Layer — v2.0.0**

Enforces role-based access control for capability claims and syscall invocations. Lives inside the SharedWorker.

Role hierarchy:
- `operator` — PID 1 / shell. Full system access.
- `system` — Trusted first-party apps. Cannot own filesystem or HAL hardware locks.
- `guest_app` — Third-party apps. Cannot own exclusive resources. Blocked from destructive operations.

---

### reset.js
**Factory Reset — v2.0.0**

Wipes all persisted Gnoke state from the browser origin.

```js
await GnokeReset.nuke();
location.reload(); // optional — caller decides
```

---

## System

### boot.js
**System Boot Coordinator — App Script Loader — v1.0.0**

The single `<script>` tag every app includes. Loads the invariant system sequence, then app-declared scripts, then `gnoke-presence.js`.

**Load sequence (same for every app):**
1. `/firmware/gnoke-client.js`
2. `/firmware/gnoke-syscall.js`
3. `/firmware/gnoke-core.js`
4. `/sys2026/sysdb.js`
5. `/sys2026/gnoke-spirit.js`
6. App scripts declared in `<meta name="gnoke:scripts">`
7. `gnoke-presence.js` (app-local copy, always last)

**Usage in `index.html`:**
```html
<!-- Declare app scripts — boot.js loads these in order -->
<meta name="gnoke:scripts" content="js/data.js,js/ui.js,js/app.js,menu.js">

<!-- Single boot entry point -->
<script src="/sys2026/boot.js"></script>
```

**Important:** `boot.js` loads scripts dynamically after the page parses. This means `DOMContentLoaded` has already fired by the time your app scripts run. App scripts that need DOM-ready init must listen for `gnoke:boot` instead — dispatched by `gnoke-presence.js` after the full sequence completes.

```js
// ✗ Wrong for boot.js apps
document.addEventListener('DOMContentLoaded', () => { ... });

// ✓ Correct for boot.js apps
document.addEventListener('gnoke:boot', () => { ... });
```

See [TYPE C apps](#app-types) for the exception to this rule.

---

### sysdb.js
**System App Database — v1.0.0**

Single IndexedDB for all Gnoke apps. Apps never open their own IDB — they use `GnokeSysDB` namespaced to their `appId`. Provided automatically as `window.AppDB` after `gnoke-presence.js` runs.

```js
const db = GnokeSysDB('my-app');

// KV store
await db.put('draft', 'hello world');
await db.get('draft');
await db.delete('draft');
await db.list();

// Sessions store
await db.sessions.put({ id, title, ts, ...payload });
await db.sessions.getAll();
await db.sessions.delete(id);

// Factory reset
GnokeSysDB.nuke();
```

---

### auth.js
**Authentication & Session Management — v1.0.0**

IIFE. No imports, no dependencies. Blocks the station shell from rendering until the user authenticates. Supports PIN (SHA-256) and WebAuthn passkeys.

```html
<!-- Add before all other scripts in index.html to activate -->
<script src="/auth.js"></script>
```

---

### config.js
**App Config Resolver — Spawn Interceptor — v1.0.0**

Overrides `window.spawnApp` so every URL opened through the station goes through `gnoke.json` resolution before opening.

Tier detection:
- **Tier 1** — No `gnoke.json`. Unregistered process.
- **Tier 2** — `gnoke.json` found. Config stored, policy enforced.
- **Tier 3** — `gnoke.json` + app calls `Gnoke.ready()`. Full bus participation.

---

### backup.js
**Backup & Restore Utility — v1.0.0**

IIFE. No imports. Downloads / restores a full JSON backup of all spirit (persisted UI state) entries.

```js
await GnokeBackup.export();           // download backup JSON
await GnokeBackup.restore(fileObj);   // restore from File input
```

---

### apps.js
**App Registry & Category Map**

Single source of truth for the app grid. `index.html` reads `APPS` and `CATS` — it holds no app definitions of its own.

| Field | Type | Purpose |
|---|---|---|
| `id` | string | Unique identifier — tile key and bus process name |
| `name` | string | Display name on tile |
| `desc` | string | Tooltip / search text |
| `icon` | string | Emoji in tile icon box |
| `url` | string | Path opened on launch. `#` for unbuilt apps |
| `cat` | string | Category key — must match a key in `CATS` |
| `caps` | string[] | Capabilities this app intends to claim |
| `privileged` | boolean | `true` applies purple accent styling |

---

### launcher.js
**Station Launcher Logic**

All runtime logic for `index.html`. Owns: clock tick, bus pill state, `renderLauncher()`, `spawnApp()`, search input, custom process modal, `GnokeClient` boot sequence, live process registry sync.

Contains an inlined minified copy of `gnoke-client.js` at the top — intentional, the launcher is the first tab and cannot depend on an external load.

---

## App Layer

### gnoke-presence.js
**App Presence & Bus Registration — v1.1.0**

Standard bridge between any Gnoke app and the system bus. One file per app. Copy it into the app folder and change three fields.

```js
const APP_ID      = 'my-app';   // ← change this
const APP_VERSION = '1.0.0';    // ← change this
const APP_CAPS    = [];         // ← change this
```

Nothing else in the file changes. `boot.js` always loads it last.

After it runs:
- `GnokeClient` is booted and registered on the bus
- `window.AppDB` is a namespaced `GnokeSysDB` instance ready for use
- `sysPill` shows **Live** (green pulsing dot)

**Pill HTML required in `index.html`:**
```html
<div class="sys-pill" id="sysPill">
  <div class="sys-pill-dot"></div>
  <span id="sysPillLabel">Connecting</span>
</div>
```

---

### gnoke.json
**App Manifest**

```json
{
  "gnoke": "1.0",
  "appId": "my-app",
  "name": "My App",
  "version": "1.0.0",
  "role": "guest_app",
  "native": true,
  "capabilities": [],
  "description": "One-line description",
  "icon": "🔷",
  "author": "Your Name",
  "license": "MIT"
}
```

| Field | Values | Notes |
|---|---|---|
| `gnoke` | `"1.0"` | Spec version. Fixed. |
| `appId` | string | Lowercase hyphenated. Matches sysdb namespace. |
| `role` | `"operator"` / `"system"` / `"guest_app"` | Use `"guest_app"` for all new apps. |
| `native` | `true` | Always true for apps calling `Gnoke.ready()`. |
| `capabilities` | string[] | e.g. `["geolocation"]`. Advisory declaration. |

Real examples:

| App | role | capabilities |
|---|---|---|
| notes | `system` | `[]` |
| shopping-list | `system` | `[]` |
| council | `guest_app` | `[]` |
| geocompass | `guest_app` | `["geolocation"]` |

---

### menu.js
**Hamburger Drawer (optional)**

Drop-in side drawer for multi-page apps. Injects a `☰` toggle button as the first child of the topbar at runtime. Define pages in the `PAGES` array at the top of the file — nothing else changes.

```js
const PAGES = [
  { file: 'index',    label: 'Home',     icon: '🏠', sub: 'Main view'   },
  { file: 'history',  label: 'History',  icon: '📊', sub: 'Past records' },
  { file: 'settings', label: 'Settings', icon: '⚙️', sub: 'Preferences'  },
];
```

The hamburger is **always injected by `menu.js`** at runtime — never hardcoded in HTML. Declare `menu.js` last in `gnoke:scripts`.

---

## App Patterns

### Topbar Standard

Every app must include the standard Gnoke topbar. Copy this block as-is — only change the emoji and app name.

```html
<header id="topbar" class="topbar">
  <!-- ☰ injected here by menu.js at runtime, if used -->
  <a class="tb-logo" href="/index.html" title="Back to Station">
    <div class="tb-hex">🔷</div><!-- ← your app emoji -->
    <div class="tb-wordmark">Gnoke<small>APP NAME</small></div><!-- ← your app name -->
  </a>
  <div class="tb-sep"></div>
  <div class="tb-spacer"></div>
  <!-- Bus pill — driven by gnoke-presence.js — do not remove -->
  <div class="sys-pill" id="sysPill">
    <div class="sys-pill-dot"></div>
    <span id="sysPillLabel">Connecting</span>
  </div>
</header>
```

**Topbar left → right anatomy:**

| Element | Purpose | Required |
|---|---|---|
| `☰` (`.hmenu-toggle`) | Hamburger — injected by `menu.js` | Only if multi-page |
| `.tb-logo` → `/index.html` | Back to station home link | Always |
| `.tb-hex` | App emoji in blue gradient box | Always |
| `.tb-wordmark` | "Gnoke" + `<small>app name</small>` | Always |
| `.tb-sep` | 1px vertical separator | Always |
| *(app-specific content)* | e.g. `#context-info`, filename, identity bar | Optional |
| `.tb-spacer` | `flex: 1` push | Always |
| `.sys-pill` | Bus connection indicator | Always |

**Page title format:** `App Name — Gnoke` (app name first, Gnoke last, em-dash separator)

```html
<title>GeoCompass — Gnoke</title>
<title>Shopping List — Gnoke</title>
<title>Notepad — Gnoke</title>
```

---

### Script Loading

#### Standard pattern (TYPE A / B — bus-dependent apps)

Apps that store data or communicate across tabs use `boot.js`.

```html
<meta name="gnoke:scripts" content="js/data.js,js/ui.js,js/app.js,menu.js">
<script src="/sys2026/boot.js"></script>
```

App scripts must use `gnoke:boot` not `DOMContentLoaded`:

```js
// shopping-list, notes, council all do this
document.addEventListener('gnoke:boot', () => {
  // DOM is ready, firmware is loaded, AppDB is available
});
```

#### TYPE C pattern (tool apps — UI-first, no bus dependencies)

Apps whose entire UI renders with no bus data (e.g. geocompass) must not wait for `boot.js` to render. Their app scripts load synchronously so `DOMContentLoaded` fires correctly, and `boot.js` runs after just to connect the pill.

```html
<!-- App scripts — synchronous, DOMContentLoaded fires correctly -->
<script src="js/core.js"></script>
<script src="js/geo-compass.js"></script>
<script src="js/speed.js"></script>
<script src="js/app.js"></script>
<!-- boot.js loads async after — connects firmware + pill only -->
<script src="/sys2026/boot.js"></script>
```

No `gnoke:scripts` meta — boot.js finds none and only loads firmware + presence. App scripts use `DOMContentLoaded` as normal.

**When to use TYPE C:** Your app renders meaningful UI with zero data from the bus or AppDB on first paint. The compass, a calculator, a converter — anything that works immediately.

**When to use boot.js with gnoke:boot:** Your app needs AppDB data to render its initial state (shopping list, notes, council history).

---

## App Types

| Type | Init event | Boot entry | AppDB needed on first paint | Examples |
|---|---|---|---|---|
| **A — System** | `gnoke:boot` | `boot.js` only | Yes | notes, shopping-list |
| **B — Guest** | `gnoke:boot` | `boot.js` only | Yes | council |
| **C — Tool** | `DOMContentLoaded` | direct `<script>` tags + `boot.js` last | No | geocompass, calculator |

---

*Gnoke Station 2 — © 2026 Ekong Ikpe / Edmund Sparrow — MIT*
