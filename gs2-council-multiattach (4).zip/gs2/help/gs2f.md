# Gnoke Station 2 File Storage Architecture (`gs2f.md`)

## 1. Core Realization
* **Monolithic Write Problem:** Standard web applications overwrite database binaries completely during state mutation loops, creating a scaling bottleneck on mobile hardware.
* **OPFS Synchronous Breakthrough:** By wrapping `sql.js` (WASM) inside a Web Worker linked to the Chromium **Origin Private File System (OPFS)** via `FileSystemSyncAccessHandle`, the application achieves direct page-level (4KB blocks) mutations inside a single persistent binary file context per app (`<appId>.db`), avoiding complete file rewrites.

## 2. Structural Layering
To prevent tab termination on low-spec hardware and ensure rapid client loading, storage is divided into high-priority and deferred tables — **per app, automatically, by the firmware layer**:

1. **`app_surface` (High Priority):** Holds index metrics (keys, titles, epoch timestamps, small values) loaded completely on app instantiation to render structural boundaries.
2. **`app_payloads` (Deferred):** Holds large values (raw Markdown bodies, thick CSV text, binary blobs) ignored during startup and loaded via key/row lookup *only* when focused by the client UI.

Apps do not choose which table a value lands in — `GnokeSysDB` decides based on value size at write time. Apps only ever see `kv.get/put/delete/list` and `sessions.put/getAll/delete`.

## 3. Dynamic Hybrid Persistence Lifecycles — Owned by `sys2026/sysdb.js`
* **Option A (SQL.js via OPFS Access):** Activates natively inside Chromium runtimes exposing `navigator.storage.getDirectory`. Each app gets its own binary container (`<appId>.db`), opened lazily on first `GnokeSysDB(appId)` call, with atomic page adjustments via `FileSystemSyncAccessHandle` inside a dedicated worker.
* **Option B (IndexedDB Fallback):** Activates on browsers missing OPFS sync access (non-Chromium, or denied storage permission). Falls back to the existing `GnokeStore` IndexedDB database, with `app-data` and `sessions` object stores keyed by `[appId, key]` / `[appId, id]` exactly as today.

**Critical point:** this engine selection happens **once, inside `GnokeSysDB`**, not per app. App data layers (`notes-data.js`, `EditorData`, shopping-list `db.js`, etc.) are written once against the `AppDB` interface and never know or care which engine is active underneath.

## 4. Operational Implementation Target (`sys2026/sysdb.js`)

`GnokeSysDB(appId)` already returns a frozen `{ get, put, delete, list, sessions }` object (IDB-only today). The OPFS/sql.js engine is added as an internal swap inside this same factory — **no change to the returned interface, no change to any app**.

```javascript
// sys2026/sysdb.js — sketch of the surgical addition
const GnokeSysDB = (() => {

  const PAYLOAD_THRESHOLD = 2048; // bytes — values above this go to app_payloads

  // ── Engine detection (once, lazily, per appId) ──────────────
  const _engines = new Map(); // appId -> 'sqlite' | 'idb'
  const _sqlite  = new Map(); // appId -> { db, flush() }

  async function _engineFor(appId) {
    if (_engines.has(appId)) return _engines.get(appId);
    let engine = 'idb';
    try {
      if (navigator.storage?.getDirectory) {
        const root = await navigator.storage.getDirectory();
        const fileHandle = await root.getFileHandle(`${appId}.db`, { create: true });
        const sqliteDb = await _initSqliteEngine(fileHandle); // worker + sql.js + access handle
        _sqlite.set(appId, sqliteDb);
        engine = 'sqlite';
      }
    } catch (_) {
      engine = 'idb'; // any failure (older Chromium, Firefox, Safari, denied) → fallback
    }
    _engines.set(appId, engine);
    return engine;
  }

  function factory(appId) {
    if (!appId) throw new Error('[sysdb] appId is required.');

    const kv = {
      async get(key) {
        if (await _engineFor(appId) === 'sqlite') {
          return _sqlite.get(appId).getValue(key); // checks surface, then payloads
        }
        // existing IDB path — unchanged
        const db  = await _open();
        const row = await _p(_tx(db, 'app-data', 'readonly').get([appId, key]));
        return row?.val ?? null;
      },
      async put(key, val) {
        if (await _engineFor(appId) === 'sqlite') {
          const big = JSON.stringify(val).length > PAYLOAD_THRESHOLD;
          return _sqlite.get(appId).putValue(key, val, big); // routes table by size
        }
        const db = await _open();
        await _p(_tx(db, 'app-data', 'readwrite').put({ appId, key, val }));
      },
      // delete/list mirror the same if/else split
    };

    const sessions = { /* same pattern — surface row + payload row per session id */ };

    return Object.freeze({ ...kv, sessions });
  }

  factory.nuke = nuke; // extended to also delete <appId>.db via OPFS when present
  return factory;
})();
```

Apps continue calling `window.AppDB = GnokeSysDB(APP_ID)` exactly as `gnoke-presence.js` already does for Notes, Shopping List, and Editor — **zero app-side changes**.

## 5. System Advantages
1. **Memory Flatlining:** Keeps memory allocation static across extensive usage cycles, mitigating runtime browser engine sandbox drops on resource-limited devices.
2. **Transactional Security:** Minimizes dataset corruption profiles under forced client termination through direct WebAssembly atomic database block locks (per-app `.db` file).
3. **Instantaneous Bootstrapping:** Decouples file scale profiles from initial layout assembly speeds — `app_surface` rows load fast regardless of how large `app_payloads` has grown.
4. **One Implementation, All Apps:** The OPFS/IDB split and size-based table routing live entirely in `sys2026/sysdb.js`. Every current and future app inherits the upgrade automatically through `AppDB`, with no per-app engine code, detection, or fallback logic to maintain.
