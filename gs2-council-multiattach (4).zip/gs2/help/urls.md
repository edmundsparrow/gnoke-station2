https://gnoke-station2.netlify.app/index.html
https://gnoke-station2.netlify.app/template.html
https://gnoke-station2.netlify.app/presence.js

https://gnoke-station2.netlify.app/firmware/gnoke-client.js
https://gnoke-station2.netlify.app/firmware/gnoke-core.js
https://gnoke-station2.netlify.app/firmware/gnoke-hal.js
https://gnoke-station2.netlify.app/firmware/gnoke-kernel.js
https://gnoke-station2.netlify.app/firmware/gnoke-savenative.js
https://gnoke-station2.netlify.app/firmware/gnoke-shell.js
https://gnoke-station2.netlify.app/firmware/gnoke-spirit.js
https://gnoke-station2.netlify.app/firmware/gnoke-syscall.js
https://gnoke-station2.netlify.app/firmware/gnoke-worker.js
https://gnoke-station2.netlify.app/firmware/policy.js
https://gnoke-station2.netlify.app/firmware/reset.js

https://gnoke-station2.netlify.app/sys2026/apps.js
https://gnoke-station2.netlify.app/sys2026/auth.js
https://gnoke-station2.netlify.app/sys2026/backup.js
https://gnoke-station2.netlify.app/sys2026/config.js
https://gnoke-station2.netlify.app/sys2026/gnoke-doc.md
https://gnoke-station2.netlify.app/sys2026/gnoke-presence.js
https://gnoke-station2.netlify.app/sys2026/launcher.js
https://gnoke-station2.netlify.app/sys2026/sysdb.js

https://gnoke-station2.netlify.app/apps/council/attach.js
https://gnoke-station2.netlify.app/apps/council/core.js
https://gnoke-station2.netlify.app/apps/council/council.md
https://gnoke-station2.netlify.app/apps/council/gnoke-presence.js
https://gnoke-station2.netlify.app/apps/council/gnoke-spirit.js
https://gnoke-station2.netlify.app/apps/council/gnoke.json
https://gnoke-station2.netlify.app/apps/council/history.js
https://gnoke-station2.netlify.app/apps/council/index.html
https://gnoke-station2.netlify.app/apps/council/menu.js
https://gnoke-station2.netlify.app/apps/council/styles.css
https://gnoke-station2.netlify.app/apps/notes/index.html

https://gnoke-station2.netlify.app/system/debug/debug.js
https://gnoke-station2.netlify.app/system/debug/debug.md
https://gnoke-station2.netlify.app/system/debug/index.html