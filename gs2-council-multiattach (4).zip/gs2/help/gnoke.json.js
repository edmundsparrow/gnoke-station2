{
  "gnoke": "1.0",
  "appId": "my-app",
  "name": "My App",
  "version": "1.0.0",
  "role": "guest_app",
  "native": true,
  "capabilities": [],
  "description": "One-line description of what this app does",
  "icon": "🔷",
  "author": "Your Name",
  "license": "MIT"
}

/*
  ═══════════════════════════════════════════════════════════
  gnoke.json — Field Reference
  ═══════════════════════════════════════════════════════════

  gnoke        "1.0"          Spec version. Station rejects unknown versions.

  appId        string         Unique identifier. Used as:
                               - sysdb namespace (AppDB storage key)
                               - bus process name
                               - tile key in the launcher
                              Lowercase, hyphenated. e.g. "shopping-list"

  name         string         Display name shown on the station tile.

  version      string         Semver. Shown in About pages and debug tool.

  role         string         One of three values:
                               "operator"   → PID 1 / shell only (gnoke-shell.js)
                               "system"     → First-party trusted apps
                                              (notes, shopping-list, council)
                               "guest_app"  → Third-party / capability-restricted
                                              (geocompass and all new apps)
                              When in doubt: use "guest_app".

  native       true           Always true for apps that call Gnoke.ready().
                              Signals Tier 3 participation to the station.

  capabilities string[]       Capabilities this app intends to claim on the bus.
                              Advisory — declared for the station registry.
                              Examples: ["geolocation"], ["printer"], []

  description  string         One sentence. Used in station registry and debug.

  icon         string         Emoji shown in the station tile icon box.

  author       string         Your name or handle.

  license      string         e.g. "MIT", "GPL-3.0"

  ═══════════════════════════════════════════════════════════
  Real examples from the codebase:

  notes          role: "system",     capabilities: []
  shopping-list  role: "system",     capabilities: []
  council        role: "guest_app",  capabilities: []
  geocompass     role: "guest_app",  capabilities: ["geolocation"]
  ═══════════════════════════════════════════════════════════
*/
