# Kitana AI — Lightweight PHP/SQLite Rebuild

Replaces the ~1,700-line vanilla-JS transformer (math/forward/backward/
trainer/weights) with BM25 full-text retrieval over your existing
curriculum, using SQLite FTS5 — built into PHP's sqlite3 extension,
no Composer, no external libraries.

## Why this instead of the transformer

- 536 Q/A pairs is far too little data to train a useful ~800K-param
  model. BM25 retrieval over the same data gives equal or better
  answers, instantly, with zero training step.
- Memory footprint on the client drops from "load + run a neural net"
  to "send a string, get a string back."
- Corpus can grow to thousands of entries without touching device RAM —
  it all lives in SQLite on the server.

## Server setup (server/)

1. Upload `server/` (ask.php, teach.php, build-db.php, curriculum.md)
   to your PHP host. Requires PHP with the `pdo_sqlite` extension
   (enabled by default on virtually all hosts, including shared hosting).

2. Build the database once:
   ```
   php build-db.php
   ```
   This reads `curriculum.md` (your existing gnoke-curriculum.md format:
   `Q: ...` / `A: ...` pairs) and creates `kitana.sqlite` with an FTS5
   index for BM25 ranking.

3. To add more Q/A pairs later, either:
   - Edit `curriculum.md` and re-run `build-db.php` (rebuilds from scratch), or
   - Use `teach.php` to insert single pairs at runtime without rebuilding.

4. **Set your own admin token** in `teach.php` — replace
   `'change-me-edmund'` with a private string before deploying.

## API

### POST /ask.php
```json
{ "q": "who are you" }
```
Response:
```json
{
  "ok": true,
  "match": true,
  "answer": "I am Gnoke AI ...",
  "question": "who are you",
  "score": -2.1,
  "alternates": [ { "question": "...", "answer": "...", "score": -1.4 } ]
}
```
`score` is SQLite's bm25() value — more negative means a stronger match.
`alternates` gives the next 4 best matches in case you want to show
"did you mean" options in the UI.

### POST /teach.php
```json
{ "q": "new question", "a": "new answer", "token": "your-admin-token" }
```
Adds a single Q/A pair to the live database immediately — no rebuild needed.

## Client app (system/dictionary/)

A complete drop-in replacement for the old `system/dictionary/` folder:

```
system/dictionary/
├── index.html          # Stripped chat UI (topbar, chat, voice — no training panels)
├── gnoke.json           # Manifest (name: Kitana AI)
├── gnoke-presence.js    # Bus registration, same pattern as original
├── assets/icon.svg
└── js/
    ├── kitana-respond.js  # Replaces gnoke-respond.js — BM25 retrieval pipeline
    ├── kitana-health.js   # Replaces gnoke-health.js — simple usage log, no training metrics
    └── voice.js           # Unchanged, voice input/output
```

Edit `KITANA_SERVER_URL` at the top of `js/kitana-respond.js` to point
at your deployed `server/` folder before use.

### Removed from the original system/dictionary/
math.js, vocab.js, weights.js, forward.js, backward.js, trainer.js,
tokenizer.js, train-worker.js, seed.js, attach.js (Claude-curriculum
bridge), ai-menu.js, brainbox.md, gnoke-curriculum.md (moved to
server/curriculum.md) — the entire training pipeline, ~2,300 lines.

ai-history.js was also dropped from this build: its session-array API
doesn't match the simple per-message flow here. Re-add later if you
want multi-session chat history.


### What's removed
- math.js, forward.js, backward.js, trainer.js, train-worker.js, weights.js,
  vocab.js, tokenizer.js (~1,700 lines, ~800K params, training pipeline)
- The seed.js curriculum-fetch-and-train-on-first-boot flow — no longer
  needed since the corpus lives server-side and is always "trained"

## Next step (optional)

Wire `gnoke-persona.js` around `KitanaRespond.ask()`'s return value —
that layer is independent of the matching engine and needs no changes.
