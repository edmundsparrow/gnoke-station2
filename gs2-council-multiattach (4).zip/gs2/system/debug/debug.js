// debug.js — v1.0.0
// Gnoke Debug — Task Manager Runtime
// Edmund Sparrow © 2026 — MIT

'use strict';

/* ─────────────────────────────────────────────────
   Driver catalogue
   url: '#' = not yet built — button disabled
───────────────────────────────────────────────── */
const DRIVERS = [
  { id:'serial',    name:'Serial',    desc:'Web Serial API · UART / COM bridge',  icon:'⊛', cap:'serial',    url:'../gnoke-driver-serial.html' },
  { id:'usb',       name:'WebUSB',    desc:'WebUSB API · GPIO & device bridge',    icon:'⊕', cap:'usb',       url:'../gnoke-driver-usb.html' },
  { id:'bluetooth', name:'Bluetooth', desc:'Web Bluetooth API · BLE scanner',     icon:'⋈', cap:'bluetooth', url:'../gnoke-driver-bluetooth.html' },
];

/* ─────────────────────────────────────────────────
   State
───────────────────────────────────────────────── */
let _live  = {};
let _ghost = {};
let _caps  = {};   // capability → pid (advisory, from live meta)
let _logN  = 0;
let _busOk = false;

/* ─────────────────────────────────────────────────
   Clock
───────────────────────────────────────────────── */
function tick() {
  const n = new Date();
  document.getElementById('tbClock').textContent =
    n.toLocaleTimeString('en-GB', { hour:'2-digit', minute:'2-digit', hour12:false });
}
tick(); setInterval(tick, 1000);

/* ─────────────────────────────────────────────────
   Tab switching
───────────────────────────────────────────────── */
function switchView(id) {
  document.querySelectorAll('.view').forEach(v => v.classList.remove('active'));
  document.querySelectorAll('.tb-tab, .mn-tab').forEach(t => t.classList.remove('active'));
  document.getElementById(`view-${id}`).classList.add('active');
  document.querySelectorAll(`[data-view="${id}"]`).forEach(t => t.classList.add('active'));
}
document.querySelectorAll('.tb-tab, .mn-tab').forEach(btn => {
  btn.addEventListener('click', () => switchView(btn.dataset.view));
});

/* ─────────────────────────────────────────────────
   Console log
───────────────────────────────────────────────── */
function clog(msg, type = 'info') {
  const el = document.createElement('div');
  el.className = `con-line ${type}`;
  const t = new Date().toLocaleTimeString('en-GB', { hour12:false });
  const icons = { born:'↑', died:'↓', ghost:'~', warn:'!', info:'·', cap:'⬡', err:'✕' };
  el.innerHTML =
    `<span class="cl-ts">${t}</span>` +
    `<span class="cl-icon">${icons[type]||'·'}</span>` +
    `<span class="cl-msg" title="${msg}">${msg}</span>`;
  document.getElementById('consoleOut').prepend(el);
  _logN++;
}

/* ─────────────────────────────────────────────────
   Bus pill
───────────────────────────────────────────────── */
function setBus(state) {
  const pill = document.getElementById('busPill');
  const lbl  = document.getElementById('busLabel');
  _busOk = state === 'live';
  pill.className = 'bus-pill' + (state==='live' ? ' live' : state==='error' ? ' error' : '');
  lbl.textContent = state === 'live' ? 'Bus Live' : state === 'error' ? 'Bus Error' : 'Connecting';
  document.getElementById('sysBusState').textContent = state.toUpperCase();
}

/* ─────────────────────────────────────────────────
   FS pill
───────────────────────────────────────────────── */
function setFS(mounted, name) {
  const pill = document.getElementById('fsPill');
  const lbl  = document.getElementById('fsLabel');
  pill.className = 'fs-pill' + (mounted ? ' mounted' : '');
  lbl.textContent = mounted ? `FS: ${name || 'Mounted'}` : 'FS: Unmounted';
  document.getElementById('wsName').textContent = mounted ? (name || 'Mounted') : 'Not mounted';
}

/* ─────────────────────────────────────────────────
   Update tab badge + panel bar summary
───────────────────────────────────────────────── */
function updateCounts() {
  const liveN  = Object.keys(_live).length;
  const ghostN = Object.keys(_ghost).length;
  const tab = document.querySelector('[data-view="tasks"] .tab-count');
  if (tab) tab.textContent = liveN || '';
  const summary = document.getElementById('taskSummary');
  if (summary) {
    summary.textContent = liveN
      ? `${liveN} live${ghostN ? ` · ${ghostN} ghost` : ''}`
      : ghostN ? `${ghostN} ghost` : '';
  }
}

/* ─────────────────────────────────────────────────
   Refresh capability map from live processes
───────────────────────────────────────────────── */
function refreshCaps() {
  _caps = {};
  for (const [pid, { meta }] of Object.entries(_live)) {
    for (const cap of (meta?.capabilities || [])) {
      if (!_caps[cap]) _caps[cap] = pid;
    }
  }
}

/* ─────────────────────────────────────────────────
   Render: Tasks
───────────────────────────────────────────────── */
function renderTasks() {
  const scroll = document.getElementById('taskScroll');
  const all = [
    ...Object.entries(_live).map(([pid,d])  => ({ pid, ...d, state:'live'  })),
    ...Object.entries(_ghost).map(([pid,d]) => ({ pid, ...d, state:'ghost' })),
  ];
  if (!all.length) {
    scroll.innerHTML = `
      <div class="task-empty">
        <div class="hex-grid">
          <div class="hex-cell"></div><div class="hex-cell"></div>
          <div class="hex-cell"></div><div class="hex-cell"></div>
          <div class="hex-cell"></div><div class="hex-cell"></div>
          <div class="hex-cell"></div><div class="hex-cell"></div>
        </div>
        <p>No processes registered</p>
      </div>`;
    return;
  }
  scroll.innerHTML = all.map(p => {
    const caps   = p.meta?.capabilities || [];
    const isPriv = caps.includes('filesystem') || p.meta?.role === 'operator';
    const cls    = isPriv ? 'priv' : p.state;
    const label  = isPriv ? 'PID 1' : p.state === 'ghost' ? 'Ghost' : 'Live';
    const capBadges = caps.map(c => `<span class="tc-cap">${c}</span>`).join('');
    return `
      <div class="task-card ${cls}" data-pid="${p.pid}">
        <div class="tc-dot"></div>
        <div class="tc-info">
          <div class="tc-name">${p.meta?.name || p.pid}</div>
          <div class="tc-pid tc-pid-copy" data-pid="${p.pid}" title="Click to copy PID">${p.pid}</div>
          ${capBadges ? `<div class="tc-caps">${capBadges}</div>` : ''}
        </div>
        <div class="tc-state">${label}</div>
        ${p.state !== 'ghost' && !isPriv
          ? `<button class="tc-kill" data-kill="${p.pid}" title="Send kill signal">✕</button>`
          : ''
        }
      </div>`;
  }).join('');

  scroll.querySelectorAll('.task-card').forEach(card => {
    card.addEventListener('click', e => {
      if (e.target.closest('[data-kill]') || e.target.closest('.tc-pid-copy')) return;
      const pid = card.dataset.pid;
      const proc = _live[pid] || _ghost[pid];
      const appName = proc?.meta?.name;
      const app = typeof APPS !== 'undefined'
        ? APPS.find(a => a.name === appName || a.id === appName?.toLowerCase())
        : null;
      if (!app) { clog(`No app mapping for ${appName || pid}`, 'warn'); return; }
      // Re-opening the same named window focuses the existing tab (no reload)
      // if it's still open, or relaunches it if it was closed.
      const win = window.open(app.url, `gnoke-${app.id}`);
      if (win) { card.classList.add('switching'); setTimeout(() => card.classList.remove('switching'), 400); }
    });
  });

  scroll.querySelectorAll('[data-kill]').forEach(btn => {
    btn.addEventListener('click', e => {
      e.stopPropagation();
      const pid = btn.dataset.kill;
      const card = btn.closest('.task-card');
      const proc = _live[pid] || _ghost[pid];
      const appName = proc?.meta?.name;
      const app = typeof APPS !== 'undefined'
        ? APPS.find(a => a.name === appName || a.id === appName?.toLowerCase())
        : null;

      GnokeClient.send(pid, 'SYS_KILL', { from: GnokeClient.pid }).catch(() => {});
      clog(`Kill → ${pid.slice(0,20)}`, 'warn');

      // Attempt to close the actual tab/window too (same-origin only).
      if (app) {
        try {
          const win = window.open('', `gnoke-${app.id}`);
          if (win && !win.closed && win.location.href !== 'about:blank') {
            win.close();
            clog(`Closed window → ${app.name}`, 'warn');
          } else if (win) {
            win.close(); // discard the blank tab we just opened
          }
        } catch (err) {
          clog(`Could not close ${app.name} (cross-origin)`, 'warn');
        }
      }
    });
  });

  scroll.querySelectorAll('.tc-pid-copy').forEach(el => {
    el.addEventListener('click', e => {
      e.stopPropagation();
      const pid = el.dataset.pid;
      navigator.clipboard.writeText(pid).then(() => {
        el.classList.add('copied');
        el.textContent = 'Copied!';
        setTimeout(() => {
          el.classList.remove('copied');
          el.textContent = pid;
        }, 1200);
      }).catch(() => {});
    });
  });
}

/* ─────────────────────────────────────────────────
   Render: Drivers
───────────────────────────────────────────────── */
function renderDrivers() {
  const scroll = document.getElementById('driverScroll');
  const liveNames = new Set(Object.values(_live).map(p => p.meta?.name?.toLowerCase()));
  scroll.innerHTML = DRIVERS.map(d => {
    const isLive = _caps[d.cap] || liveNames.has(d.name.toLowerCase());
    const noUrl  = !d.url || d.url === '#';
    return `
      <div class="driver-card">
        <div class="dr-icon">${d.icon}</div>
        <div class="dr-info">
          <div class="dr-name">${d.name}</div>
          <div class="dr-desc">${d.desc}</div>
          <div class="dr-cap">${d.cap}</div>
        </div>
        <div class="dr-status ${isLive ? 'live' : 'idle'}">${isLive ? 'Live' : 'Idle'}</div>
        <button class="dr-launch ${isLive ? 'running' : ''}"
          data-url="${d.url}" data-id="${d.id}" data-name="${d.name}"
          ${noUrl ? 'disabled style="opacity:0.4;cursor:not-allowed"' : ''}>
          ${isLive ? 'Running' : noUrl ? 'Soon' : 'Launch →'}
        </button>
      </div>`;
  }).join('');

  scroll.querySelectorAll('.dr-launch:not([disabled])').forEach(btn => {
    btn.addEventListener('click', () => {
      const tab = window.open(btn.dataset.url, `gnoke-driver-${btn.dataset.id}`);
      if (tab) clog(`Driver launched → ${btn.dataset.name}`, 'born');
      else     clog('Popup blocked', 'warn');
    });
  });
}

/* ─────────────────────────────────────────────────
   Console input
───────────────────────────────────────────────── */
function sendCmd() {
  const input = document.getElementById('conInput');
  const msg   = input.value.trim();
  if (!msg) return;
  input.value = '';
  if (!_busOk) { clog('Bus not connected', 'warn'); return; }
  GnokeClient.broadcast('DEBUG_CMD', { msg }).catch(() => {});
  clog(`broadcast: ${msg}`, 'info');
}
document.getElementById('conSend').addEventListener('click', sendCmd);
document.getElementById('conInput').addEventListener('keydown', e => {
  if (e.key === 'Enter') sendCmd();
});
document.getElementById('clearConsole').addEventListener('click', () => {
  document.getElementById('consoleOut').innerHTML = '';
  _logN = 0;
});

/* ─────────────────────────────────────────────────
   System buttons
───────────────────────────────────────────────── */
document.getElementById('btnMount').addEventListener('click', async () => {
  try {
    const handle = await GnokeShell.mount();
    setFS(true, handle.name);
    clog(`Workspace mounted: ${handle.name}`, 'cap');
  } catch (err) {
    clog(`Mount failed: ${err.message}`, 'warn');
  }
});
document.getElementById('btnWake').addEventListener('click', async () => {
  try {
    await GnokeShell.wake();
    setFS(true, 'restored');
    clog('Workspace woken from cache', 'info');
  } catch (err) {
    clog(`Wake failed: ${err.message}`, 'warn');
  }
});
document.getElementById('btnClearCache').addEventListener('click', () => {
  sessionStorage.clear();
  clog('Session cache cleared', 'warn');
  setTimeout(() => location.reload(), 400);
});
document.getElementById('btnNuke').addEventListener('click', async () => {
  if (!confirm('Factory Reset?\n\nThis wipes all Gnoke runtime data.\nYour workspace files on disk are NOT affected.')) return;
  try {
    if (window._gnoke_nuke) {
      const { wiped, failed } = await window._gnoke_nuke();
      clog(`Nuked: ${wiped.join(', ')}`, 'warn');
      if (failed.length) clog(`Failed: ${failed.join(', ')}`, 'err');
    } else {
      sessionStorage.clear();
      indexedDB.deleteDatabase('GnokeFirmware');
      clog('Runtime cleared (fallback)', 'warn');
    }
  } catch (err) {
    clog(`Nuke error: ${err.message}`, 'err');
  }
});

/* FS pill click → mount */
document.getElementById('fsPill').addEventListener('click', async () => {
  if (!GnokeClient.ready) return;
  try {
    const handle = await GnokeShell.mount();
    setFS(true, handle.name);
    clog(`Workspace mounted: ${handle.name}`, 'cap');
  } catch (err) {
    if (err.name !== 'AbortError') clog(`Mount: ${err.message}`, 'warn');
  }
});

/* Refresh button */
document.getElementById('refreshTasks').addEventListener('click', async () => {
  if (!_busOk) return;
  try {
    const { processes, ghosts } = await GnokeClient.listAll();
    _live  = processes;
    _ghost = ghosts;
    refreshCaps();
    renderTasks();
    updateCounts();
    renderDrivers();
    clog('Registry refreshed', 'info');
  } catch {}
});

/* Session info */
document.getElementById('sysSession').textContent =
  (GnokeClient?.pid || 'None');

/* ─────────────────────────────────────────────────
   Boot
───────────────────────────────────────────────── */
/* ─────────────────────────────────────────────────
   Boot diagnostic — shows failure reason on Tasks tab
   so you don't need to switch to Console to see errors
───────────────────────────────────────────────── */
function _diagMsg(msg, isErr) {
  const scroll = document.getElementById('taskScroll');
  if (!scroll) return;
  scroll.innerHTML = `
    <div class="task-empty" style="gap:12px">
      <div style="font-size:1.5rem">${isErr ? '⚠' : '⏳'}</div>
      <p style="color:${isErr ? 'var(--err,#f66)' : 'inherit'};text-align:center;padding:0 1rem">${msg}</p>
    </div>`;
}

(async () => {
  _diagMsg('Booting firmware…', false);
  renderDrivers();
  if (!('SharedWorker' in window)) {
    setBus('error');
    clog('SharedWorker unavailable', 'err');
    _diagMsg('SharedWorker not supported in this browser.<br>Try desktop Chrome or Edge.', true);
    return;
  }
  try {
    await GnokeShell.boot();
    setBus('live');
    clog('Shell online · PID 1 · v2 firmware', 'cap');

    document.getElementById('sysMyPid').textContent =
      GnokeClient.pid || '—';
    document.getElementById('sysSession').textContent =
      GnokeClient.pid?.slice(0, 20) || '—';
    _diagMsg('', false); /* clear boot message — real content renders below */

    try {
      await GnokeShell.wake();
      setFS(true, 'restored');
      clog('Workspace restored from cache', 'info');
    } catch { /* not mounted yet — fine */ }

    const { processes, ghosts } = await GnokeClient.listAll();
    console.info('[gnoke-debug] listAll →', { processes, ghosts });
    clog(`Registry: ${Object.keys(processes).length} live · ${Object.keys(ghosts).length} ghost`, 'info');
    _live  = processes;
    _ghost = ghosts;
    refreshCaps();
    renderTasks();
    updateCounts();
    renderDrivers();

    GnokeClient.onRegistry(async procs => {
      _live = procs;
      /* also refresh ghosts — REGISTRY broadcast only carries live processes */
      try {
        const { ghosts } = await GnokeClient.listAll();
        _ghost = ghosts;
      } catch {}
      refreshCaps();
      renderTasks();
    updateCounts();
      renderDrivers();
    });
    GnokeClient.onProcessBorn((pid, meta) => {
      clog(`Born — ${meta?.name || pid.slice(0,18)}`, 'born');
      /* Add to live registry immediately — don't wait for next poll */
      _live[pid] = { meta, ts: Date.now() };
      refreshCaps();
      renderTasks();
      updateCounts();
      renderDrivers();
    });
    GnokeClient.onProcessDied(pid => {
      const name = _live[pid]?.meta?.name || pid.slice(0,18);
      if (_live[pid]) { _ghost[pid] = _live[pid]; delete _live[pid]; }
      refreshCaps();
      renderTasks();
    updateCounts();
      renderDrivers();
      clog(`Died — ${name}`, 'died');
    });

    /* Ghost poll */
    setInterval(async () => {
      try {
        const { processes, ghosts } = await GnokeClient.listAll();
        _live  = processes;
        _ghost = ghosts;
        refreshCaps();
        renderTasks();
    updateCounts();
      } catch {}
    }, 5_000);

  } catch (err) {
    setBus('error');
    clog(`Boot error: ${err.message}`, 'err');
    _diagMsg(`Boot failed: ${err.message}<br><br>Check Console tab for details.`, true);
  }
})();
