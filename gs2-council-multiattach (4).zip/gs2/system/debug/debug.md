# Gnöke Debug — Source Commentary Reference

> All inline comments extracted from every Debug source file.
> Collapsible per file. Companion to the clean codebase.

---

## Table of Contents

### Entry
- [index.html](#indexhtml) — App Entry Point & Layout

### Core Logic
- [debug.js](#debugjs) — Task Manager Runtime

---

## Entry

<details><summary><strong>index.html</strong> &nbsp;·&nbsp; App Entry Point & Layout</summary>

#### GnokeClient inline stub
```
GnokeClient inline stub — debug-layer copy, NOT gnoke-client.js
listAll() + releaseCapability() live here only.
The frozen gnoke-client.js is unchanged.
Worker path is relative to debug/: ../../firmware/gnoke-worker.js
```
> _Precedes:_ `const GnokeClient = (() => {`

#### Load order matters
```
Firmware — load order matters:
gnoke-savenative.js and gnoke-shell.js must precede debug.js.
reset.js is imported as a module to avoid polluting global scope.
```
> _Precedes:_ `<script src="../../firmware/gnoke-savenative.js"></script>`

</details>

---

## Core Logic

<details><summary><strong>debug.js</strong> &nbsp;·&nbsp; Task Manager Runtime</summary>

**Note 1**
```
debug.js — v1.0.0
Gnoke Debug — Task Manager Runtime
Edmund Sparrow © 2026 — MIT

WHAT THIS IS:
All runtime logic for the debug app — extracted from the
legacy inline script so index.html contains zero executable code.

Owns: clock tick, bus pill state, FS pill state, tab switching,
renderTasks(), renderDrivers(), console log (clog()), console
input, system buttons, and the boot sequence.

LOAD ORDER:
GnokeClient stub (inline) → gnoke-savenative.js →
gnoke-shell.js → reset.js (module) → debug.js
```
> _Precedes:_ `'use strict';`

#### Driver catalogue
```
url: '#' = not yet built — button is disabled in the UI.
Driver paths are relative to system/ (one level above debug/).
```
> _Precedes:_ `const DRIVERS = [`

#### ── State ──────────────────────────────────────────────────
> _Precedes:_ `let _live  = {};`

#### ── Clock ──────────────────────────────────────────────────
> _Precedes:_ `function tick() {`

#### ── Tab switching ──────────────────────────────────────────
> _Precedes:_ `function switchView(id) {`

#### ── Console log ────────────────────────────────────────────
> _Precedes:_ `function clog(msg, type = 'info') {`

#### ── Bus pill ───────────────────────────────────────────────
> _Precedes:_ `function setBus(state) {`

#### ── FS pill ────────────────────────────────────────────────
> _Precedes:_ `function setFS(mounted, name) {`

#### ── Refresh capability map from live processes ─────────────
> _Precedes:_ `function refreshCaps() {`

#### ── Render: Tasks ──────────────────────────────────────────
**Note 9**
```
Renders live and ghost processes as task cards.
Each card shows:
  - App name (meta.name) — prominent display font
  - Full PID — monospace, word-break: break-all, click to copy
  - Capability badges — if the process declared any
  - State badge — Live / Ghost / PID 1
  - Kill button — live non-privileged processes only

PID copy: click flashes green "Copied!" for 1200ms then restores.
Privileged processes (filesystem cap or operator role) show
as PID 1 with purple accent and no kill button.
```
> _Precedes:_ `function renderTasks() {`

#### ── Render: Drivers ─────────────────────────────────────────
> _Precedes:_ `function renderDrivers() {`

#### ── Console input ──────────────────────────────────────────
> _Precedes:_ `function sendCmd() {`

#### ── System buttons ─────────────────────────────────────────
> _Precedes:_ `document.getElementById('btnMount').addEventListener`

#### FS pill click → mount
> _Precedes:_ `document.getElementById('fsPill').addEventListener`

#### Refresh button
> _Precedes:_ `document.getElementById('refreshTasks').addEventListener`

#### ── Boot ──────────────────────────────────────────────────
**Note 17**
```
Boot sequence:
1. renderDrivers() — populate driver list before bus connects
2. GnokeShell.boot() — claims filesystem + dock capabilities
3. setBus('live') — update pill
4. GnokeShell.wake() — silently restore workspace from cache
5. listAll() — seed live + ghost registries
6. renderTasks() + renderDrivers() — initial render
7. onRegistry() — live updates on every bus topology change
8. onProcessBorn/Died() — console log events
9. Ghost poll every 5s — keeps ghost list fresh
```
> _Precedes:_ `(async () => {`

#### Ghost poll
> _Precedes:_ `setInterval(async () => {`

</details>

---
_Gnöke Debug — System Task Manager. Comments removed from runtime files._