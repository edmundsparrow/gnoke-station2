(() => {
'use strict';
const DB_NAME  = 'gnoke:auth';
const DB_VER   = 1;
const STORE    = 'credentials';
const UID_KEY  = 'gnoke:uid';
const AUTH_KEY = 'gnoke:authed';
const _overlay = (() => {
  const el = document.createElement('div');
  Object.assign(el.style, {
    position:        'fixed',
    inset:           '0',
    zIndex:          '99999',
    background:      '#f0f5fb',
    display:         'flex',
    flexDirection:   'column',
    alignItems:      'center',
    justifyContent:  'center',
    fontFamily:      "'Outfit', sans-serif",
    gap:             '0',
  });
  el.innerHTML = `
    <div style="display:flex;flex-direction:column;align-items:center;gap:20px;width:100%;max-width:320px;padding:0 24px;">
      <div style="width:48px;height:48px;background:linear-gradient(135deg,#86b4e4,#3f6e9b);border-radius:12px;display:flex;align-items:center;justify-content:center;font-size:24px;color:white;box-shadow:0 4px 12px rgba(63,110,155,0.3);">⬡</div>
      <div style="text-align:center;">
        <div style="font-weight:800;font-size:20px;color:#1F4765;letter-spacing:-0.02em;">Gnoke Station</div>
        <div style="font-size:11px;color:#8aa3bc;letter-spacing:0.08em;text-transform:uppercase;margin-top:3px;" id="gnk-auth-sub">Authenticating…</div>
      </div>
      <div id="gnk-auth-body" style="width:100%;display:flex;flex-direction:column;gap:10px;"></div>
      <div id="gnk-auth-err" style="font-family:'DM Mono',monospace;font-size:10px;color:#dc2626;text-align:center;min-height:16px;"></div>
    </div>
  `;
  document.body.appendChild(el);
  return el;
})();
const _sub  = document.getElementById('gnk-auth-sub');
const _body = document.getElementById('gnk-auth-body');
const _err  = document.getElementById('gnk-auth-err');
function _setSub(t)  { _sub.textContent  = t; }
function _setErr(t)  { _err.textContent  = t; }
function _clearErr() { _err.textContent  = ''; }
(() => {
  const s = document.createElement('style');
  s.textContent = `
    .gnk-btn {
      all: unset;
      width: 100%;
      padding: 12px;
      border-radius: 10px;
      font-family: 'Outfit', sans-serif;
      font-size: 14px;
      font-weight: 600;
      text-align: center;
      cursor: pointer;
      border: 1px solid #d8e6f2;
      background: #ffffff;
      color: #1a2e44;
      box-sizing: border-box;
      transition: all 0.15s;
      -webkit-tap-highlight-color: transparent;
    }
    .gnk-btn:active { transform: scale(0.97); }
    .gnk-btn.primary {
      background: linear-gradient(135deg, #86b4e4, #3f6e9b);
      color: white;
      border-color: transparent;
      box-shadow: 0 2px 8px rgba(63,110,155,0.3);
    }
    .gnk-btn.primary:active { box-shadow: none; }
    .gnk-input {
      all: unset;
      width: 100%;
      padding: 12px 14px;
      border-radius: 10px;
      font-family: 'DM Mono', monospace;
      font-size: 18px;
      letter-spacing: 0.2em;
      text-align: center;
      color: #1a2e44;
      background: #ffffff;
      border: 1px solid #c4d8ed;
      box-sizing: border-box;
      transition: border-color 0.15s, box-shadow 0.15s;
    }
    .gnk-input:focus {
      border-color: #86b4e4;
      box-shadow: 0 0 0 3px rgba(134,180,228,0.2);
      outline: none;
    }
    .gnk-sep {
      display: flex;
      align-items: center;
      gap: 10px;
      font-family: 'DM Mono', monospace;
      font-size: 10px;
      color: #8aa3bc;
      letter-spacing: 0.06em;
    }
    .gnk-sep::before, .gnk-sep::after {
      content: '';
      flex: 1;
      height: 1px;
      background: #d8e6f2;
    }
  `;
  document.head.appendChild(s);
})();
function _getDB() {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, DB_VER);
    req.onupgradeneeded = () => {
      if (!req.result.objectStoreNames.contains(STORE)) {
        req.result.createObjectStore(STORE);
      }
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror   = () => reject(req.error);
  });
}
async function _dbGet(key) {
  const db = await _getDB();
  return new Promise((res, rej) => {
    const r = db.transaction(STORE, 'readonly').objectStore(STORE).get(key);
    r.onsuccess = () => res(r.result);
    r.onerror   = () => rej(r.error);
  });
}
async function _dbPut(key, val) {
  const db = await _getDB();
  return new Promise((res, rej) => {
    const r = db.transaction(STORE, 'readwrite').objectStore(STORE).put(val, key);
    r.onsuccess = () => res();
    r.onerror   = () => rej(r.error);
  });
}
/* UID lives in GnokeFirmware/config IDB — same store as PIDs.
   Async, no localStorage, survives browser restarts, available
   in workers and private-browsing-resistant. */
const _uidDB = (() => {
  let _db = null;
  function _open() {
    if (_db) return Promise.resolve(_db);
    return new Promise((res, rej) => {
      const req = indexedDB.open('GnokeFirmware', 2);
      req.onupgradeneeded = e => {
        const db = e.target.result;
        if (!db.objectStoreNames.contains('kernel')) db.createObjectStore('kernel');
        if (!db.objectStoreNames.contains('config')) db.createObjectStore('config');
      };
      req.onsuccess = e => { _db = e.target.result; res(_db); };
      req.onerror   = e => rej(e.target.error);
    });
  }
  return {
    async get(key) {
      const db = await _open();
      return new Promise((res, rej) => {
        const r = db.transaction('config','readonly').objectStore('config').get(key);
        r.onsuccess = () => res(r.result ?? null);
        r.onerror   = () => rej(r.error);
      });
    },
    async set(key, val) {
      const db = await _open();
      return new Promise((res, rej) => {
        const r = db.transaction('config','readwrite').objectStore('config').put(val, key);
        r.onsuccess = () => res();
        r.onerror   = () => rej(r.error);
      });
    },
  };
})();
async function _getUID() {
  let uid = await _uidDB.get(UID_KEY);
  if (!uid) {
    uid = crypto.randomUUID();
    await _uidDB.set(UID_KEY, uid);
  }
  return uid;
}
async function _hashPIN(pin) {
  const uid  = await _getUID();
  const buf  = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(pin + uid));
  return Array.from(new Uint8Array(buf)).map(b => b.toString(16).padStart(2,'0')).join('');
}
const _WA_RP = { name: 'Gnoke Station', id: location.hostname || 'localhost' };
function _randomBytes(n) {
  return crypto.getRandomValues(new Uint8Array(n));
}
async function _waRegister() {
  const uid      = await _getUID();
  const credOpts = {
    publicKey: {
      challenge:        _randomBytes(32),
      rp:               _WA_RP,
      user: {
        id:             new TextEncoder().encode(uid),
        name:           'gnoke-user',
        displayName:    'Gnoke User',
      },
      pubKeyCredParams: [
        { type: 'public-key', alg: -7  },
        { type: 'public-key', alg: -257 },
      ],
      authenticatorSelection: {
        userVerification:     'required',
        residentKey:          'preferred',
      },
      timeout: 60_000,
    }
  };
  const cred = await navigator.credentials.create(credOpts);
  await _dbPut('wa:credId', Array.from(new Uint8Array(cred.rawId)));
  return true;
}
async function _waAuthenticate() {
  const rawIdArr = await _dbGet('wa:credId');
  if (!rawIdArr) throw new Error('No passkey registered');
  const credOpts = {
    publicKey: {
      challenge:        _randomBytes(32),
      rpId:             _WA_RP.id,
      allowCredentials: [{
        type: 'public-key',
        id:   new Uint8Array(rawIdArr),
      }],
      userVerification: 'required',
      timeout:          60_000,
    }
  };
  await navigator.credentials.get(credOpts);
  return true;
}
function _unlock() {
  sessionStorage.setItem(AUTH_KEY, '1');
  _overlay.style.opacity    = '0';
  _overlay.style.transition = 'opacity 0.3s';
  setTimeout(() => _overlay.remove(), 320);
  _getUID().then(uid => { window.GnokeAuth = Object.freeze({ uid, authed: true }); });
}
function _showSetup() {
  _setSub('First boot — choose how to lock your station');
  _body.innerHTML = '';
  const hasWA = !!window.PublicKeyCredential;
  if (hasWA) {
    const waBtn = document.createElement('button');
    waBtn.className   = 'gnk-btn primary';
    waBtn.textContent = '☝️  Use Fingerprint / Passkey';
    waBtn.onclick     = async () => {
      _clearErr();
      _setSub('Setting up passkey…');
      waBtn.disabled = true;
      try {
        await _waRegister();
        await _dbPut('auth:method', 'webauthn');
        _setSub('Passkey saved — welcome to Gnoke Station');
        setTimeout(_unlock, 800);
      } catch (e) {
        _setSub('First boot — choose how to lock your station');
        _setErr(e.name === 'NotAllowedError' ? 'Cancelled — try again' : e.message);
        waBtn.disabled = false;
      }
    };
    _body.appendChild(waBtn);
    const sep = document.createElement('div');
    sep.className   = 'gnk-sep';
    sep.textContent = 'or';
    _body.appendChild(sep);
  }
  const pinLabel = document.createElement('div');
  pinLabel.style.cssText = 'font-family:"DM Mono",monospace;font-size:10px;color:#8aa3bc;letter-spacing:0.08em;text-transform:uppercase;';
  pinLabel.textContent   = 'Set a PIN';
  _body.appendChild(pinLabel);
  const pinInput = document.createElement('input');
  pinInput.className   = 'gnk-input';
  pinInput.type        = 'password';
  pinInput.inputMode   = 'numeric';
  pinInput.maxLength   = 8;
  pinInput.placeholder = '· · · ·';
  _body.appendChild(pinInput);
  const pinInput2 = document.createElement('input');
  pinInput2.className   = 'gnk-input';
  pinInput2.type        = 'password';
  pinInput2.inputMode   = 'numeric';
  pinInput2.maxLength   = 8;
  pinInput2.placeholder = 'Confirm PIN';
  _body.appendChild(pinInput2);
  const pinBtn = document.createElement('button');
  pinBtn.className   = 'gnk-btn';
  pinBtn.textContent = 'Set PIN →';
  pinBtn.onclick     = async () => {
    _clearErr();
    const p1 = pinInput.value.trim();
    const p2 = pinInput2.value.trim();
    if (p1.length < 4)   { _setErr('PIN must be at least 4 digits'); return; }
    if (p1 !== p2)        { _setErr('PINs do not match'); return; }
    const hash = await _hashPIN(p1);
    await _dbPut('auth:method', 'pin');
    await _dbPut('auth:pin',    hash);
    _setSub('PIN set — welcome to Gnoke Station');
    setTimeout(_unlock, 800);
  };
  _body.appendChild(pinBtn);
  pinInput2.addEventListener('keydown', e => { if (e.key === 'Enter') pinBtn.click(); });
}
function _showLogin(method) {
  _setSub('Welcome back');
  _body.innerHTML = '';
  if (method === 'webauthn') {
    _setSub('Tap to unlock');
    const waBtn = document.createElement('button');
    waBtn.className   = 'gnk-btn primary';
    waBtn.textContent = '☝️  Unlock with Fingerprint';
    waBtn.onclick     = async () => {
      _clearErr();
      waBtn.disabled = true;
      _setSub('Verifying…');
      try {
        await _waAuthenticate();
        _setSub('Unlocked');
        _unlock();
      } catch (e) {
        _setSub('Welcome back');
        _setErr(e.name === 'NotAllowedError' ? 'Cancelled — try again' : 'Authentication failed');
        waBtn.disabled = false;
      }
    };
    _body.appendChild(waBtn);
    setTimeout(() => waBtn.click(), 300);
    const sep = document.createElement('div');
    sep.className   = 'gnk-sep';
    sep.textContent = 'or use PIN';
    _body.appendChild(sep);
  }
  const pinInput = document.createElement('input');
  pinInput.className   = 'gnk-input';
  pinInput.type        = 'password';
  pinInput.inputMode   = 'numeric';
  pinInput.maxLength   = 8;
  pinInput.placeholder = '· · · ·';
  pinInput.autofocus   = true;
  _body.appendChild(pinInput);
  const pinBtn = document.createElement('button');
  pinBtn.className   = 'gnk-btn';
  pinBtn.style.marginTop = '2px';
  pinBtn.textContent = method === 'webauthn' ? 'Use PIN instead →' : 'Unlock →';
  pinBtn.onclick     = async () => {
    _clearErr();
    const pin     = pinInput.value.trim();
    if (!pin)     { _setErr('Enter your PIN'); return; }
    const hash    = await _hashPIN(pin);
    const stored  = await _dbGet('auth:pin');
    if (!stored)  { _setErr('No PIN set — reset the station'); return; }
    if (hash !== stored) {
      _setErr('Wrong PIN');
      pinInput.value = '';
      pinInput.focus();
      return;
    }
    _setSub('Unlocked');
    _unlock();
  };
  _body.appendChild(pinBtn);
  pinInput.addEventListener('keydown', e => { if (e.key === 'Enter') pinBtn.click(); });
  if (method !== 'webauthn') setTimeout(() => pinInput.focus(), 100);
}
(async () => {
  if (sessionStorage.getItem(AUTH_KEY) === '1') {
    _unlock();
    return;
  }
  const method = await _dbGet('auth:method');
  if (!method) {
    _showSetup();
  } else {
    _showLogin(method);
  }
})();
})();
