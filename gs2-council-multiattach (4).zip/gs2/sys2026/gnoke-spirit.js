(() => {
  const DB_NAME = 'gnoke:spirit';
  const STORE   = 'processes';
  const VERSION = 2;
  const SENSITIVE = new Set(['password', 'token', 'cc', 'cvv', 'ssn', 'secret']);
  let _mem = {};
  let _db = null;

  const getDB = () => {
    if (_db) return Promise.resolve(_db);
    return new Promise((res, rej) => {
      const r = indexedDB.open(DB_NAME, VERSION);
      r.onupgradeneeded = e => e.target.result.createObjectStore(STORE);
      r.onsuccess = e => { _db = e.target.result; res(_db); };
      r.onerror   = e => rej(e.target.error);
    });
  };

  const tx     = (db, mode) => db.transaction(STORE, mode).objectStore(STORE);
  const dbGet  = (db, key)      => new Promise((res, rej) => { const r = tx(db,'readonly').get(key);        r.onsuccess = e => res(e.target.result); r.onerror = e => rej(e.target.error); });
  const dbPut  = (db, val, key) => new Promise((res, rej) => { const r = tx(db,'readwrite').put(val, key);  r.onsuccess = () => res();              r.onerror = e => rej(e.target.error); });
  const dbDel  = (db, key)      => new Promise((res, rej) => { const r = tx(db,'readwrite').delete(key);    r.onsuccess = () => res();              r.onerror = e => rej(e.target.error); });
  const dbKeys = (db)           => new Promise((res, rej) => { const r = tx(db,'readonly').getAllKeys();     r.onsuccess = e => res(e.target.result); r.onerror = e => rej(e.target.error); });

  const migrate = (state) => {
    if (!state) return null;
    if (state.v !== VERSION) state.v = VERSION;
    return state;
  };

  const _parseHash = (hash) => {
    const raw   = hash.replace(/^#/, '');
    const colon = raw.indexOf(':');
    return colon === -1
      ? { page: raw, id: null }
      : { page: raw.slice(0, colon), id: raw.slice(colon + 1) };
  };

  const isSensitive = f =>
    f.type === 'password' ||
    SENSITIVE.has(f.type) ||
    [...SENSITIVE].some(s => (f.name || f.id || '').toLowerCase().includes(s));

  const sel = el =>
    el.id ? `#${el.id}` : el.name ? `[name="${el.name}"]` : el.tagName.toLowerCase();

  const capture = (root) => {
    const r = root || document;
    const bareFields = [...r.querySelectorAll('input,textarea,select')]
      .filter(el => !el.closest('form') && !isSensitive(el) && (el.name || el.id))
      .map(el => ({ sel: sel(el), val: el.value }));
    return {
      v: VERSION,
      ts: Date.now(),
      url: location.href,
      hash: location.hash,
      scroll: { x: scrollX, y: scrollY },
      focus: document.activeElement ? sel(document.activeElement) : null,
      fields: bareFields,
      forms: [...(r.tagName === 'FORM' ? [r] : r.querySelectorAll('form'))].map(f => ({
        sel: sel(f),
        fields: [...f.querySelectorAll('input,textarea,select')]
          .filter(el => !isSensitive(el) && (el.name || el.id))
          .map(el => ({ sel: sel(el), val: el.value }))
      })).filter(f => f.fields.length)
    };
  };

  const save = async (pid, formEl) => {
    _mem[pid] = capture(formEl);
    await dbPut(await getDB(), _mem[pid], pid);
  };

  const restore = async (db, pid, root) => {
    const raw   = await dbGet(db, pid);
    const state = migrate(raw);
    if (!state || state.url !== location.href) return;
    scrollTo(state.scroll.x, state.scroll.y);
    const r = root || document;
    // restore bare fields (outside forms)
    if (state.fields) {
      state.fields.forEach(({ sel: eSel, val }) => {
        const el = r.querySelector(eSel);
        if (el) { el.value = val; el.dispatchEvent(new Event('input', { bubbles: true })); }
      });
    }
    state.forms.forEach(({ sel: fSel, fields }) => {
      const form = r.tagName === 'FORM' ? r : r.querySelector(fSel);
      if (!form) return;
      fields.forEach(({ sel: eSel, val }) => {
        const el = form.querySelector(eSel);
        if (el) el.value = val;
      });
    });
    if (state.focus) document.querySelector(state.focus)?.focus();
    if (state.hash) {
      history.replaceState(null, '', state.hash);
      document.dispatchEvent(new CustomEvent('gnoke:resurrect', {
        detail: _parseHash(state.hash)
      }));
    }
  };

  window.gnokeSpirit = {
    async wake(pid, formEl) {
      pid = pid || location.pathname;
      const db = await getDB();
      await restore(db, pid, formEl);

      let t;
      const target = formEl || window;

      target.addEventListener('input', () => {
        clearTimeout(t);
        t = setTimeout(() => save(pid, formEl), 300);
      });

      window.addEventListener('pagehide', () => save(pid, formEl));

      window.addEventListener('visibilitychange', () => {
        if (document.visibilityState === 'hidden') save(pid, formEl);
      });

      return pid;
    },

    async kill(pid) {
      pid = pid || location.pathname;
      await dbDel(await getDB(), pid);
    },

    async list() {
      return dbKeys(await getDB());
    }
  };
})();

