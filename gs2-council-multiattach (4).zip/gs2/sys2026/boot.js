'use strict';
/* ─── boot.js ── sys2026 ────────────────────────────────────────────
   Gnoke Station — System Boot Coordinator
   Edmund Sparrow © 2026 — MIT

   WHAT THIS IS:
   The single source of truth for the firmware + system load order.
   Every app's index.html loads only this file from /sys2026/.
   Boot loads the invariant system sequence, then dispatches
   'gnoke:boot' so the app can load its own scripts on top.

   SYSTEM SEQUENCE (same for every app, in this exact order):
     1. /firmware/gnoke-client.js   — bus connection stub
     2. /firmware/gnoke-syscall.js  — kernel syscall bridge
     3. /firmware/gnoke-core.js     — high-level Gnoke.ready() API
     4. /sys2026/sysdb.js           — namespaced app storage
     5. /sys2026/gnoke-spirit.js   — UI state resurrection
     5. gnoke-presence.js           — app bus registration (app-local copy)

   APP SCRIPTS:
   Each app declares its own scripts via a <meta> tag in <head>:
     <meta name="gnoke:scripts" content="notes-data.js,notes-ui.js">
   Boot reads this list and loads them sequentially before presence.

   WHY <meta> NOT data- ATTRIBUTE ON THE BOOT SCRIPT TAG:
   The boot script tag has no guaranteed id. The <meta> tag is
   always findable, explicit, and doesn't require the app to know
   its own script src path.
──────────────────────────────────────────────────────────────────── */

const _load = src => new Promise((resolve, reject) => {
  const s   = document.createElement('script');
  s.src     = src;
  s.onload  = resolve;
  s.onerror = () => reject(new Error(`[boot] Failed: ${src}`));
  document.head.appendChild(s);
});

(async () => {
  const FIRMWARE = [
    '/firmware/gnoke-client.js',
    '/firmware/gnoke-syscall.js',
    '/firmware/gnoke-core.js',
  ];

  const SYSTEM = [
    '/sys2026/sysdb.js',
    '/sys2026/gnoke-spirit.js',
  ];

  // App-specific scripts declared in <meta name="gnoke:scripts">
  const meta    = document.querySelector('meta[name="gnoke:scripts"]');
  const APP     = meta ? meta.content.split(',').map(s => s.trim()).filter(Boolean) : [];

  const PRESENCE = ['gnoke-presence.js'];

  try {
    for (const src of [...FIRMWARE, ...SYSTEM, ...APP, ...PRESENCE]) {
      await _load(src);
    }
    document.dispatchEvent(new CustomEvent('gnoke:boot'));
  } catch (err) {
    console.error('[boot] Sequence failed —', err.message);
    document.dispatchEvent(new CustomEvent('gnoke:boot:error', { detail: err.message }));
  }
})();

