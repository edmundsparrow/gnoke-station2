'use strict';
const GNOKE_SPEC_VERSION = '1.0';
const GnokeRegistry = new Map();
async function resolveConfig(url) {
  try {
    const origin  = new URL(url).origin;
    const res     = await fetch(`${origin}/gnoke.json`, {
      method:  'GET',
      headers: { 'Accept': 'application/json' },
      signal:  AbortSignal.timeout(3000),
    });
    if (!res.ok) return null;
    const config = await res.json();
    if (config.gnoke !== GNOKE_SPEC_VERSION) {
      console.warn(`[config] Unsupported gnoke.json spec: "${config.gnoke}" — expected "${GNOKE_SPEC_VERSION}"`);
      return null;
    }
    if (!config.appId || !config.name || !config.role) {
      console.warn('[config] gnoke.json missing required fields: appId, name, role');
      return null;
    }
    return config;
  } catch (err) {
    return null;
  }
}
function detectTier(config) {
  if (!config)          return 1;
  if (config.native)    return 3;
  return 2;
}
async function registerWithKernel(config, pid) {
  if (!window.GnokeClient?.ready) return;
  try {
    await GnokeClient.broadcast('APP_CONFIG_RESOLVED', {
      appId:  config.appId,
      name:   config.name,
      role:   config.role,
      tier:   detectTier(config),
      pid,
      config,
    });
  } catch (err) {
    console.warn('[config] Could not broadcast config to bus:', err.message);
  }
}
function showTierBadge(el, tier) {
  if (!el) return;
  const labels = {
    1: { text: 'Unregistered', color: '#8aa3bc' },
    2: { text: '✦ Gnoke Compatible', color: '#3f6e9b' },
    3: { text: '⬡ Gnoke Native',     color: '#0e9f6e' },
  };
  const badge = document.createElement('div');
  badge.textContent = labels[tier].text;
  Object.assign(badge.style, {
    position:   'fixed',
    bottom:     '72px',
    left:       '50%',
    transform:  'translateX(-50%)',
    background: '#ffffff',
    border:     `1px solid ${labels[tier].color}`,
    color:      labels[tier].color,
    fontFamily: 'DM Mono, monospace',
    fontSize:   '10px',
    fontWeight: '600',
    padding:    '5px 14px',
    borderRadius: '20px',
    boxShadow:  '0 4px 12px rgba(31,71,101,0.12)',
    zIndex:     '9999',
    letterSpacing: '0.06em',
    pointerEvents: 'none',
    transition: 'opacity 0.3s',
    opacity:    '1',
  });
  document.body.appendChild(badge);
  setTimeout(() => {
    badge.style.opacity = '0';
    setTimeout(() => badge.remove(), 300);
  }, 2000);
}
window.spawnApp = async function spawnApp(url, name, id, el) {
  if (!url || url === '#') { alert(`${name} — not yet built`); return; }
  if (el) {
    el.classList.add('launching');
    setTimeout(() => el.classList.remove('launching'), 600);
  }
  const configPromise = resolveConfig(url);
  const tab = window.open(url, `gnoke-${id}`);
  if (!tab) {
    alert('Popup blocked — allow popups for this origin');
    return;
  }
  const config = await configPromise;
  const tier   = detectTier(config);
  const pid = `${(config?.appId || id).toLowerCase().replace(/\W+/g,'-')}-${Date.now().toString(36)}`;
  GnokeRegistry.set(config?.appId || id, {
    config,
    pid,
    tier,
    url,
    name:  config?.name  || name,
    ts:    Date.now(),
  });
  console.info(
    `[config] Spawned %c${config?.name || name}%c — Tier ${tier}`,
    'font-weight:700',
    'font-weight:400',
    config || '(no gnoke.json)'
  );
  registerWithKernel(config || { appId: id, name, role: 'guest_app' }, pid);
  showTierBadge(el, tier);
};
window.GnokeConfig = Object.freeze({
  SPEC_VERSION: GNOKE_SPEC_VERSION,
  registry: GnokeRegistry,
  resolve: resolveConfig,
  tierLabel(tier) {
    return { 1: 'Unregistered', 2: 'Compatible', 3: 'Native' }[tier] || 'Unknown';
  },
  list() {
    return [...GnokeRegistry.entries()].map(([appId, entry]) => ({
      appId,
      name:  entry.name,
      tier:  entry.tier,
      url:   entry.url,
      pid:   entry.pid,
      ts:    entry.ts,
    }));
  },
});
console.info('[config] Gnoke Config Resolver v1.0 loaded — spawnApp intercepted');

