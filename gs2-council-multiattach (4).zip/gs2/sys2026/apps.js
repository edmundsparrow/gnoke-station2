'use strict';

const APPS = [
  { id: 'calc',          name: 'Calculator',    desc: 'Native arithmetic and currency market',                icon: '🧮', iconUrl: '/apps/calculator/assets/icon.svg',       url: '/apps/calculator/index.html',                    cat: 'apps',   caps: [],     privileged: false },
  { id: 'coding',        name: 'Coding',        desc: 'Web coding editor',                                    icon: '</>', iconUrl: '/apps/editor/assets/icon.svg',          url: '/apps/editor/index.html',                        cat: 'apps',   caps: [],     privileged: false },
  { id: 'contact',       name: 'Contacts',      desc: 'Offline contact book',                                 icon: '👤', url: '/apps/contact/index.html',                       cat: 'apps',   caps: [],     privileged: false },
  { id: 'council',       name: 'Council',       desc: 'Multi-AI thread relay',                                icon: '⚡', url: '/apps/council/index.html',                       cat: 'apps',   caps: [],     privileged: false },
  { id: 'dictionary',    name: 'Dictionary',    desc: 'Lexical reasoning engine (coming soon)',               icon: '📕', url: '#',                                              cat: 'apps',   caps: [],     privileged: false },
  { id: 'chat',          name: 'Free Text',     desc: 'Local P2P messaging on this device',                   icon: '💬', iconUrl: '/apps/chat/assets/icon.svg',             url: '#',                                              cat: 'apps',   caps: [],     privileged: false },
  { id: 'geocompass',    name: 'GeoCompass',    desc: 'Real-time GPS bearing and heading',                    icon: '🧭', url: '/apps/geocompass/index.html',                cat: 'apps', caps: [],   privileged: false },
  { id: 'mail',          name: 'Mail',          desc: 'Messages and inbox',                                   icon: '✉️', iconUrl: '/apps/mail/assets/icon.svg',             url: '#',                                              cat: 'apps',   caps: [],     privileged: false },
  { id: 'news',          name: 'News',          desc: 'Latest headlines and feeds',                           icon: '📰', iconUrl: '/apps/news/assets/icon.svg',            url: '/apps/news/index.html',                          cat: 'apps',   caps: [],     privileged: false },
  { id: 'notes',         name: 'Notes',         desc: 'Write files to workspace',                             icon: '¶',  url: '/apps/notes/index.html',                         cat: 'apps',   caps: [],     privileged: false },
  { id: 'qr',            name: 'QR Scanner',    desc: 'Scan and generate QR codes',                           icon: '▦',  url: '#',                                              cat: 'apps',   caps: [],     privileged: false },
  { id: 'reader',        name: 'Reader',        desc: 'Markdown, PDF and plain text viewer',                  icon: '📖', url: '#',                                              cat: 'apps',   caps: [],     privileged: false },
  { id: 'share',         name: 'Share',         desc: 'Share files and links across apps',                    icon: '↗',  iconUrl: '/apps/share/assets/icon.svg',            url: '#',                                              cat: 'apps',   caps: [],     privileged: false },
  { id: 'shopping-list', name: 'Shopping List', desc: 'Offline shopping trips with price tracking and budget', icon: '🛒', url: '/apps/shopping-list/index.html',                 cat: 'apps',   caps: [],     privileged: false },
  { id: 'videos',        name: 'Videos',        desc: 'Video player',                                         icon: '▶',  iconUrl: '/apps/videos/assets/icon.svg',          url: '#',                                              cat: 'apps',   caps: [],     privileged: false },

  { id: 'google',        name: 'Google',        desc: 'Search the web',                                       icon: 'G',  iconUrl: '/apps/google/assets/icon.svg',           url: 'https://www.google.com',                         cat: 'web',    caps: [],     privileged: false },
  { id: 'telegram',      name: 'Telegram',      desc: 'Messaging via Telegram Web',                           icon: '✈️', iconUrl: '/apps/telegram/assets/icon.svg',         url: 'https://web.telegram.org/a/',                    cat: 'web',    caps: [],     privileged: false },

  { id: 'scrabble',      name: 'Scrabble',      desc: 'Classic word tile game',                               icon: '🔠', iconUrl: '/apps/scrabble/assets/icon.svg',         url: '#',                                              cat: 'games',  caps: [],     privileged: false },
  { id: 'sudoku',        name: 'Sudoku',        desc: 'Number grid puzzle',                                   icon: '9',  iconUrl: '/apps/sudoku/assets/icon.svg',           url: '#',                                              cat: 'games',  caps: [],     privileged: false },

  { id: 'debug',         name: 'Debug',         desc: 'Task manager and process inspector',                   icon: '⚙',  url: '/system/debug/index.html',                      cat: 'system', caps: [],     privileged: true  },
  { id: 'pache',         name: 'Pache',         desc: 'SW-powered local server for developers',               icon: '🗄', iconUrl: '/apps/pache/assets/icon.svg',           url: '/apps/pache/index.html',                        cat: 'system', caps: ['vfs'], privileged: true  },
  { id: 'settings',      name: 'Settings',      desc: 'System preferences',                                   icon: '⚙️', iconUrl: '/system/settings/assets/icon.svg',       url: '/system/settings/index.html',                   cat: 'system', caps: [],     privileged: true  },
  { id: 'terminal',      name: 'Terminal',      desc: 'System shell',                                         icon: '>_', iconUrl: '/system/terminal/assets/icon.svg',       url: '#',                                              cat: 'system', caps: [],     privileged: true  },
];

const CATS = {
  apps:   { label: 'Apps' },
  web:    { label: 'Web' },
  games:  { label: 'Games' },
  system: { label: 'System' },
};
