(() => {
'use strict';
const SPIRIT_DB  = 'gnoke:spirit';
const SPIRIT_ST  = 'processes';
async function _readSpirit() {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open(SPIRIT_DB, 1);
    req.onerror = () => resolve({});
    req.onsuccess = () => {
      const db    = req.result;
      if (!db.objectStoreNames.contains(SPIRIT_ST)) return resolve({});
      const store = db.transaction(SPIRIT_ST, 'readonly').objectStore(SPIRIT_ST);
      const out   = {};
      store.openCursor().onsuccess = e => {
        const cursor = e.target.result;
        if (!cursor) return resolve(out);
        out[cursor.key] = cursor.value;
        cursor.continue();
      };
    };
  });
}
function _download(filename, data) {
  const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
  const url  = URL.createObjectURL(blob);
  const a    = document.createElement('a');
  a.href     = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}
window.GnokeBackup = Object.freeze({
  async export() {
    const spirit   = await _readSpirit();
    /* Read UID from GnokeFirmware/config IDB — same store auth.js writes to */
    const uid = await (async () => {
      try {
        return await new Promise((res, rej) => {
          const req = indexedDB.open('GnokeFirmware', 2);
          req.onsuccess = e => {
            const r = e.target.result.transaction('config','readonly').objectStore('config').get('gnoke:uid');
            r.onsuccess = () => res(r.result || 'unknown');
            r.onerror   = () => res('unknown');
          };
          req.onerror = () => res('unknown');
        });
      } catch { return 'unknown'; }
    })();
    const filename = `gnoke-backup-${new Date().toISOString().slice(0,10)}.json`;
    _download(filename, {
      gnoke:    '1.0',
      exported: new Date().toISOString(),
      uid,
      spirit,
    });
    console.info(`[backup] Exported ${Object.keys(spirit).length} app(s) → ${filename}`);
    return { apps: Object.keys(spirit).length, filename };
  },
  async restore(file) {
    const text = await file.text();
    const data = JSON.parse(text);
    if (data.gnoke !== '1.0') throw new Error('Unrecognised backup format');
    const spirit = data.spirit || {};
    const db     = await new Promise((res, rej) => {
      const r = indexedDB.open(SPIRIT_DB, 1);
      r.onupgradeneeded = () => {
        if (!r.result.objectStoreNames.contains(SPIRIT_ST))
          r.result.createObjectStore(SPIRIT_ST);
      };
      r.onsuccess = () => res(r.result);
      r.onerror   = () => rej(r.error);
    });
    const tx    = db.transaction(SPIRIT_ST, 'readwrite');
    const store = tx.objectStore(SPIRIT_ST);
    for (const [key, val] of Object.entries(spirit)) store.put(val, key);
    await new Promise((res, rej) => { tx.oncomplete = res; tx.onerror = rej; });
    console.info(`[backup] Restored ${Object.keys(spirit).length} app(s)`);
    return { apps: Object.keys(spirit).length };
  },
});
console.info('[backup] GnokeBackup ready — export() / restore(file)');
})();

