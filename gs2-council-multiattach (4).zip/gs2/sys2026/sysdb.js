'use strict';

const GnokeSysDB = (() => {

  const DB_NAME = 'GnokeStore';
  const DB_VER  = 1;
  let   _db     = null;

  function _open() {
    if (_db) return Promise.resolve(_db);
    return new Promise((res, rej) => {
      const req = indexedDB.open(DB_NAME, DB_VER);
      req.onupgradeneeded = e => {
        const db = e.target.result;
        if (!db.objectStoreNames.contains('app-data')) {
          db.createObjectStore('app-data', { keyPath: ['appId', 'key'] });
        }
        if (!db.objectStoreNames.contains('sessions')) {
          db.createObjectStore('sessions', { keyPath: ['appId', 'id'] });
        }
      };
      req.onsuccess = e => { _db = e.target.result; res(_db); };
      req.onerror   = e => rej(e.target.error);
    });
  }

  function _p(req) {
    return new Promise((res, rej) => {
      req.onsuccess = e => res(e.target.result);
      req.onerror   = e => rej(e.target.error);
    });
  }

  function _tx(db, store, mode) {
    return db.transaction(store, mode).objectStore(store);
  }

  function nuke() {
    _db = null;
    return new Promise((res, rej) => {
      const req = indexedDB.deleteDatabase(DB_NAME);
      req.onsuccess = () => res();
      req.onerror   = () => rej(req.error);
      req.onblocked = () => {
        console.warn('[sysdb] GnokeStore open in another tab — will wipe on close.');
        res();
      };
    });
  }

  function factory(appId) {
    if (!appId) throw new Error('[sysdb] appId is required.');

    const kv = {
      async get(key) {
        const db  = await _open();
        const row = await _p(_tx(db, 'app-data', 'readonly').get([appId, key]));
        return row?.val ?? null;
      },
      async put(key, val) {
        const db = await _open();
        await _p(_tx(db, 'app-data', 'readwrite').put({ appId, key, val }));
      },
      async delete(key) {
        const db = await _open();
        await _p(_tx(db, 'app-data', 'readwrite').delete([appId, key]));
      },
      async list() {
        const db      = await _open();
        const range   = IDBKeyRange.bound([appId], [appId, '\uffff']);
        const results = await _p(_tx(db, 'app-data', 'readonly').getAll(range));
        return results.map(r => r.key);
      },
    };

    const sessions = {
      async put(session) {
        if (!session?.id) throw new Error('[sysdb] session.id is required.');
        const db = await _open();
        await _p(_tx(db, 'sessions', 'readwrite').put({ ...session, appId }));
      },
      async getAll() {
        const db      = await _open();
        const range   = IDBKeyRange.bound([appId], [appId, '\uffff']);
        const results = await _p(_tx(db, 'sessions', 'readonly').getAll(range));
        return results.map(({ appId: _, ...rest }) => rest);
      },
      async delete(id) {
        const db = await _open();
        await _p(_tx(db, 'sessions', 'readwrite').delete([appId, id]));
      },
    };

    return Object.freeze({ ...kv, sessions });
  }

  factory.nuke = nuke;
  return factory;

})();

if (typeof window !== 'undefined') window.GnokeSysDB = GnokeSysDB;

