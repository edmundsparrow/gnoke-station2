'use strict';
const GnokeClient=(()=>{const W='./firmware/gnoke-worker.js',HB=20_000;let _port=null,_pid=null,_booted=false,_bootP=null,_hbT=null,_seq=0,_bmeta={},_sessionToken=null;const _p=new Map(),_h=new Map(),_b=new Set(),_d=new Set(),_r=new Set();const _fwDB=(()=>{let _db=null;function _op(){if(_db)return Promise.resolve(_db);return new Promise((res,rej)=>{const req=indexedDB.open('GnokeFirmware',2);req.onupgradeneeded=e=>{const db=e.target.result;if(!db.objectStoreNames.contains('kernel'))db.createObjectStore('kernel');if(!db.objectStoreNames.contains('config'))db.createObjectStore('config');};req.onsuccess=e=>{_db=e.target.result;res(_db);};req.onerror=e=>rej(e.target.error);});}return{async get(k){const db=await _op();return new Promise((res,rej)=>{const r=db.transaction('config','readonly').objectStore('config').get(k);r.onsuccess=()=>res(r.result??null);r.onerror=()=>rej(r.error);});},async set(k,v){const db=await _op();return new Promise((res,rej)=>{const r=db.transaction('config','readwrite').objectStore('config').put(v,k);r.onsuccess=()=>res();r.onerror=()=>rej(r.error);});},async remove(k){const db=await _op();return new Promise((res,rej)=>{const r=db.transaction('config','readwrite').objectStore('config').delete(k);r.onsuccess=()=>res();r.onerror=()=>rej(r.error);});}};})();async function _res(n){const k=`pid:${n||'proc'}`;let p=await _fwDB.get(k);if(!p){p=`${(n||'proc').toLowerCase().replace(/\W+/g,'-')}-${Date.now().toString(36)}-${Math.random().toString(36).slice(2,6)}`;await _fwDB.set(k,p);}return p;}function boot({name='app',meta={}}={}){if(_bootP)return _bootP;_bmeta={name,...meta};_bootP=(async()=>{if(!('SharedWorker'in window)){_booted=true;return;}_pid=await _res(name);const w=new SharedWorker(W);_port=w.port;_port.onmessage=_om;_port.start();_sessionToken=await new Promise(resolve=>{const h=ev=>{if(ev.data?.event==='SESSION_TOKEN'){_port.removeEventListener('message',h);resolve(ev.data.token);}};_port.addEventListener('message',h);});const _rr=await _s({cmd:'REGISTER',pid:_pid,meta:_bmeta,token:_sessionToken});if(_rr?.error==='SESSION_MISMATCH'){await _fwDB.remove(`pid:${name}`);_pid=await _res(name);await _s({cmd:'REGISTER',pid:_pid,meta:_bmeta,token:_sessionToken});}clearInterval(_hbT);_hbT=setInterval(()=>_s({cmd:'PING',pid:_pid}).catch(()=>{}),HB);document.addEventListener('visibilitychange',async()=>{if(document.visibilityState==='hidden'){_s({cmd:'PING',pid:_pid}).catch(()=>{});return;}await _s({cmd:'REGISTER',pid:_pid,meta:_bmeta}).catch(()=>{});});_booted=true;})();return _bootP;}async function send(t,e,d){_a();return _s({cmd:'SEND',from:_pid,to:t,event:e,data:d});}async function broadcast(e,d){_a();return _s({cmd:'BROADCAST',from:_pid,event:e,data:d});}async function list(){_a();const r=await _s({cmd:'LIST'});return r.processes;}async function listAll(){_a();const r=await _s({cmd:'LIST'});return{processes:r.processes||{},ghosts:r.ghosts||{}};}async function claimCapability(c){_a();return _s({cmd:'CLAIM_CAPABILITY',capability:c});}function _sendKernel(m){_a();return _s(m);}function on(e,fn){if(!_h.has(e))_h.set(e,new Set());_h.get(e).add(fn);return()=>_h.get(e)?.delete(fn);}function onProcessBorn(fn){_b.add(fn);return()=>_b.delete(fn);}function onProcessDied(fn){_d.add(fn);return()=>_d.delete(fn);}function onRegistry(fn){_r.add(fn);return()=>_r.delete(fn);}function _om(ev){const m=ev.data;if(!m)return;if(m._id){const p=_p.get(m._id);if(!p)return;_p.delete(m._id);m.ok?p.resolve(m.result):p.reject(new Error(m.error));return;}switch(m.event){case'MESSAGE':{const f=_h.get(m.type);if(f)f.forEach(fn=>{try{fn(m.data,m.from);}catch{}});break;}case'PROCESS_BORN':_b.forEach(fn=>{try{fn(m.pid,m.meta);}catch{}});break;case'PROCESS_DIED':_d.forEach(fn=>{try{fn(m.pid);}catch{}});break;case'REGISTRY':_r.forEach(fn=>{try{fn(m.processes);}catch{}});break;case'PEER_JOINED':if(_pid&&_port&&_bmeta)_s({cmd:'REGISTER',pid:_pid,meta:_bmeta}).catch(()=>{});break;}}function _s(m){return new Promise((res,rej)=>{const id=`gc_${Date.now().toString(36)}_${++_seq}`;_p.set(id,{resolve:res,reject:rej});try{_port.postMessage({...m,_id:id});}catch(e){_p.delete(id);rej(e);}});}function _a(){if(!_booted)throw new Error('[gnoke-client] Call boot() first.');}return Object.freeze({boot,send,broadcast,list,listAll,claimCapability,_sendKernel,on,onProcessBorn,onProcessDied,onRegistry,get pid(){return _pid;},get ready(){return _booted;}});})();
let _live={},_q='';

/* ── Grid detection ── */
function _detectGrid() {
  const w = window.innerWidth, h = window.innerHeight;
  if (w > h) return Math.max(5, Math.floor(w / 120));
  return 4;
}
function _applyGrid() {
  document.documentElement.style.setProperty('--grid-cols', _detectGrid());
}
_applyGrid();
new ResizeObserver(_applyGrid).observe(document.documentElement);
function tick(){const n=new Date();document.getElementById('tbClock').textContent=n.toLocaleTimeString('en-GB',{hour:'2-digit',minute:'2-digit',hour12:false});}
tick();setInterval(tick,1000);
function setBus(s){const pill=document.getElementById('busPill'),lbl=document.getElementById('busLabel');pill.className='bus-pill'+(s==='live'?' live':s==='error'?' error':'');lbl.textContent=s==='live'?'Bus Live':s==='error'?'Bus Error':'No Bus';}
function renderLauncher(q=''){
  const c=document.getElementById('appScroll');c.innerHTML='';
  const lq=q.toLowerCase();
  const ln=new Set(Object.values(_live).map(d=>(d.meta?.name||'').toLowerCase()));
  for(const[catId,cat]of Object.entries(CATS)){
    const apps=APPS.filter(a=>a.cat===catId&&(!lq||a.name.toLowerCase().includes(lq)||a.desc.toLowerCase().includes(lq)));
    if(!apps.length)continue;
    const b=document.createElement('div');b.className='cat-block';
    b.innerHTML=`<div class="cat-label open">${cat.label}<span class="cl-chev">▶</span></div>
    <div class="cat-apps open">${apps.map(a=>`
      <div class="app-tile${a.privileged?' privileged':''}${ln.has(a.name.toLowerCase())?' running':''}"
           data-url="${a.url}" data-id="${a.id}" data-name="${a.name}" role="button" tabindex="0" title="${a.desc}">
        <div class="live-dot"></div>
        <div class="at-icon" style="padding:0;overflow:hidden;background:transparent;border:none">
          <img src="${a.iconUrl||`/apps/${a.id}/assets/icon.svg`}" alt="${a.name}"
               onerror="this.style.display='none';this.nextElementSibling.style.display='flex'"
               style="width:100%;height:100%;object-fit:cover;border-radius:10px;display:block">
          <span style="display:none;width:100%;height:100%;align-items:center;justify-content:center;font-size:20px;background:linear-gradient(135deg,var(--surface3),var(--blue-light))">${a.icon||a.name[0]}</span>
        </div>
        <div class="at-name">${a.name}</div>
      </div>`).join('')}</div>`;
    c.appendChild(b);
  }
  c.querySelectorAll('.cat-label').forEach(h=>{
    h.addEventListener('click',e=>{e.stopPropagation();h.classList.toggle('open');h.nextElementSibling.classList.toggle('open');});
  });
  c.querySelectorAll('.app-tile').forEach(t=>{
    const fn=()=>spawnApp(t.dataset.url,t.dataset.name,t.dataset.id,t);
    t.addEventListener('click',fn);
    t.addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' ')fn();});
  });
}
function spawnApp(url,name,id,el){
  if(!url||url==='#'){alert(`${name} — not yet built`);return;}
  const tab=window.open(url,`gnoke-${id}`);
  if(tab){if(el){el.classList.add('launching');setTimeout(()=>el.classList.remove('launching'),600);}}
  else alert('Popup blocked — allow popups for this origin');
}
(async()=>{
  renderLauncher();
  document.getElementById('appSearch').addEventListener('input',e=>{_q=e.target.value;renderLauncher(_q);});
  document.addEventListener('click',e=>{
    const s=document.getElementById('appSearch');
    if(!s.contains(e.target)&&e.target.id!=='btnCustom'){s.value='';_q='';renderLauncher('');}
  });
  const modal=document.getElementById('customModal');
  document.getElementById('btnCustom').addEventListener('click',()=>{modal.classList.add('open');setTimeout(()=>document.getElementById('customUrl').focus(),100);});
  document.getElementById('customCancel').addEventListener('click',()=>modal.classList.remove('open'));
  modal.addEventListener('click',e=>{if(e.target===modal)modal.classList.remove('open');});
  document.getElementById('customSpawn').addEventListener('click',()=>{
    const url=document.getElementById('customUrl').value.trim();
    if(!url)return;
    spawnApp(url,url,`custom-${Date.now()}`,null);
    modal.classList.remove('open');
    document.getElementById('customUrl').value='';
  });
  document.getElementById('customUrl').addEventListener('keydown',e=>{
    if(e.key==='Enter')document.getElementById('customSpawn').click();
    if(e.key==='Escape')modal.classList.remove('open');
  });
  if(!('SharedWorker'in window)){setBus('error');return;}
  try{
    await GnokeClient.boot({name:'gnoke-launch',meta:{role:'launcher'}});
    try{await GnokeClient.claimCapability('dock');}catch(_){}
    setBus('live');
    const{processes}=await GnokeClient.listAll();
    _live=processes;renderLauncher(_q);
    GnokeClient.onRegistry(procs=>{_live=procs;renderLauncher(_q);});
  }catch(e){setBus('error');}
})();


